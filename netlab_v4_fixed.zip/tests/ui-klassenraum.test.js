"use strict";
/* KLASSENRAUM — DIE OBERFLÄCHE (Bereich B): Lehrkräfte-Ansicht `klassenraum` und Azubi-Ansicht `mitarbeit`.
   Verbindlich: docs/entwicklung/Klassenraum/B – Oberfläche und Ablauf.md
     § 1.2 Anmeldung        § 2.1/2.2 DOM      § 4 Startseiten-Zeile (Haken auf Bus „ansicht“)
     § 6.1 Öffnungsweg      § 7 Ergebnis-Toast § 8 Block-Eingabe   § 9 Ampel   § 10 Datei…   § 11 Einstellungen

   WAS HIER BEWIESEN WIRD (jeder Fall nennt seinen Abschnitt):
     · beide Ansichten angemeldet (Titel/Symbole), Einstellungsabschnitt, Bus-Hörer
     · die Lehrkraft erzeugt eine Sitzung, sieht den Code GROSS und kopiert ihn
     · genau sechs Bedienelemente in der Lehrkraft-Ansicht, drei beim Azubi (R12, B § 2.1/2.2)
     · die Ampel rechnet richtig: oberer Median, „Plätze nicht eingestellt“, gelb/grün (B § 9.2)
     · die Ergebnis-Eingabe nimmt einen Block, erkennt Doppelte und füllt die Tafel (B § 8)
     · der Azubi: Tippfehler wird MARKIERT und öffnet NICHT; gültiger Code öffnet über den echten Weg
     · der Bildungsstand bleibt unangetastet (E3)
     · der Ergebnis-Toast hängt am Kanal „klassenraum“ (B § 7)
     · „Datei…“ benutzt den Hausdialog (app.js:246-265, mit Escape) statt eines eigenen Overlays

   KEIN GÜLTIGER CODE WIRD ERFUNDEN: `NL-4F7K-2Q` ist das FORMBEISPIEL aus A § 1.4 und ausdrücklich
   KEIN gültiger Code (er steht nur als Platzhalter im Feld). Jeder Code in diesem Test kommt aus
   `Spiel.klassenraum.erzeugen` oder `ergebnisCode` — dann kann er nicht veralten.

   DIE UI-SCHICHT WIRD HEADLESS NICHT GELADEN (tests/run.js:42-48 reicht nur `require` durch) — dieser
   Test lädt src/ui/klassenraum.js selbst in einem vm-Bereich mit nachgebildetem DOM.

   Auf oberster Ebene steht NUR die gekapselte Fähigkeitsprobe (der Gruppenname braucht sie vorher);
   alle Helfer liegen im `gruppe`-Rückruf, und im Gruppenrumpf steht keine Zusicherung — sonst reißt
   eine Ausnahme den ganzen Lauf mit LADEFEHLER (Exit 2) mit. */

const KL_KLAR = (() => {
  try {
    const laden = typeof require === "function" && typeof document === "undefined" && typeof Spiel === "object" && Spiel !== null;
    const codec = laden && typeof Spiel.klassenraum === "object" && typeof Spiel.klassenraum.ausCode === "function";
    return {laden, codec, zusatz: laden ? "" : " (kein require im Testbereich – nur unter node tests/run.js)"};
  } catch (e) { return {laden: false, codec: false, zusatz: " (Testbereich nicht lesbar)"}; }
})();

gruppe("UI: Klassenraum" + KL_KLAR.zusatz, () => {
  /* ================= DOM-Ersatz (nur für den vm-Bereich) ================= */
  function klKnoten(tag){
    const el = {
      nodeType: 1, tag, kinder: [], attrs: {}, listeners: {}, className: "", _text: "", parentNode: null, value: "",
      append(...k){ for (const x of k) if (x != null && x !== false) { if (typeof x === "object") x.parentNode = el; el.kinder.push(x); } },
      replaceChildren(...k){ el.kinder = []; el.append(...k); },
      remove(){ if (el.parentNode) el.parentNode.kinder = el.parentNode.kinder.filter(x => x !== el); },
      setAttribute(k, v){ el.attrs[k] = String(v); },
      getAttribute(k){ return el.attrs[k] === undefined ? null : el.attrs[k]; },
      removeAttribute(k){ delete el.attrs[k]; },
      addEventListener(art, fn){ (el.listeners[art] ||= []).push(fn); },
      click(){ for (const fn of (el.listeners.click || []).slice()) fn({currentTarget: el, target: el, preventDefault(){}, stopPropagation(){}}); },
      ausloesen(art, o){ for (const fn of (el.listeners[art] || []).slice()) fn(Object.assign({currentTarget: el, target: el, preventDefault(){}, stopPropagation(){}}, o)); },
      insertBefore(neu, vor){ const i = el.kinder.indexOf(vor); el.kinder.splice(i < 0 ? el.kinder.length : i, 0, neu); neu.parentNode = el; return neu; },
      querySelector(sel){ return klFinde(el, sel)[0] || null; },
      querySelectorAll(sel){ return klFinde(el, sel); },
      classList: {
        _l(){ return klKlassen(el); },
        _s(l){ el.className = l.join(" "); delete el.attrs.class; },
        add(...k){ const l = el.classList._l(); for (const x of k) if (!l.includes(x)) l.push(x); el.classList._s(l); },
        remove(...k){ el.classList._s(el.classList._l().filter(x => !k.includes(x))); },
        toggle(x, an){ const a = an === undefined ? !el.classList.contains(x) : !!an; if (a) el.classList.add(x); else el.classList.remove(x); return a; },
        contains(x){ return el.classList._l().includes(x); },
      },
      get hidden(){ return el.attrs.hidden !== undefined; },
      get children(){ return el.kinder.filter(k => k && k.tag); },
      set textContent(v){ el._text = String(v); el.kinder = []; },
      get textContent(){ return el.kinder.length ? el.kinder.map(klText).join("") : el._text; },
    };
    return el;
  }
  const klKlassen = el => String(el.className || (el.attrs && el.attrs.class) || "").split(/\s+/).filter(Boolean);
  function klPasst(el, sel){
    const s = String(sel).trim();
    if (/^[a-z][a-z0-9]*$/i.test(s)) return el.tag === s;
    const teile = s.match(/\.[\w-]+|\[[^\]]+\]/g) || [];
    return teile.length > 0 && teile.every(t => {
      if (t.startsWith(".")) return klKlassen(el).includes(t.slice(1));
      const m = /^\[([\w-]+)(?:="([^"]*)")?\]$/.exec(t);
      return !!m && (m[2] === undefined ? el.attrs[m[1]] !== undefined : el.attrs[m[1]] === m[2]);
    });
  }
  function klFinde(el, sel){
    const treffer = [];
    const lauf = k => { for (const x of k.kinder) if (x && x.tag) { if (klPasst(x, sel)) treffer.push(x); lauf(x); } };
    lauf(el);
    return treffer;
  }
  function klText(k){ return k == null ? "" : typeof k === "string" ? k : (k.textContent || ""); }
  /* h() mit demselben Vertrag wie src/ui/dom.js:7-20 */
  function klH(tag, attrs = {}, ...kinder){
    const el = klKnoten(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (k === "class") el.className = v;
      else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2), v);
      else if (k === "value") el.value = v;
      else if (v !== false && v != null) el.setAttribute(k, v === true ? "" : String(v));
    }
    for (const kid of kinder.flat(Infinity)) if (kid != null && kid !== false) el.append(kid.nodeType ? kid : {nodeType: 3, textContent: String(kid)});
    return el;
  }
  const klKnopf = (el, text) => klFinde(el, "button").find(b => klText(b).includes(text)) || null;
  /* KLR-12: Die Sitzungsliste ist eine LISTE — ihre Einträge zählen bei R12 separat. Gezählt werden
     die Dauer-Bedienelemente AUSSERHALB der Liste (der Bestand bleibt bei sechs). */
  function klSteuerAusserListe(p, c){
    const liste = p && p.K && p.K._L ? p.K._L.sitzungen : null;
    const drin = el => { let x = el; while (x) { if (x === liste) return true; x = x.parentNode; } return false; };
    return klFinde(c, "button").concat(klFinde(c, "select"), klFinde(c, "input"), klFinde(c, "textarea")).filter(el => !drin(el)).length;
  }

  /* ================= Prüfstand ================= */
  /* opt.importText/opt.importSync erlauben den Import-Weg im Test SYNCHRON zu messen: die echte
     Plattform liefert ein Promise; für die DOM-Prüfung genügt ein Thenable, das sofort antwortet. */
  function klPruefstand(opt = {}){
    const fs = require("fs"), path = require("path"), vm = require("vm");
    const registriert = [], abschnitte = [], busHaken = [], rufe = [], dialoge = [], exporte = [], importe = [];
    const seite = klKnoten("div");                          /* der Hub (.hb-seite) für die Startzeile */
    seite.className = "hb-seite";
    const dokument = {
      createElement: tag => klKnoten(tag), createElementNS: (ns, tag) => klKnoten(tag),
      createTextNode: t => ({nodeType: 3, textContent: String(t)}),
      getElementById: () => null, querySelectorAll: () => [], listeners: {},
      querySelector: sel => String(sel).includes("hb-seite") ? seite : null,
      addEventListener(){}, removeEventListener(){},
      body: klKnoten("body"), documentElement: klKnoten("html"), activeElement: null,
    };
    /* Plattform als Attrappe (im Testbereich gibt es sie nicht): „tauri“ zeigt den Server-Schalter. */
    const Plattform = {name: "tauri", datei: {
      exportieren: (name, text) => { exporte.push([name, text]); return Promise.resolve(true); },
      importieren: () => {
        importe.push(true);
        const text = opt.importText == null ? null : String(opt.importText);
        if (opt.importSync) return {then: fn => { fn(text); return {catch(){}}; }};
        return Promise.resolve(text);
      }}};
    const UIstub = {
      startHaken: [],
      app: {
        registrieren: (name, def) => { registriert.push({name, def}); return def; },
        einstellungAbschnitt: (titel, fn) => abschnitte.push({titel, fn}),
        /* wie app.js:246-265: Dialog mit Escape-Hörer */
        dialogOeffnen: (titel, inhalt) => { dialoge.push({titel, inhalt, zu: false});
          const esc = e => { if (e.key === "Escape") dialoge[dialoge.length - 1].zu = true; };
          dokument.listeners.keydown = (dokument.listeners.keydown || []).concat(esc);
          return dialoge.length - 1; },
        dialogZu: () => { if (dialoge.length) dialoge[dialoge.length - 1].zu = true; },
        aktuell: "heute",
      },
      /* `spiel` wie das echte Spiel: `oeffnen(iid)` merkt sich die Instanz — sonst könnte keine
         Ansicht je „ein Auftrag ist offen" sehen (genau daran hing der „Ich hänge"-Knopf: ohne
         offene Instanz sagt er ehrlich ab, und der Test hätte nur die Absage geprüft). Die Rufe
         werden weiter mitgeschrieben; der GETEILTE Zustand wird NICHT geöffnet (`Spiel.instanz`
         ist eine reine Abfrage), damit dieser Prüfstand die folgenden Dateien nicht verändert. */
      spiel: {
        oeffnen: iid => { rufe.push(["spiel-oeffnen", iid]); rufe.inst = Spiel.instanz(iid) || rufe.inst || null; return rufe.inst; },
        get inst(){ return rufe.inst || null; }},
      hub: {kopieren: (text, ok) => rufe.push(["kopieren", text, ok])},
      toast: (text, art, opt) => rufe.push(["toast", text, art, opt]),
    };
    const bereich = {
      UI: UIstub, h: klH, console, document: dokument,
      Bus: {an: (art, fn) => { busHaken.push({art, fn}); return () => {}; }},
      Spiel, store, Plattform, jetzt, heute,
      requestAnimationFrame: fn => { try { fn(0); } catch (e) {} return 0; },
      setTimeout: () => 0, clearTimeout(){},
    };
    vm.createContext(bereich);
    vm.runInContext(fs.readFileSync(path.join(__dirname, "..", "src", "ui", "klassenraum.js"), "utf8"), bereich, {filename: "ui/klassenraum.js"});
    return {UI: bereich.UI, K: bereich.UI.klassenraum, registriert, abschnitte, busHaken, rufe, dialoge, exporte, importe, Plattform, seite, dokument,
      zeige: i => { const c = klKnoten("div"); registriert[i].def.zeigen(c); return c; },
      start: () => { for (const fn of UIstub.startHaken) fn(); }};
  }

  /* ================= Kapsel ================= */
  const KL_T0 = Date.UTC(2026, 9, 10, 9, 0, 0);
  function klKapsel(fn){
    const alt = {speicher: store.alles(), st: Spiel._st, einst: Spiel._einst, lz: Spiel._lz, trocken: Spiel._trocken,
                 uhr: jetzt(), gen: Object.assign({}, Spiel.generierte)};
    try {
      jetzt.setzen(KL_T0);
      store.set("einst", {});
      Spiel._einst = null; Spiel._trocken = false; Spiel.neu();
      return fn();
    } finally {
      Spiel.generierte = alt.gen;
      for (const k of Object.keys(SPEICHER.daten)) delete SPEICHER.daten[k];
      Object.assign(SPEICHER.daten, alt.speicher);
      Spiel._st = alt.st; Spiel._einst = alt.einst; Spiel._lz = {}; Spiel._trocken = alt.trocken;
      jetzt.setzen(alt.uhr); jetzt.frei();
    }
  }
  /* Eine Sitzung anlegen, wie es die Lehrkraft tut (echter Codec, echter Speicher). */
  function klSitzung(ticketId){
    const s = Spiel.klassenraum.erzeugen({ticketId: ticketId || "salon-terminal"});
    if (!s || s.fehler) throw new Error("Sitzung ließ sich nicht anlegen: " + ((s && s.grund) || "?"));
    return s;
  }
  /* Einen ECHTEN Ergebnis-Code bauen (A: `ergebnisCode(inst, abnahme)`) – nie einen erfundenen. */
  const klErgebnis = (sitzung, platz, sterne, zeitMs, abnahmen) =>
    Spiel.klassenraum.ergebnisCode({klassenraum: {sitzung, platz}, zeitMs, abnahmen: abnahmen || 1}, {bestanden: true, sterne});

  /* ================= WÄCHTER DER NUTZERENTSCHEIDUNG (3.0, Säule 5) =================
     „Lehreraufträge werden NICHT bewertet" — keine Note, keine Punkte, keine Rangfolge, kein
     Vergleich zwischen Azubis. Das ist keine Anzeige-Frage, sondern eine Entscheidung, und deshalb
     bewacht sie ein TEST, keine Vereinbarung (Konzept Säule 5: „Das höchste Risiko im ganzen
     Konzept — sobald eine Lehrkraft sieht, WER hängt, ist die Bewertung nur ein kleiner Schritt").
     Beide Helfer stehen absichtlich im Test und nicht im Produktivcode: der Wächter soll die
     Anzeige prüfen, nicht ein Teil von ihr sein. */
  const KL_PERSONEN = /name|schueler|schüler|note|zensur|rang|bewertung|punkte/i;
  /* Personenbezogene FELDER in einem Datensatz (Sitzung, Ergebnissatz) — Namen, Noten, Ränge. */
  const klPersonenFelder = obj => Object.keys(obj || {}).filter(k => KL_PERSONEN.test(k));
  /* Personenbezogene WÖRTER im DOM: jedes Attribut und der gesamte Text des Baums. */
  function klPersonenWoerter(el){
    const treffer = [];
    if (KL_PERSONEN.test(klText(el))) treffer.push(klText(el).slice(0, 80));
    const lauf = k => {
      for (const [n, w] of Object.entries(k.attrs || {})) if (KL_PERSONEN.test(String(w))) treffer.push(`${n}="${String(w).slice(0, 40)}"`);
      for (const kind of k.kinder) if (kind && kind.tag) lauf(kind);
    };
    lauf(el);
    return treffer;
  }

  /* ================= HILFECODE-VERTRAG (task-56) =================
     `Spiel.klassenraum.hilfeCode(inst)` → "H-XXXX-XX", `hilfeLesen(code)` → {ok, sitzung, platz,
     schritt, offen} bzw. {fehler, grund}. Ist die echte API da, wird SIE benutzt — nichts ersetzt.
     Fehlt sie noch, prüft dieser Test die Oberfläche gegen genau diesen Vertrag (Attrappen), und
     die Attrappen werden im `finally` WIEDER ENTFERNT: kein Test verändert die Welt für die
     folgenden Dateien (Lehre aus dem wiki-2-Befund vom 10.10.2026). */
  const KL_HILFE_STUB = "H-2M7K-9Q";
  const klOhneStriche = s => String(s == null ? "" : s).trim().toUpperCase().replace(/-/g, "");
  function klMitHilfeApi(fn){
    const K = Spiel.klassenraum;
    if (typeof K.hilfeCode === "function" && typeof K.hilfeLesen === "function") return fn({echt: true});
    const hatteCode = Object.prototype.hasOwnProperty.call(K, "hilfeCode");
    const hatteLesen = Object.prototype.hasOwnProperty.call(K, "hilfeLesen");
    const altCode = K.hilfeCode, altLesen = K.hilfeLesen;
    if (!hatteCode) K.hilfeCode = inst => (inst && inst.klassenraum)
      ? KL_HILFE_STUB : {fehler: "auftrag", grund: "Es ist kein Klassenraum-Auftrag offen."};
    if (!hatteLesen) K.hilfeLesen = code => klOhneStriche(code) === klOhneStriche(KL_HILFE_STUB)
      ? {ok: true, sitzung: 0, platz: 7, schritt: 2, offen: 3}
      : {fehler: "prüfziffer", grund: "Dieser Hilfecode ist nicht gültig."};
    try { return fn({echt: false}); }
    finally {
      if (hatteCode) K.hilfeCode = altCode; else delete K.hilfeCode;
      if (hatteLesen) K.hilfeLesen = altLesen; else delete K.hilfeLesen;
    }
  }

  if (!KL_KLAR.laden) { pruefe("Klassenraum-Ansichten: nur unter node tests/run.js prüfbar", () => { erwarte.wahr(false, "require fehlt"); }); return; }

  pruefe("Der Codec aus Bereich A ist da — ohne ihn prüft diese Datei nichts", () => klKapsel(() => {
    erwarte.wahr(KL_KLAR.codec, "Spiel.klassenraum.ausCode fehlt (src/spiel/klassenraum.js)");
    erwarte.gleich(typeof Spiel.klassenraum.erzeugen, "function", "erzeugen");
    erwarte.gleich(typeof Spiel.klassenraum.ergebnisEintragen, "function", "ergebnisEintragen");
  }));

  pruefe("Beide Ansichten melden sich in EINEM Haken an — Titel, Symbole, Einstellungen, Bus (B § 1.2, § 11)", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    erwarte.gleich(p.registriert.map(r => r.name), ["klassenraum", "mitarbeit"], "Lehrkraft zuerst, dann der Azubi");
    const lehrer = p.registriert[0].def, schueler = p.registriert[1].def;
    erwarte.gleich([lehrer.titel, lehrer.symbol], ["Klasse", "kunden"], "Andock-Knopf der Lehrkraft");
    erwarte.gleich([schueler.titel, schueler.symbol], ["Auftrag", "akte"], "Andock-Knopf des Azubi");
    erwarte.gleich([typeof lehrer.zeigen, typeof lehrer.wieder, typeof schueler.zeigen, typeof schueler.wieder],
      ["function", "function", "function", "function"], "zeigen und wieder für beide");
    erwarte.gleich(p.abschnitte.map(a => a.titel), ["Klassenraum"], "der Einstellungsabschnitt");
    erwarte.gleich(p.busHaken.map(b => b.art), ["ansicht", "zustand-geaendert", "spiel-geladen", "klassenraum"], "die Bus-Hörer");
  }));

  pruefe("Lehrkraft: Sitzung anlegen zeigt den Code GROSS, kopierbar — und er kommt aus erzeugen (B § 2.1)", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(0);
    erwarte.gleich(klFinde(c, "button").length, 4, "vier Knöpfe: Code anzeigen, Code kopieren, Eintragen, Datei…");
    p.K._L.auftrag.value = "id:salon-terminal";
    klKnopf(c, "Code anzeigen").click();
    const s = Spiel.klassenraum.sitzung();
    erwarte.wahr(!!s, "die Sitzung läuft");
    erwarte.passt(s.code, /^NL-[0-9A-Z]{4}-[0-9A-Z]{2}$/, "der gedruckte Code hat die Form NL-XXXX-XX");
    const gross = klFinde(c, ".kl-gross")[0];
    erwarte.wahr(!!gross, "die Beamer-Zeile steht da");
    erwarte.gleich(klText(gross), s.code, "und zeigt genau den Code aus erzeugen");
    klKnopf(c, "Code kopieren").click();
    erwarte.gleich(p.rufe.filter(r => r[0] === "kopieren").map(r => r[1]), [s.code], "kopiert wird derselbe Code");
  }));

  /* KLR-03 (W2): Die Lehrkraft-Auswahl bot 76 Aufträge an, der 6-Bit-Codec adressiert nur 58 –
     18 Optionen scheiterten erst nach dem Klick. Jetzt kommen die Optionen aus der Codec-Tabelle,
     mit sichtbarem Hinweis auf die Formatgrenze (3.1). */
  pruefe("KLR-03: die Lehrkraft sieht nur die 58 per Code adressierbaren Aufträge (Formatgrenze 3.1)", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(0);
    const tab = Spiel.klassenraum.tabellen();
    const ids = tab.auftraege.ids.slice();
    erwarte.gleich(ids.length, 58, "die Codec-Tabelle bleibt bei 58 Aufträgen (STAND-Ausnahme)");
    const optionen = klFinde(c, "option").filter(o => String(o.value || "").startsWith("id:"));
    erwarte.gleich(optionen.length, ids.length, "die Auswahl bietet genau die adressierbaren Aufträge an");
    erwarte.gleich(optionen.map(o => String(o.value).slice(3)), ids, "in Codec-Reihenfolge, keine Fremden");
    /* Gegenprobe: ein nicht adressierbarer Auftrag steht NICHT in der Auswahl. */
    const fremd = (DATEN.tickets || []).map(t => t.id).find(id => !ids.includes(id));
    erwarte.wahr(!!fremd, "es gibt nicht adressierbare Aufträge (Gegenprobe möglich)");
    erwarte.falsch(optionen.some(o => String(o.value) === "id:" + fremd), "nicht adressierbarer Auftrag fehlt in der Auswahl: " + fremd);
    /* Jede angebotene Option liefert wirklich einen Auftrag (frischer Speicher je Code). */
    const kaputt = [];
    for (const id of ids){
      store.set("klassenraum", null);
      const r = Spiel.klassenraum.erzeugen({ticketId: id});
      if (!r || r.fehler) kaputt.push(id + ": " + ((r && r.grund) || "?"));
    }
    erwarte.gleich(kaputt, [], "jede angebotene Option erzeugt einen Auftrag ohne Fehler");
    /* Der Hinweis auf die Formatgrenze steht sichtbar in der Ansicht. */
    const text = klText(c);
    erwarte.enthaelt(text, "Formatgrenze", "der Hinweis nennt die Formatgrenze");
    erwarte.enthaelt(text, "3.1", "und den Formatwechsel 3.1");
    erwarte.enthaelt(text, String(ids.length), "mit der Zahl der adressierbaren Aufträge");
  }));

  pruefe("Lehrkraft: sechs sichtbare Bedienelemente, Azubi: drei — mehr gibt es nicht (B § 2.1/2.2, R12)", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const steuer = c => klFinde(c, "button").length + klFinde(c, "select").length + klFinde(c, "input").length + klFinde(c, "textarea").length;
    erwarte.gleich(steuer(p.zeige(0)), 6, "select, Code anzeigen, Code kopieren, textarea, Eintragen, Datei…");
    erwarte.gleich(steuer(p.zeige(1)), 3, "Auftragscode, Platz, Auftrag öffnen — die Azubi-Ansicht hat ihre EIGENE Grenze 3 (B § 2.2)");
  }));

  pruefe("Ampel: 0 Ergebnisse dunkel, halb voll gelb, alles grün — Median ist der OBERERE (B § 9)", () => klKapsel(() => {
    const K = klPruefstand().K;
    const leer = K.ampel({ergebnisse: {}, plaetze: 4});
    erwarte.gleich([leer.farbe, leer.summe], ["", "Ampel: noch keine Abgaben"], "ohne Abgabe dunkel (task-115: Abgabe-Wort)");
    /* KLR-10: gültige Plätze 1..4 — Plätze außerhalb der Klassenstärke zählen nicht als fertig. */
    const zwei = K.ampel({plaetze: 4, ergebnisse: {1: {platz: 1, sterne: 4, dauerS: 250}, 2: {platz: 2, sterne: 5, dauerS: 260}}});
    erwarte.gleich(zwei.farbe, "kl-gelb", "halb voll ist gelb");
    erwarte.enthaelt(zwei.summe, "fertig 2", "zwei Plätze belegt");
    erwarte.enthaelt(zwei.summe, "offen 2", "zwei fehlen");
    erwarte.enthaelt(zwei.summe, "Median 4:20", "oberer Median (250, 260) → 4:20, nicht 4:15");
    /* grün: so viele Ergebnisse wie Plätze, keins außerhalb 1..plaetze */
    const voll = K.ampel({plaetze: 2, ergebnisse: {1: {platz: 1, sterne: 4, dauerS: 110}, 2: {platz: 2, sterne: 5, dauerS: 70}}});
    erwarte.gleich([voll.farbe, voll.offen], ["kl-gruen", 0], "alle Plätze belegt ist grün");
    const ohne = K.ampel({ergebnisse: {5: {platz: 5, sterne: 4}}});
    erwarte.gleich(ohne.farbe, "kl-gelb", "ohne Platzzahl bleibt gelb");
    erwarte.enthaelt(ohne.summe, "Plätze nicht eingestellt", "und sagt das, statt zu raten");
    const ausfall = K.ampel({plaetze: 8, ergebnisse: {0: {platz: 0, sterne: 1}, 5: {platz: 5, sterne: 4, dauerS: 110}, 7: {platz: 7, sterne: 4, dauerS: 0}}});
    erwarte.enthaelt(ausfall.summe, "1 Abgabe ohne gültigen Platz", "Platz 0 zählt als ausgefallen (Einzahl, neue Fläche: Abgabe)");
    erwarte.enthaelt(ausfall.summe, "Median 1:50", "eine fehlende Dauer (0) zählt nicht für den Median");
    erwarte.gleich(ausfall.farbe, "kl-gelb", "mit Ausfall nicht grün");
  }));

  pruefe("Block-Eingabe: Zerlegung, Doppelte, Tafel und Summenzeile (B § 8, § 3.4)", () => klKapsel(() => {
    const p = klPruefstand();
    /* Diese Zeichenketten werden NUR zerlegt (Trenner, Zeilennummern) – sie werden nie eingetragen,
       also nie gegen den Codec geprüft. Die echten Codes weiter unten kommen aus `erzeugen`. */
    const stuecke = p.K.zerlegen("E-CBUD-RX5, E-KFWS-HZM\n\nE-AAAA-BBB;E-CCCC-DDD");
    erwarte.gleich(stuecke.map(s => s.stueck), ["E-CBUD-RX5", "E-KFWS-HZM", "E-AAAA-BBB", "E-CCCC-DDD"], "Bindestriche sind keine Trenner");
    erwarte.gleich(stuecke.map(s => s.zeile), [1, 1, 3, 3], "die Zeilennummer ist die Fehleradresse");
    p.start();
    const c = p.zeige(0);
    const s = klSitzung("salon-terminal");
    p.K.lehrerWieder();
    const e5 = klErgebnis(s.id, 5, 4.5, 110000, 2), e9 = klErgebnis(s.id, 9, 5, 70000, 1);
    p.K._L.codes.value = `${e5}\n${e5}\n${e9}\nE-CCCC-DDD`;
    klKnopf(c, "Eintragen").click();
    const hinweis = klFinde(c, ".kl-hinweis").map(x => klText(x)).join(" | ");
    erwarte.enthaelt(hinweis, "2 eingetragen", "zwei gültige Codes");
    erwarte.enthaelt(hinweis, "doppelt", "derselbe Code zweimal ist doppelt");
    erwarte.enthaelt(hinweis, "1 unlesbar", "der kaputte Code wird als unlesbar gezählt");
    /* KLR-12: Sitzungsliste nutzt dieselbe Zeilen-Klasse — die Tafel wird im Tafel-Behälter gezählt. */
    const zeilen = klFinde(p.K._L.tafel, ".kl-zeile");
    erwarte.gleich(zeilen.length, 2, "die Tafel zeigt zwei Ergebnisse");
    erwarte.enthaelt(klText(zeilen[0]), "Platz 5", "erste Zeile: Platz 5");
    erwarte.enthaelt(klText(zeilen[0]), "1:50", "mit Dauer 1:50 (110 s)");
    erwarte.enthaelt(klText(zeilen[0]), "1 Fehlversuch", "und dem Fehlversuch");
    erwarte.enthaelt(klText(zeilen[1]), "★★★★★", "zweite Zeile: fünf Sterne");
    erwarte.enthaelt(klText(zeilen[1]), "1:10", "und 70 s");
    erwarte.gleich(p.K._L.codes.value, "", "das Feld ist danach leer");
    /* Gegenprobe: der zweite Durchgang ist gefahrlos (idempotent) */
    p.K._L.codes.value = e5;
    klKnopf(c, "Eintragen").click();
    erwarte.enthaelt(klFinde(c, ".kl-hinweis").map(x => klText(x)).join(" | "), "0 eingetragen · 1 doppelt", "derselbe Code ändert nichts");
  }));

  pruefe("Azubi: Tippfehler wird MARKIERT und öffnet NICHT — gültiger Code öffnet über den echten Weg (B § 6.1)", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(1);
    const form = klFinde(c, "form")[0];
    erwarte.wahr(!!form, "das Formular steht da");
    erwarte.gleich(klFinde(c, "input").map(i => i.getAttribute("type")), ["text", "text"], "zwei Textfelder, KEIN type=search");
    const s = klSitzung("salon-terminal");
    const kaputt = s.code.slice(0, -1) + (s.code.endsWith("A") ? "B" : "A");
    /* Tippfehler: markiert, A's Grund wörtlich, nichts geöffnet */
    p.K._A.code.value = kaputt;
    form.ausloesen("submit");
    erwarte.gleich(p.rufe.filter(r => r[0] === "spiel-oeffnen").length, 0, "kein Auftrag geöffnet");
    erwarte.gleich(p.K._A.code.getAttribute("aria-invalid"), "true", "das Feld ist markiert");
    const grund = Spiel.klassenraum.ausCode(kaputt).grund;
    erwarte.enthaelt(klText(p.K._A.hinweis), String(grund).slice(0, 24), "A's Grund steht wörtlich da (keine zweite Wahrheit)");
    /* Das FORMBEISPIEL aus A § 1.4 ist kein gültiger Code — es muss die Fehlermeldung zeigen. */
    p.K._A.code.value = "NL-4F7K-2Q";
    form.ausloesen("submit");
    erwarte.gleich(p.rufe.filter(r => r[0] === "spiel-oeffnen").length, 0, "das Formbeispiel öffnet nichts");
    erwarte.gleich(p.K._A.code.getAttribute("aria-invalid"), "true", "und wird markiert");
    /* leer: keine Meldung, kein Öffnen */
    p.K._A.code.value = "   ";
    form.ausloesen("submit");
    erwarte.gleich(p.rufe.filter(r => r[0] === "spiel-oeffnen").length, 0, "leer öffnet nichts");
    /* gültig: der echte Weg */
    p.K._A.code.value = s.code;
    p.K._A.platz.value = "7";
    form.ausloesen("submit");
    erwarte.gleich(p.rufe.filter(r => r[0] === "spiel-oeffnen").length, 1, "genau ein Auftrag geöffnet");
    const inst = Spiel.st.postfach[Spiel.st.postfach.length - 1];
    erwarte.gleich(inst.quelle, "klassenraum", "vierte Quelle");
    erwarte.gleich(inst.klassenraum.platz, 7, "der Platz aus dem Feld steht an der Instanz");
    erwarte.gleich(inst.klassenraum.code, s.code, "der Code steht an der Instanz");
    erwarte.gleich(Spiel.klassenraum.platz(), 7, "und ist im Speicher gemerkt (für den Ergebnis-Code)");
  }));

  pruefe("Bildungsstand bleibt unangetastet (E3) — die Ansage überstimmt ihn nicht", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    Spiel.stufe.setzen("geselle", {still: true});
    const c = p.zeige(1);
    const s = klSitzung("salon-terminal");
    p.K._A.code.value = s.code;
    klFinde(c, "form")[0].ausloesen("submit");
    erwarte.gleich(Spiel.stufe.id(), "geselle", "der Bildungsstand ist unverändert");
    erwarte.gleich(p.rufe.filter(r => r[0] === "spiel-oeffnen").length, 1, "und der Auftrag ist trotzdem offen");
  }));

  pruefe("Startseiten-Zeile hängt sich in den Hub — über den Bus, ohne hub.js (B § 4, L5)", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    erwarte.gleich(klFinde(p.seite, ".kl-start").length, 1, "die Zeile steht in .hb-seite");
    erwarte.gleich(klFinde(p.seite, ".kl-start-feld")[0].getAttribute("placeholder"), "NL-4F7K-2Q", "mit dem Code-Platzhalter");
    const knopf = klFinde(p.seite, "button")[0];
    erwarte.gleich(knopf.className.split(" ").includes("primaer"), false, "kein primaer (Rauchtest haupt())");
    erwarte.gleich(knopf.className.split(" ").includes("hb-annehmen"), false, "und kein hb-annehmen");
    p.K.startEinhaengen();
    erwarte.gleich(klFinde(p.seite, ".kl-start").length, 1, "zweimal einhängen ergibt eine Zeile");
    const feld = klFinde(p.seite, ".kl-start-feld")[0];
    const s = klSitzung("salon-terminal");
    feld.value = s.code.slice(0, -1) + (s.code.endsWith("A") ? "B" : "A");
    knopf.click();
    erwarte.gleich(p.rufe.filter(r => r[0] === "toast").length, 0, "kein Toast auf der Startseite");
    erwarte.gleich(klFinde(p.seite, ".kl-hinweis").length, 1, "die Fehlerzeile steht unter dem Feld");
    erwarte.enthaelt(klText(klFinde(p.seite, ".kl-hinweis")[0]), "Prüfziffer", "mit A's Grund");
    feld.value = s.code;
    knopf.click();
    erwarte.gleich(p.rufe.filter(r => r[0] === "spiel-oeffnen").length, 1, "gültiger Code öffnet auch von hier");
    /* Neuaufbau des Hubs wirft die Zeile weg — der Haken hängt sie frisch wieder ein (Spiel.neu). */
    p.seite.replaceChildren();
    erwarte.gleich(klFinde(p.seite, ".kl-start").length, 0, "nach dem Neuaufbau ist sie weg");
    p.busHaken.find(b => b.art === "zustand-geaendert").fn();
    erwarte.gleich(klFinde(p.seite, ".kl-start").length, 1, "der Haken hängt sie wieder ein");
  }));

  pruefe('„Datei…“ benutzt den Hausdialog mit Escape statt eines eigenen Overlays (B § 10, app.js:246-265)', () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(0);
    klSitzung("salon-terminal");
    klKnopf(c, "Datei…").click();
    erwarte.gleich(p.dialoge.length, 1, "genau ein Dialog");
    erwarte.gleich(klFinde(c, ".sp-overlay").length, 0, "kein eigenes Overlay in der Ansicht");
    erwarte.gleich(p.dialoge[0].titel, "Klassenraum-Datei", "mit Titel");
    erwarte.wahr(!!klKnopf(p.dialoge[0].inhalt, "Exportieren"), "Export im Dialog");
    erwarte.wahr(!!klKnopf(p.dialoge[0].inhalt, "Importieren"), "Import im selben Dialog");
    klKnopf(p.dialoge[0].inhalt, "Exportieren").click();
    erwarte.gleich(p.exporte.length, 1, "der Export schreibt eine Datei");
    erwarte.passt(p.exporte[0][0], /^klassenraum-\d{4}-\d{2}-\d{2}\.json$/, "Name mit Datum (B § 10.2)");
    erwarte.gleich(JSON.parse(p.exporte[0][1]).format, "netzwerk-labor/klassenraum", "und dem Format der Sitzung");
    p.dokument.listeners.keydown[0]({key: "Escape"});
    erwarte.gleich(p.dialoge[0].zu, true, "Escape schließt den Dialog");
  }));

  pruefe('Ergebnis-Code kommt über den Bus-Kanal „klassenraum“ — dezent als Toast (B § 7)', () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const s = klSitzung("salon-terminal");
    const code = klErgebnis(s.id, 5, 5, 110000, 1);
    p.busHaken.find(b => b.art === "klassenraum").fn({code});
    const toasts = p.rufe.filter(r => r[0] === "toast");
    erwarte.gleich(toasts.length, 1, "genau ein Toast");
    erwarte.enthaelt(toasts[0][1], code, "mit dem fertigen Code");
    erwarte.gleich(toasts[0][2], "ok", "als Erfolg, nicht als Fehler");
    erwarte.gleich(toasts[0][3].id, "klassenraum-code", "feste id: ein zweiter ersetzt den ersten");
    erwarte.gleich(toasts[0][3].titel, "Für die Lehrkraft", "mit Titel");
    toasts[0][3].aktion.fn();
    erwarte.gleich(p.rufe.filter(r => r[0] === "kopieren").map(r => r[1]), [code], "der Kopier-Knopf kopiert den Code");
    /* Ohne Code im Ereignis: kein Toast, kein Fehler (kein Verrat, keine Erfindung) */
    p.busHaken.find(b => b.art === "klassenraum").fn({art: "erzeugt", code: null});
    erwarte.gleich(p.rufe.filter(r => r[0] === "toast").length, 1, "ohne Code bleibt es still");
  }));

  /* VIS-04 (§ 12.6): Der Schalter „Klassenraum-Server“ war wirkungslos — er schrieb nur die
     Einstellung klassenraumServer, niemand las sie; Server und QR sind in 3.0 nicht gebaut. Statt
     eines Schalters ohne Wirkung steht jetzt ein ehrlicher Hinweis auf 3.1. */
  pruefe("VIS-04: kein wirkungsloser Klassenraum-Server-Schalter – ehrlicher 3.1-Hinweis (§ 12.6)", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const el = klKnoten("div");
    p.abschnitte[0].fn(el);
    erwarte.gleich(klFinde(el, ".einst-zeile").length, 1, "eine Haus-Zeile bleibt");
    erwarte.gleich(klFinde(el, ".schalter").length, 0, "kein Schalter ohne Wirkung");
    erwarte.gleich(klFinde(el, "button").length + klFinde(el, "input").length, 0, "gar kein Bedienelement in diesem Abschnitt");
    erwarte.enthaelt(klText(el), "Klassenraum-Server", "der Gegenstand wird weiter benannt");
    erwarte.enthaelt(klText(el), "nicht gebaut", "der Text sagt ehrlich, dass der Server fehlt");
    erwarte.enthaelt(klText(el), "3.1", "und nennt die Fassung, in der er kommt");
    erwarte.enthaelt(klText(el), "Ergebnis-Codes", "der Weg ohne Server (Codes abtippen) bleibt erklärt");
    erwarte.gleich(store.get("einst", {}).klassenraumServer, undefined, "die tote Einstellung wird nicht mehr geschrieben");
  }));

  pruefe("Der Abdruck der Lehrkraft sagt, WESSEN Netz er zeigt (Vorführlauf-Befund 10.10.2026)", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(0);
    const detail = klFinde(c, ".kl-detail").map(x => klText(x));
    erwarte.enthaelt(detail.join(" | "), "Klassenraum-Abdruck (dein geladenes Netz)", "die Beschriftung nennt das eigene Netz");
    const hinweis = klFinde(c, ".kl-hinweis").map(x => klText(x)).join(" | ");
    erwarte.enthaelt(hinweis, "eigenes Labor", "und der Hinweis sagt, wessen Abdruck das ist");
    erwarte.enthaelt(hinweis, "dasselbe Auftragsnetz geladen", "mit der Bedingung, wann beide gleich sind");
    /* die Zahl der Bedienelemente bleibt bei sechs — die Ehrlichkeit kostet keinen Knopf (R12) */
    erwarte.gleich(klSteuerAusserListe(p, c), 6, "weiterhin sechs sichtbare Bedienelemente (ohne Sitzungsliste)");
  }));

  pruefe("Auftrag erzeugen meldet KEINEN Ergebnis-Code — auch kein NL-… in `code` (B § 7, Kanal kontrakt)", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const s = klSitzung("salon-terminal");
    const kanal = d => p.busHaken.find(b => b.art === "klassenraum").fn(d);
    const toasts = () => p.rufe.filter(r => r[0] === "toast").length;
    kanal({art: "erzeugt", sitzung: s.id, auftragscode: s.code});        /* so meldet die Quelle den Auftragscode */
    erwarte.gleich(toasts(), 0, "Auftrag erzeugen ist kein Ergebnis");
    kanal({art: "ergebnis", platz: 5});                                  /* Ergebnis eingetragen, aber ohne Code */
    erwarte.gleich(toasts(), 0, "das Eintragen meldet keinen Code");
    kanal({art: "import", sitzung: s.id});
    kanal({art: "plaetze", plaetze: 9});
    erwarte.gleich(toasts(), 0, "Import und Platzzahl erst recht nicht");
    /* die alte, irreführende Form: Auftragscode im Feld `code` — genau der Vorführlauf-Befund */
    kanal({art: "erzeugt", sitzung: s.id, code: s.code});
    erwarte.gleich(toasts(), 0, "ein NL-…-Code wird vom Codec als Ergebnis abgewiesen");
    kanal({bestanden: false, sterne: 0, code: null});                    /* nicht bestanden: kein Code */
    erwarte.gleich(toasts(), 0, "ohne Bestehen gibt es keinen Ergebnis-Code");
  }));

  pruefe("Abnahme bestanden: GENAU EIN Toast, und zwar mit dem E-…-Code aus `code` (B § 7)", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const s = klSitzung("salon-terminal");
    const code = klErgebnis(s.id, 5, 4.5, 110000, 2);
    erwarte.passt(code, /^E-[0-9A-Z]{4}-[0-9A-Z]{3}$/, "der Codec baut einen Ergebnis-Code der gedruckten Form");
    /* Die Abnahme-Meldung trägt BEIDES: den Auftragscode (neues Feld) und den Ergebnis-Code (`code`) */
    p.busHaken.find(b => b.art === "klassenraum").fn({iid: "i1", bestanden: true, sterne: 4.5, auftragscode: s.code, code});
    const toasts = p.rufe.filter(r => r[0] === "toast");
    erwarte.gleich(toasts.length, 1, "genau ein Toast");
    erwarte.enthaelt(toasts[0][1], code, "mit dem Ergebnis-Code");
    erwarte.falsch(String(toasts[0][1]).includes(s.code), "nicht mit dem Auftragscode");
    erwarte.gleich(toasts[0][2], "ok", "als Erfolg");
    erwarte.gleich(toasts[0][3].id, "klassenraum-code", "mit fester id");
    erwarte.gleich(toasts[0][3].titel, "Für die Lehrkraft", "und Titel");
  }));

  pruefe("Diagnose ohne Bewertung: anonyme Fortschrittszahlen in der Ampel-Region (3.0, Säule 5, Weg A)", () => klKapsel(() => {
    const p = klPruefstand();
    const T = KL_T0;
    /* 20 Plätze, 13 Abgaben → 7 offen. Drei Abgaben im letzten Fenster, die jüngste vor zwei Minuten. */
    const ergebnisse = {};
    for (let i = 1; i <= 10; i++) ergebnisse[i] = {platz: i, sterne: 4, dauerS: 60 + i, versuche: 0, zeit: T - 60 * 60 * 1000};
    ergebnisse[12] = {platz: 12, sterne: 4, dauerS: 120, versuche: 0, zeit: T - 4 * 60 * 1000};
    ergebnisse[13] = {platz: 13, sterne: 5, dauerS: 90, versuche: 0, zeit: T - 3 * 60 * 1000};
    ergebnisse[14] = {platz: 14, sterne: 5, dauerS: 80, versuche: 0, zeit: T - 2 * 60 * 1000};
    const a = p.K.ampel({plaetze: 20, ergebnisse}, T);
    erwarte.enthaelt(a.fortschritt, "7 von 20 offen", "die offenen Plätze MIT der Klassengröße");
    erwarte.enthaelt(a.fortschritt, "3 Abgaben in den letzten 5 Minuten", "die Abgaben des letzten Fensters");
    erwarte.enthaelt(a.fortschritt, "letzte Abgabe vor 2 Minuten", "und wie frisch die jüngste ist");
    erwarte.falsch(a.fortschritt.includes("Median"), "der Median steht schon in der Ampel — die Zeile wiederholt ihn nicht");
    erwarte.falsch(KL_PERSONEN.test(a.fortschritt), "und kein personenbezogenes Wort steht in der Zeile");
    /* Ohne Uhr wird keine Zeit behauptet — die Rechnung ist prüfbar, nicht „ungefähr jetzt". */
    const ohneUhr = p.K.ampel({plaetze: 20, ergebnisse});
    erwarte.enthaelt(ohneUhr.fortschritt, "7 von 20 offen", "die Zahl der Offenen braucht keine Uhr");
    erwarte.falsch(ohneUhr.fortschritt.includes("Minute"), "ohne Uhr keine Zeitaussage");
    /* Im DOM: die Zeile steht in der Ampel-Region — und es bleibt bei sechs Bedienelementen (R12). */
    p.start();
    const c = p.zeige(0);
    klSitzung("salon-terminal");
    Spiel.klassenraum.plaetzeSetzen(20);
    p.K.lehrerWieder();
    erwarte.enthaelt(klText(klFinde(c, ".kl-ampel")[0]), "Fortschritt: 20 von 20 offen", "die Diagnose steht in der Ampel-Region");
    erwarte.gleich(klSteuerAusserListe(p, c), 6, "kein neues Dauer-Bedienelement — außerhalb der Liste sechs");
  }));

  pruefe("Wächter: kein personenbezogenes FELD in Sitzung und Ergebnissen (3.0, Säule 5)", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const s = klSitzung("salon-terminal");
    erwarte.gleich(Object.keys(s).length, 16, "die Sitzung führt sechzehn Felder (3.0.0: diagnose neu, KLR-05a)");
    erwarte.gleich(Object.keys(s).sort().join(","),
      "art,code,dauerMin,diagnose,eigene,ergebnisse,erstellt,id,index,plaetze,schritte,seed,skill,ticketId,titel,variante",
      "genau diese sechzehn — kein Namens-, Noten- oder Rangfeld");
    /* KLR-05a (§ 12.2): diagnose ist ein anonymes Histogramm {schritt: anzahl} — kein Platz, kein Name. */
    erwarte.gleich(Object.keys(s.diagnose || {}).every(k => /^\d+$/.test(k)), true, "diagnose trägt nur Schritt-Zähler");
    erwarte.gleich(klPersonenFelder(s.diagnose || {}), [], "auch diagnose ist nicht personenbezogen");
    erwarte.gleich(klPersonenFelder(s), [], "kein Feld der Sitzung ist personenbezogen");
    /* Einen ECHTEN Ergebnissatz erzeugen und seine Felder prüfen. */
    const r = Spiel.klassenraum.ergebnisEintragen(klErgebnis(s.id, 5, 4, 80000, 1));
    erwarte.gleich(r.ok, true, "das Ergebnis ist eingetragen");
    const eintrag = Object.values(Spiel.klassenraum.sitzung().ergebnisse)[0];
    erwarte.gleich(Object.keys(eintrag).length, 7, "ein Ergebnissatz führt sieben Felder");
    erwarte.gleich(Object.keys(eintrag).sort().join(","), "code,dauerS,platz,quelle,sterne,versuche,zeit",
      "genau diese sieben — kein Name, keine Note");
    erwarte.gleich(klPersonenFelder(eintrag), [], "kein personenbezogenes Feld im Ergebnissatz");
    /* GEGENPROBE: der Wächter ist scharf — eingeschmuggelt heißt gefunden. */
    erwarte.gleich(klPersonenFelder({platz: 5, sterne: 4, name: "Anna", note: 2, rang: 1}), ["name", "note", "rang"],
      "ein eingeschmuggeltes Feld wird gefunden (sonst wäre der Wächter nur eine Behauptung)");
  }));

  pruefe("Wächter: kein personenbezogenes WORT im DOM der Lehrkraft-Ansicht (3.0, Säule 5)", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(0);
    const s = klSitzung("salon-terminal");
    Spiel.klassenraum.plaetzeSetzen(20);
    Spiel.klassenraum.ergebnisEintragen(klErgebnis(s.id, 5, 4, 80000, 1));
    p.K.lehrerWieder();
    erwarte.gleich(klPersonenWoerter(c), [], "kein Name, keine Note, kein Rang, keine Punkte im DOM der Ansicht");
    /* GEGENPROBE: dasselbe eingeschmuggelt in den DOM — der Wächter muss es finden. */
    const schmuggel = klKnoten("span");
    schmuggel.textContent = "Anna · 2 Punkte";
    c.append(schmuggel);
    erwarte.wahr(klPersonenWoerter(c).length > 0, "der Wächter findet den Schmuggel im DOM");
  }));

  pruefe('„Ich hänge" für die Auftragsmappe: EIN Knopf zeigt den Code und kopiert ihn (3.0, Säule 5)', () => klKapsel(() => klMitHilfeApi(() => {
    const p = klPruefstand();
    p.start();
    /* 1 · ohne offenen Klassenraum-Auftrag: ehrliche Absage, kein erfundener Code */
    const kalt = p.K.hilfeKnopf();
    erwarte.gleich(klText(kalt), "Ich hänge", 'der Knopf heißt „Ich hänge"');
    kalt.click();
    const warnungen = p.rufe.filter(r => r[0] === "toast");
    erwarte.gleich(warnungen.length, 1, "genau eine Meldung");
    erwarte.enthaelt(warnungen[0][1], "kein Klassenraum-Auftrag offen", "und sie sagt ehrlich, dass es nichts zu melden gibt");
    erwarte.gleich(warnungen[0][2], "warn", "als Warnung, nicht als Erfolg");
    erwarte.gleich(klText(kalt), "Ich hänge", "der Knopf erfindet keinen Code");
    /* 2 · mit offenem Auftrag (echter Weg: Platzzahl, Code, Platz → öffnen) */
    const c = p.zeige(1);
    const s = klSitzung("salon-terminal");
    Spiel.klassenraum.plaetzeSetzen(20);
    const form = klFinde(c, "form")[0];
    p.K._A.code.value = s.code;
    p.K._A.platz.value = "7";
    form.ausloesen("submit");
    erwarte.gleich(p.rufe.filter(r => r[0] === "spiel-oeffnen").length, 1, "der Auftrag ist offen");
    const k = p.K.hilfeKnopf();
    k.click();
    erwarte.passt(klText(k), /^H-[0-9A-Z]{4}-[0-9A-Z]{2}$/, "der Knopf ZEIGT den echten Hilfecode");
    erwarte.gleich(p.rufe.filter(r => r[0] === "kopieren").map(r => r[1]), [klText(k)], "und kopiert ihn beim selben Klick");
    erwarte.gleich(klPersonenWoerter(k), [], "kein Name, keine Note, kein Rang am Knopf");
    /* 3 · zweiter Klick kopiert DENSELBEN Code noch einmal — der Zähler darf sich nicht heimlich ändern */
    const vorher = klText(k);
    k.click();
    erwarte.gleich(p.rufe.filter(r => r[0] === "kopieren").map(r => r[1]), [vorher, vorher], "zweiter Klick kopiert denselben Code");
    erwarte.gleich(klText(k), vorher, "und der Code bleibt stehen");
  })));

  pruefe("Lehrkraft: ein H-Code wird als Klartext gelesen und NIE als Ergebnis eingetragen (3.0, Säule 5)", () => klKapsel(() => klMitHilfeApi(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(0);
    const s = klSitzung("salon-terminal");
    Spiel.klassenraum.plaetzeSetzen(20);
    p.K.lehrerWieder();
    /* Einen ECHTEN Hilfecode bauen (nie einen erfundenen) und seine Zahlen vom Codec holen. */
    const inst = Spiel.instanzErstellen({ticketId: s.ticketId, seed: s.seed, quelle: "klassenraum", ohneFlow: true});
    inst.klassenraum = {sitzung: s.id, platz: 7, code: s.code};
    const hCode = Spiel.klassenraum.hilfeCode(inst);
    erwarte.passt(hCode, /^H-[0-9A-Z]{4}-[0-9A-Z]{2}$/, "der Codec baut einen Hilfecode der gedruckten Form");
    const gelesen = Spiel.klassenraum.hilfeLesen(hCode);
    erwarte.gleich(gelesen.ok, true, "und derselbe Code lässt sich wieder lesen");
    const erwartet = `Platz ${gelesen.platz} hängt: ${gelesen.schritt} von ${gelesen.schritt + gelesen.offen} Zielen erfüllt`;
    p.K._L.codes.value = hCode;
    klKnopf(c, "Eintragen").click();
    const aus = klFinde(c, ".kl-hinweis").map(x => klText(x)).join(" | ");
    erwarte.enthaelt(aus, erwartet, "der Hilfecode wird als Klartext gelesen (Platz und Zähler)");
    erwarte.enthaelt(aus, "1 Hilferuf gelesen", "die Summe nennt ihn Hilferuf, nicht Ergebnis");
    erwarte.falsch(aus.includes("1 eingetragen"), 'keine Zeile meldet ein eingetragenes Ergebnis');
    erwarte.enthaelt(aus, "0 eingetragen", "die Summe sagt ausdrücklich: nichts eingetragen");
    /* DIE Zusicherung: ein H-Code ist kein Ergebnis — der Ergebnissatz bleibt leer. */
    erwarte.gleich(Object.keys(Spiel.klassenraum.sitzung().ergebnisse).length, 0, "kein Ergebnis eingetragen");
    /* Auch klein und ohne Striche erkannt (die Lehrkraft tippt ab, was dasteht) — und weiter kein Ergebnis. */
    p.K._L.codes.value = hCode.replace(/-/g, "").toLowerCase();
    klKnopf(c, "Eintragen").click();
    erwarte.gleich(Object.keys(Spiel.klassenraum.sitzung().ergebnisse).length, 0, "auch klein/ohne Striche kein Ergebnis");
    /* Ein ABGESCHNITTENER H-Code geht den Hilfeweg (Präfix entscheidet) — mit A's Erklärung und
       weiterhin ohne Ergebnis. */
    p.K._L.codes.value = hCode.slice(0, 5);
    klKnopf(c, "Eintragen").click();
    erwarte.gleich(Object.keys(Spiel.klassenraum.sitzung().ergebnisse).length, 0, "ein kaputter H-Code wird nicht eingetragen");
    erwarte.enthaelt(klFinde(c, ".kl-hinweis").map(x => klText(x)).join(" | "), "1 unlesbar", "und als unlesbar gezählt");
    /* Und ein echter E-Code geht weiterhin durch — der H-Zweig frisst ihn nicht. */
    p.K._L.codes.value = klErgebnis(s.id, 5, 4, 80000, 1);
    klKnopf(c, "Eintragen").click();
    erwarte.gleich(Object.keys(Spiel.klassenraum.sitzung().ergebnisse).length, 1, "ein E-Code wird weiterhin eingetragen");
    erwarte.enthaelt(klFinde(c, ".kl-hinweis").map(x => klText(x)).join(" | "), "1 eingetragen", "und als eingetragen gemeldet");
  })));

  /* ================= KLR-01b: Sitzungsverwaltung in der Oberfläche (§ 12.1/§ 12.2) =================
     Eine neue Sitzung ersetzt die alte nicht still (P0 aus berichte/klassenraum.md): mit Ergebnissen
     fragt die Oberfläche vorher; Abbrechen lässt alles, wie es war. Die Auswahl liegt im bestehenden
     „Datei…“-Dialog (R12: keine neuen Sicht-Elemente); der Import ist eine VOLLSICHERUNG und ersetzt
     alle Sitzungen des Geräts erst nach Bestätigung. */
  pruefe("KLR-01b: neue Sitzung mit Ergebnissen nur nach Bestätigung – Abbrechen erhält die alte (P0)", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(0);
    const s1 = klSitzung("salon-terminal");
    Spiel.klassenraum.ergebnisEintragen(klErgebnis(s1.id, 5, 4, 80000, 1));
    p.K.lehrerWieder();
    p.K._L.auftrag.value = "id:salon-02";
    klKnopf(c, "Code anzeigen").click();
    erwarte.gleich(p.dialoge.length, 1, "die Warnung kommt als Hausdialog");
    erwarte.enthaelt(p.dialoge[0].titel, "Abgaben", "der Titel nennt den Grund (neuer Flow: Abgabe)");
    erwarte.gleich(Spiel.klassenraum.sitzung().code, s1.code, "ohne Bestätigung bleibt die alte Sitzung aktiv");
    erwarte.gleich(Spiel.klassenraum.sitzungen().length, 1, "und es entsteht keine zweite Sitzung");
    klKnopf(p.dialoge[0].inhalt, "Abbrechen").click();
    erwarte.gleich(p.dialoge[0].zu, true, "Abbrechen schließt den Dialog");
    erwarte.gleich(Spiel.klassenraum.sitzung().code, s1.code, "Abbrechen erhält die alte Sitzung");
    erwarte.gleich(Spiel.klassenraum.sitzungen().length, 1, "kein stiller Datenverlust");
    klKnopf(c, "Code anzeigen").click();
    erwarte.gleich(p.dialoge.length, 2, "die Warnung erscheint erneut");
    klKnopf(p.dialoge[1].inhalt, "Neue Sitzung anlegen").click();
    const jetzt = Spiel.klassenraum.sitzung();
    erwarte.wahr(!!jetzt && jetzt.code !== s1.code, "bestätigt: eine neue Sitzung ist aktiv");
    const alle = Spiel.klassenraum.sitzungen();
    erwarte.gleich(alle.length, 2, "die alte Sitzung bleibt in der Liste");
    const alt2 = alle.find(x => x.code === s1.code);
    erwarte.wahr(!!alt2 && Object.keys(alt2.ergebnisse || {}).length === 1, "samt ihrem einen Ergebnis erhalten");
  }));

  pruefe("KLR-01b: Datei-Dialog listet alle Sitzungen und wechselt über die echte API", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(0);
    const s1 = klSitzung("salon-terminal");
    Spiel.klassenraum.ergebnisEintragen(klErgebnis(s1.id, 3, 2, 30000, 1));
    Spiel.klassenraum.erzeugen({ticketId: "salon-02", bestaetigen: true});
    erwarte.gleich(Spiel.klassenraum.sitzungen().length, 2, "zwei Sitzungen auf dem Gerät");
    p.K.lehrerWieder();
    klKnopf(c, "Datei…").click();
    const inhalt = p.dialoge[0].inhalt;
    erwarte.enthaelt(klText(inhalt), "Sitzungen auf diesem Gerät: 2", "die Anzahl steht im Dialog");
    erwarte.enthaelt(klText(inhalt), "1 Abgabe", "je Sitzung die Zahl der Abgaben (neuer Flow: Abgabe)");
    const laden = klKnopf(inhalt, "Sitzung laden");
    erwarte.wahr(!!laden, "für die nicht aktive Sitzung gibt es einen Wechsel");
    laden.click();
    erwarte.gleich(Spiel.klassenraum.sitzung().id, s1.id, "gewechselt über sitzungWaehlen (echte API)");
    erwarte.gleich(p.dialoge.length, 2, "der Dialog zeigt den neuen Stand");
    erwarte.enthaelt(klText(p.dialoge[1].inhalt), "Sitzungen auf diesem Gerät: 2", "Liste bleibt vollständig");
    erwarte.gleich(Spiel.klassenraum.sitzungen().filter(x => x.aktiv).length, 1, "genau eine aktive Sitzung");
  }));

  pruefe("KLR-01b: Import ist Vollsicherung – Bestätigung ersetzt ALLE Sitzungen, danach Liste + Anzahl", () => klKapsel(() => {
    /* Datei mit genau EINER Sitzung samt Ergebnis bauen (echter Export, keine erfundene Datei). */
    const sA = klSitzung("salon-terminal");
    Spiel.klassenraum.ergebnisEintragen(klErgebnis(sA.id, 5, 4, 80000, 1));
    const datei = Spiel.klassenraum.exportieren();
    erwarte.gleich(typeof datei, "string", "der Export liefert die Datei");
    Spiel.klassenraum.erzeugen({ticketId: "salon-02", bestaetigen: true});
    Spiel.klassenraum.erzeugen({ticketId: "salon-03", bestaetigen: true});
    erwarte.gleich(Spiel.klassenraum.sitzungen().length, 3, "drei lokale Sitzungen vor dem Import");
    const p = klPruefstand({importText: datei, importSync: true});
    p.start();
    const c = p.zeige(0);
    p.K.lehrerWieder();
    klKnopf(c, "Datei…").click();
    erwarte.enthaelt(klText(p.dialoge[0].inhalt), "Sitzungen auf diesem Gerät: 3", "Liste vor dem Import");
    klKnopf(p.dialoge[0].inhalt, "Importieren").click();
    erwarte.gleich(p.dialoge.length, 2, "die Vollsicherung wird vorher bestätigt");
    erwarte.enthaelt(p.dialoge[1].titel, "ersetzen", "der Titel nennt das Ersetzen");
    erwarte.enthaelt(klText(p.dialoge[1].inhalt), "3 Sitzungen", "die Warnung nennt die lokale Zahl");
    klKnopf(p.dialoge[1].inhalt, "Abbrechen").click();
    erwarte.gleich(Spiel.klassenraum.sitzungen().length, 3, "Abbrechen ändert nichts");
    erwarte.gleich(p.importe.length, 0, "Abbrechen liest keine Datei");
    klKnopf(c, "Datei…").click();
    klKnopf(p.dialoge.at(-1).inhalt, "Importieren").click();
    klKnopf(p.dialoge.at(-1).inhalt, "Datei wählen und ersetzen").click();
    erwarte.gleich(p.importe.length, 1, "genau ein Dateizugriff");
    erwarte.gleich(Spiel.klassenraum.sitzungen().length, 1, "der Import ersetzt ALLE lokalen Sitzungen");
    erwarte.gleich(Spiel.klassenraum.sitzung().code, sA.code, "die aktive Sitzung kommt aus der Datei");
    const letzte = p.dialoge.at(-1);
    erwarte.gleich(letzte.titel, "Klassenraum-Datei", "nach dem Import steht die Datei-Ansicht wieder");
    erwarte.enthaelt(klText(letzte.inhalt), "Sitzungen auf diesem Gerät: 1", "Liste + Anzahl nach dem Import");
    erwarte.enthaelt(klText(letzte.inhalt), "1 Abgabe", "auch die Abgaben der importierten Sitzung");
    const toast = p.rufe.filter(r => r[0] === "toast").map(r => String(r[1])).join(" | ");
    erwarte.enthaelt(toast, "1 Sitzung", "ein Toast nennt die Anzahl");
  }));

  /* KLR-04b (W2, § 12.2): Ein Doppelplatz wurde still verworfen („das zuerst eingetragene gilt“).
     Jetzt fragt ein Dialog [Abbrechen][Ersetzen][Entfernen]; Esc/Abbrechen ändert nichts.
     Alles im bestehenden Hausdialog — keine neuen Sicht-Elemente (R12 bleibt 6). */
  pruefe("KLR-04b: Doppelplatz-Dialog [Abbrechen][Ersetzen][Entfernen], Grenzen ehrlich, R12 bleibt", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(0);
    const s = klSitzung("salon-terminal");
    const e5 = klErgebnis(s.id, 5, 4, 80000, 1);
    Spiel.klassenraum.ergebnisEintragen(e5);
    const e5b = klErgebnis(s.id, 5, 2, 40000, 2);
    const zustand = () => JSON.stringify(Spiel.klassenraum.sitzung().ergebnisse);
    const vorher = zustand();
    p.K._L.codes.value = e5b;
    klKnopf(c, "Eintragen").click();
    erwarte.gleich(p.dialoge.length, 1, "Konflikt-Dialog statt stillem Verwerfen");
    erwarte.enthaelt(p.dialoge[0].titel, "Platz 5", "Titel nennt den Platz");
    const dlg = p.dialoge[0].inhalt;
    erwarte.wahr(!!klKnopf(dlg, "Abbrechen") && !!klKnopf(dlg, "Ersetzen") && !!klKnopf(dlg, "Entfernen"), "drei Wege im Dialog");
    erwarte.enthaelt(klText(dlg), "Abgabe", "neuer Flow sagt „Abgabe“ statt „Ergebnis“");
    erwarte.falsch(/Ergebnis/i.test(klText(dlg)), "kein „Ergebnis“ im Konflikt-Dialog");
    /* 1 · Abbrechen ändert nichts */
    klKnopf(dlg, "Abbrechen").click();
    erwarte.gleich(zustand(), vorher, "Abbrechen ändert nichts");
    erwarte.enthaelt(klText(c), "nichts geändert", "die Zeile sagt: nichts geändert");
    /* 2 · Escape ändert nichts */
    p.K._L.codes.value = e5b;
    klKnopf(c, "Eintragen").click();
    p.dokument.listeners.keydown.at(-1)({key: "Escape"});
    erwarte.gleich(p.dialoge.at(-1).zu, true, "Escape schließt den Dialog");
    erwarte.gleich(zustand(), vorher, "Escape ändert nichts");
    /* 3 · Ersetzen schreibt den neuen Code — nach Quittung */
    p.K._L.codes.value = e5b;
    klKnopf(c, "Eintragen").click();
    klKnopf(p.dialoge.at(-1).inhalt, "Ersetzen").click();
    erwarte.gleich((Spiel.klassenraum.sitzung().ergebnisse["5"] || {}).code, e5b, "Ersetzen schreibt den neuen Code");
    erwarte.enthaelt(klText(c), "ersetzt", "Zeilenmeldung: ersetzt");
    /* 4 · Entfernen löscht den Eintrag (Tippfehler-Korrektur) */
    const e5c = klErgebnis(s.id, 5, 5, 20000, 3);
    p.K._L.codes.value = e5c;
    klKnopf(c, "Eintragen").click();
    klKnopf(p.dialoge.at(-1).inhalt, "Entfernen").click();
    erwarte.gleich(Spiel.klassenraum.sitzung().ergebnisse["5"], undefined, "Entfernen entfernt den Eintrag");
    erwarte.enthaelt(klText(c), "entfernt", "Zeilenmeldung: entfernt");
    /* 5 · Grenze: Platzzahl außerhalb 0..31 → Meldung im bestehenden Hinweisfeld */
    klKnopf(c, "Datei…").click();
    const wahl = klFinde(p.dialoge.at(-1).inhalt, "select")[0];
    wahl.value = "32";
    wahl.onchange();
    erwarte.enthaelt(klText(c), "0 bis 31", "die Grenze wird ehrlich gemeldet");
    /* 6 · R12 bleibt: sechs Bedienelemente außerhalb der Sitzungsliste */
    erwarte.gleich(klSteuerAusserListe(p, c), 6, "R12: außerhalb der Sitzungsliste sechs Bedienelemente");
  }));

  /* KLR-05b (W2, § 12.2): Die 20-Übersicht der Diagnose ist ein ANONYMES Histogramm
     (Schritt 1: 5 von 20 …) — keine Sterne, kein Rang, keine Platz→Schritt-Zuordnung, kein
     neues Bedienelement (R12 bleibt 6). H-Codes werden über den echten UI-Weg gelesen und gezählt. */
  pruefe("KLR-05b: Diagnose-Histogramm 5/7/8 anonym in der Ampel-Region, R12 bleibt", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(0);
    const s = klSitzung("salon-06");
    Spiel.klassenraum.plaetzeSetzen(20);
    const hilfe = (platz, schritt) => KlassenraumCodec.hilfeBauen({sitzung: s.id, platz, schritt, offen: Math.max(0, 5 - schritt)});
    const codes = [];
    for (let i = 0; i < 5; i++) codes.push(hilfe(i + 1, 1));
    for (let i = 0; i < 7; i++) codes.push(hilfe(6 + i, 2));
    for (let i = 0; i < 8; i++) codes.push(hilfe(13 + i, 3));
    p.K._L.codes.value = codes.join("\n");
    klKnopf(c, "Eintragen").click();
    const d = Spiel.klassenraum.diagnose();
    erwarte.gleich(d.schritte, [{schritt: 1, anzahl: 5}, {schritt: 2, anzahl: 7}, {schritt: 3, anzahl: 8}], "20 H-Codes anonym gezählt 5/7/8: " + JSON.stringify(d.schritte));
    erwarte.gleich([d.gesamt, d.plaetze], [20, 20], "gesamt 20, Nenner 20");
    erwarte.gleich(Object.keys(Spiel.klassenraum.sitzung().ergebnisse).length, 0, "H-Codes bleiben KEINE Ergebnisse");
    const ampel = klFinde(c, ".kl-ampel")[0];
    erwarte.wahr(!!ampel, "die Ampel-Region steht");
    const text = klText(ampel);
    erwarte.enthaelt(text, "Schritt 1: 5 Hilferufe", "Histogramm Schritt 1 (Hilferufe, kein Klassen-Nenner)");
    erwarte.enthaelt(text, "Schritt 2: 7 Hilferufe", "Histogramm Schritt 2");
    erwarte.enthaelt(text, "Schritt 3: 8 Hilferufe", "Histogramm Schritt 3");
    erwarte.falsch(/ von 20/.test(String(p.K._L.diagnose.textContent)), "H-Codes werden NICHT als „n von Klassenstärke“ gelesen (kein Platz-Dedupe in der API)");
    erwarte.gleich(klPersonenWoerter(ampel), [], "kein Name, kein Platz im Histogramm");
    erwarte.gleich(klSteuerAusserListe(p, c), 6, "R12: außerhalb der Sitzungsliste sechs Bedienelemente");
    /* Gegenprobe: ein eingeschmuggeltes Personenfeld in der Diagnose macht den Wächter rot. */
    erwarte.gleich(klPersonenFelder({schritt: 1, name: "Anna"}), ["name"], "Gegenprobe: Personenfeld wird erkannt");
  }));

  /* KLR-08b (W2, § 12.2): 20-Übersicht in der bestehenden Ampel-Region — nur Text, kein neues
     Bedienelement. „3 abgegeben · 17 offen · noch 8 min“ + offene Sitzplätze; keine Sterne,
     kein Rang, keine Bestenliste (didaktische Entscheidung W2). */
  pruefe("KLR-08b: 20-Übersicht „3 abgegeben · 17 offen · noch 8 min“ in der Ampel-Region, R12 bleibt", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(0);
    const s = klSitzung("salon-terminal");
    Spiel.klassenraum.plaetzeSetzen(20);
    for (const platz of [1, 2, 5]) Spiel.klassenraum.ergebnisEintragen(klErgebnis(s.id, platz, 4, 60000, 1));
    jetzt.setzen(KL_T0 + 2 * 60000);                  /* 2 Minuten nach dem Anlegen */
    p.K.lehrerWieder();
    const u = p.K._L.uebersicht;
    erwarte.wahr(!!u, "die Übersichtszeile existiert");
    const text = String(u.textContent);
    erwarte.enthaelt(text, "3 abgegeben", "drei Abgaben");
    erwarte.enthaelt(text, "17 offen", "17 offen (20 Plätze)");
    erwarte.enthaelt(text, "noch 8 min", "Restzeit: dauerMin 10 minus 2 Minuten");
    erwarte.enthaelt(text, "Sitzplatz 3", "offene Sitzplätze werden genannt");
    erwarte.falsch(text.includes("★"), "keine Sterne in der neuen Übersicht");
    erwarte.falsch(/rang|bestenliste|mittel|vergleich/i.test(text), "kein Rang, keine Bestenliste, kein Vergleich");
    const ampel = klFinde(c, ".kl-ampel")[0];
    erwarte.enthaelt(klText(ampel), "3 abgegeben", "die Übersicht steht in der Ampel-Region");
    erwarte.gleich(klSteuerAusserListe(p, c), 6, "R12: außerhalb der Sitzungsliste sechs Bedienelemente");
    /* Grenzfall: Klassenstärke nicht eingestellt → ehrlicher Text statt leerer Liste. */
    store.set("klassenraum", null);
    klSitzung("salon-terminal");
    p.K.lehrerWieder();
    erwarte.enthaelt(String(p.K._L.uebersicht.textContent), "nicht eingestellt", "ohne Klassenstärke ehrlich");
  }));

  /* KLR-10 (W3, r-didaktik): Ampel und 20-Übersicht müssen DIESELBE Definition nutzen. Ein Ergebnis
     mit ungültigem Platz (Codec erlaubt 0..31, Sitzung hat 20) zählte in der Ampel als „fertig“,
     in der Übersicht aber nicht. Jetzt: gültige Plätze zählen, ungültige werden separat ausgewiesen. */
  pruefe("KLR-10: Ampel und Übersicht zählen bei ungültigem Platz gleich (gültig zählt, ungültig separat)", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(0);
    const s = klSitzung("salon-terminal");
    Spiel.klassenraum.plaetzeSetzen(20);
    Spiel.klassenraum.ergebnisEintragen(klErgebnis(s.id, 1, 4, 60000, 1));
    Spiel.klassenraum.ergebnisEintragen(klErgebnis(s.id, 2, 3, 50000, 1));
    Spiel.klassenraum.ergebnisEintragen(klErgebnis(s.id, 25, 5, 40000, 1));   /* ungültig: > 20 Plätze */
    p.K.lehrerWieder();
    const summe = String(p.K._L.summe.textContent);
    const uebersicht = String(p.K._L.uebersicht.textContent);
    /* EINE Definition: zwei gültige Plätze → in BEIDEN Anzeigen 2 abgegeben / 18 offen. */
    erwarte.enthaelt(summe, "fertig 2", "Ampel zählt nur gültige Plätze");
    erwarte.enthaelt(summe, "offen 18", "Ampel: 18 offen");
    erwarte.enthaelt(uebersicht, "2 abgegeben", "Übersicht zählt nur gültige Plätze");
    erwarte.enthaelt(uebersicht, "18 offen", "Übersicht: 18 offen");
    erwarte.falsch(/fertig 3/.test(summe), "Ampel zählt den ungültigen Platz NICHT als fertig");
    erwarte.falsch(/3 abgegeben/.test(uebersicht), "Übersicht zählt den ungültigen Platz NICHT mit");
    /* Der ungültige Platz wird in BEIDEN Anzeigen ehrlich separat genannt. */
    erwarte.enthaelt(summe, "1 Abgabe ohne gültigen Platz", "Ampel weist die ungültige Abgabe aus");
    erwarte.enthaelt(uebersicht, "1 Abgabe ohne gültigen Platz", "Übersicht weist die ungültige Abgabe aus");
    /* Die Tafel zeigt die Zeile weiterhin als „ohne Platz“ (kein stilles Verschlucken). */
    erwarte.enthaelt(klText(c), "Platz 25", "Tafel zeigt den ungültigen Platz weiterhin an (kein stilles Verschlucken)");
    /* R12 bleibt 6/3. */
    erwarte.gleich(klSteuerAusserListe(p, c), 6, "R12: außerhalb der Sitzungsliste sechs Bedienelemente");
  }));

  /* KLR-12 (W3): sitzungLoeschen hatte keinen UI-Aufrufer. Die Lehrkraft bekommt eine kompakte
     Sitzungsliste (Kennung, Plätze, Abgaben) mit ehrlichem Löschen: ohne Abgaben direkt, mit
     Abgaben nur nach Quittung, aktive Sitzung wird nachgezogen; API-Fehler ehrlich. */
  pruefe("KLR-12: Sitzungsverwaltung im Datei-Dialog (Löschen/Quittung/aktiv nachgezogen), R12 bleibt 6", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(0);
    const s1 = klSitzung("salon-terminal");
    Spiel.klassenraum.ergebnisEintragen(klErgebnis(s1.id, 1, 4, 60000, 1));
    const s2 = Spiel.klassenraum.erzeugen({ticketId: "salon-02", bestaetigen: true});
    p.K.lehrerWieder();
    /* R12 (W3-Gate): KEINE neue Sitzungsliste in der Ansicht — die Verwaltung lebt im bestehenden
       „Datei…“-Dialog (Dialoginhalt zählt nicht als Ansicht). */
    erwarte.gleich(klFinde(c, "button").concat(klFinde(c, "select"), klFinde(c, "input"), klFinde(c, "textarea")).length, 6, "R12: Ansicht bleibt bei sechs Bedienelementen");
    erwarte.falsch(!!p.K._L.sitzungen, "keine Sitzungsliste als Dauer-Element in der Ansicht");
    const oeffneDatei = () => klKnopf(c, "Datei…").click();
    const letzterDialog = () => p.dialoge.at(-1);
    const loeschenKnopf = (inhalt, s) => klFinde(inhalt, "button").find(b => String(b.getAttribute("aria-label") || "") === "Sitzung " + s.id + " löschen");
    oeffneDatei();
    erwarte.enthaelt(letzterDialog().titel, "Klassenraum-Datei", "der bestehende Datei-Dialog öffnet");
    erwarte.gleich(klFinde(letzterDialog().inhalt, "button").filter(b => /löschen$/.test(String(b.getAttribute("aria-label") || ""))).length, 2, "je Sitzung ein Löschen-Weg im Dialog");
    erwarte.enthaelt(klText(letzterDialog().inhalt), "Sitzungen auf diesem Gerät: 2", "die Liste steht im Dialog");
    /* 1 · Löschen OHNE Abgaben: direkt, ohne Quittung; Dialog zeigt den neuen Stand. */
    const knopfS2 = loeschenKnopf(letzterDialog().inhalt, s2);
    erwarte.wahr(!!knopfS2, "Löschen-Knopf der Sitzung ohne Abgaben");
    knopfS2.click();
    erwarte.gleich(Spiel.klassenraum.sitzungen().length, 1, "Sitzung ohne Abgaben gelöscht");
    erwarte.gleich(Spiel.klassenraum.sitzung().id, s1.id, "aktive Sitzung sauber nachgezogen");
    erwarte.enthaelt(letzterDialog().titel, "Klassenraum-Datei", "die Liste wird neu gezeigt");
    erwarte.enthaelt(klText(letzterDialog().inhalt), "Sitzungen auf diesem Gerät: 1", "Dialog zählt eine Sitzung");
    erwarte.wahr(!p.dialoge.some(d => /Abgaben$/.test(d.titel)), "ohne Abgaben keine Quittung");
    /* 2 · Löschen MIT Abgaben: erst Quittung; Abbrechen ändert nichts, dann bestätigen. */
    const knopfS1 = () => loeschenKnopf(letzterDialog().inhalt, s1);
    knopfS1().click();
    erwarte.passt(String(letzterDialog().titel), /Abgaben/, "Quittung bei Abgaben");
    klKnopf(letzterDialog().inhalt, "Abbrechen").click();
    erwarte.gleich(Spiel.klassenraum.sitzungen().length, 1, "Abbrechen ändert nichts");
    oeffneDatei();
    knopfS1().click();
    erwarte.passt(String(letzterDialog().titel), /Abgaben/, "zweite Quittung");
    klKnopf(letzterDialog().inhalt, "Löschen").click();
    erwarte.gleich(Spiel.klassenraum.sitzungen().length, 0, "Sitzung mit Abgaben nach Quittung gelöscht");
    erwarte.gleich(Spiel.klassenraum.sitzung(), null, "keine aktive Sitzung mehr");
    erwarte.enthaelt(klText(letzterDialog().inhalt), "Sitzungen auf diesem Gerät: 0", "Dialog nach dem Löschen ehrlich leer");
    erwarte.enthaelt(klText(c), "noch keine Abgaben", "die Ampel ist nachgezogen (Abgabe-Wort)");
    /* 3 · API-Fehler ehrlich: stale Zeile auf eine bereits gelöschte Sitzung. */
    const s3 = Spiel.klassenraum.erzeugen({ticketId: "salon-02", bestaetigen: true});
    p.K.lehrerWieder();
    oeffneDatei();
    const stale = loeschenKnopf(letzterDialog().inhalt, s3);
    erwarte.wahr(!!stale, "Löschen-Knopf der neuen Sitzung");
    Spiel.klassenraum.sitzungLoeschen(s3.id, {bestaetigen: true});
    stale.click();
    const toasts = p.rufe.filter(r => r[0] === "toast");
    erwarte.enthaelt(String(toasts.at(-1) && toasts.at(-1)[1]), "gibt es hier nicht", "API-Fehler kommt als ehrlicher Toast");
    erwarte.enthaelt(klText(c), "gibt es hier nicht", "und steht auch im Hinweisfeld der Ansicht");
  }));


  /* KLR-11 (P2 Vorprüfung): Auch der Legacy-Zweig „platz-schon-da“ (alte API-Antwort) sagt jetzt
     „Abgabe“ statt „Ergebnis“. Der Pfad ist per API nicht mehr erreichbar — der Test stellt die
     alte Antwort gezielt nach, damit die sichtbare Meldung falsifizierbar geprüft ist. */
  pruefe("KLR-11: Legacy-Antwort „platz-schon-da“ sagt „Abgabe“, nicht „Ergebnis“", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(0);
    klSitzung("salon-terminal");
    const echt = Spiel.klassenraum.ergebnisEintragen;
    let rufe = 0;
    Spiel.klassenraum.ergebnisEintragen = () => { rufe += 1; return {ok: true, neu: false, grund: "platz-schon-da", platz: 5, sterne: 8}; };
    try {
      p.K._L.codes.value = "E-AAAA-BBB";
      klKnopf(c, "Eintragen").click();
    } finally { Spiel.klassenraum.ergebnisEintragen = echt; }
    const hinweis = klFinde(c, ".kl-hinweis").map(x => klText(x)).join(" | ");
    erwarte.gleich(rufe, 1, "der Eintragen-Pfad lief genau einmal");
    erwarte.enthaelt(hinweis, "Platz 5 hat schon eine Abgabe", "der Legacy-Pfad sagt „Abgabe“");
    erwarte.enthaelt(hinweis, "zuerst eingetragene gilt", "die Regel bleibt verständlich");
    erwarte.falsch(/Ergebnis/i.test(hinweis), "kein „Ergebnis“ in dieser Meldung");
  }));

  /* KLR-10 Randfälle (P2 Vorprüfung): Ampel und Übersicht müssen bei 0 Plätzen, Platz 32 und
     nicht-ganzzahligem Platz DIESELBEN Zahlen zeigen. Der Test schreibt pathologische Rohdaten in
     den Speicher (der Codec kann 1.5/32 nicht bauen) und vergleicht beide Anzeigen. */
  pruefe("KLR-10 Randfälle: dieselbe Platz-Definition in Ampel und Übersicht (0 Plätze, 32, 1.5)", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    p.zeige(0);
    const s = klSitzung("salon-terminal");
    const roh = store.get("klassenraum");
    const sitz = roh.sitzungen.find(x => x.id === s.id);
    sitz.plaetze = 20;
    sitz.ergebnisse = {
      a: {platz: 1, sterne: 8, dauerS: 60000, versuche: 0, code: "x", zeit: 1},
      b: {platz: 1.5, sterne: 4, dauerS: 50000, versuche: 0, code: "y", zeit: 1},
      d: {platz: 32, sterne: 6, dauerS: 40000, versuche: 0, code: "z", zeit: 1},
      e: {platz: 0, sterne: 2, dauerS: 30000, versuche: 0, code: "w", zeit: 1},
    };
    store.set("klassenraum", roh);
    p.K.lehrerWieder();
    const summe = String(p.K._L.summe.textContent), ueb = String(p.K._L.uebersicht.textContent);
    const z = (t, re) => { const m = re.exec(t); return m ? Number(m[1]) : null; };
    erwarte.gleich(z(summe, /fertig (\d+)/), 1, "nur der ganzzahlige Platz 1 zählt als gültig");
    erwarte.gleich(z(summe, /fertig (\d+)/), z(ueb, /(\d+) abgegeben/), "Ampel und Übersicht zählen gültig GLEICH");
    erwarte.gleich(z(summe, /offen (\d+)/), z(ueb, /(\d+) offen/), "Ampel und Übersicht zählen offen GLEICH");
    erwarte.gleich(z(summe, /(\d+) Abgaben? ohne gültigen Platz/), 3, "1.5, 32 und 0 sind ungültig");
    erwarte.gleich(z(summe, /(\d+) Abgaben? ohne gültigen Platz/), z(ueb, /(\d+) Abgaben? ohne gültigen Platz/), "Ungültig-Zähler GLEICH");
    /* 0 Plätze (nicht eingestellt): ehrlich, aber dieselben Zahlen — nichts wird ausgeblendet. */
    sitz.plaetze = 0;
    store.set("klassenraum", roh);
    p.K.lehrerWieder();
    const summe0 = String(p.K._L.summe.textContent), ueb0 = String(p.K._L.uebersicht.textContent);
    erwarte.enthaelt(ueb0, "nicht eingestellt", "ohne Klassenstärke ehrlich");
    erwarte.gleich(z(summe0, /fertig (\d+)/), z(ueb0, /(\d+) gültige Abgabe/), "auch bei 0 Plätzen gleiche gültig-Zahl");
    erwarte.gleich(z(summe0, /(\d+) Abgaben? ohne gültigen Platz/), z(ueb0, /(\d+) Abgaben? ohne gültigen Platz/), "auch bei 0 Plätzen gleicher Ungültig-Zähler");
  }));

  /* task-115 D1 (r-didaktik W4): Neue 3.0-Flächen sagen einheitlich „Abgabe“; „Ergebnis-Code“
     bleibt nur für den Code selbst. Sichtbarer Test an der Ansicht. */
  pruefe("D1: Ampel/Flächen sagen „Abgabe“ — kein „noch keine Ergebnisse“, Feld heißt „Abgabe-Codes“", () => klKapsel(() => {
    const p = klPruefstand();
    p.start();
    const c = p.zeige(0);
    klSitzung("salon-terminal");
    p.K.lehrerWieder();
    const text = klText(c);
    erwarte.falsch(text.includes("noch keine Ergebnisse"), "kein „noch keine Ergebnisse“ in der Ansicht");
    erwarte.enthaelt(text, "noch keine Abgaben", "die leere Ampel sagt „noch keine Abgaben“");
    const etiketten = klFinde(c, ".kl-etikett").map(e => klText(e));
    erwarte.wahr(etiketten.includes("Abgabe-Codes"), "das Code-Feld heißt „Abgabe-Codes“");
    const feld = klFinde(c, "textarea")[0];
    erwarte.gleich(feld.getAttribute("aria-label"), "Abgabe-Codes", "aria-label nennt dieselbe Bezeichnung");
    /* Der erzeugte Code selbst bleibt „Ergebnis-Code“ (bestehender Code-Test prüft den Toast). */
  }));
});
