"use strict";
/* ---------- Wiki: eine Nachschlage-Seite je Fertigkeit (DATEN.skills) ----------
   DATEN.wiki[skillId] = {titel, kurz, abschnitte:[{titel, html}], merksatz, pruefungstipp, quelle, belege, siehe:[skillIds]}
   quelle  = Name der Vault-Notiz (für „Nachschlagen“), belege = weitere Belege (RFC, IEEE, Hersteller-Doku).
   html    = schlichtes HTML: <p>, <ul>/<li>, <code>, <b>, <table>/<tr>/<th>/<td>, <pre>. Keine Klassen, keine Skripte.
   Befehle der Konsole sind „IOS-ähnlich“: an Cisco IOS angelehnt, nicht jede Feinheit ist nachgebaut. */
Object.assign(DATEN.wiki, {
  "lab.link": {
    titel: "Link und Kabel prüfen",
    kurz: "Ohne Link auf Schicht 1 kommt kein einziger Frame an, deshalb prüfst du ihn immer zuerst.",
    abschnitte: [
      {titel: "Woran du einen Link erkennst", html:
        "<p>Im Labor ist eine Leitung mit Link grün, ohne Link rot, jeweils mit Symbol. Auf Routern und Switches zeigt <code>show ip interface brief</code> zwei Spalten: <b>Status</b> (Schicht 1) und <b>Protocol</b> (Schicht 2).</p>" +
        "<table><tr><th>Status</th><th>Protocol</th><th>Bedeutung</th></tr>" +
        "<tr><td>up</td><td>up</td><td>Link steht, die Schnittstelle arbeitet</td></tr>" +
        "<tr><td>down</td><td>down</td><td>kein Signal: Kabel fehlt, Gegenstelle aus oder dort abgeschaltet</td></tr>" +
        "<tr><td>administratively down</td><td>down</td><td>hier mit <code>shutdown</code> abgeschaltet</td></tr>" +
        "<tr><td>up</td><td>down</td><td>Signal da, aber Schicht 2 einigt sich nicht (im Labor selten)</td></tr></table>" +
        "<p>Unter Windows zeigt <code>ipconfig</code> bei fehlendem Kabel „Medienstatus: Medium getrennt“.</p>"},
      {titel: "Ab Werk: Router aus, Switch an", html:
        "<p>Router-Schnittstellen sind ab Werk <b>abgeschaltet</b>, Switchports sind <b>eingeschaltet</b>. Nach dem Eintragen einer IP-Adresse am Router fehlt deshalb oft nur ein Befehl:</p>" +
        "<pre>R1(config)# interface g0/0\nR1(config-if)# no shutdown</pre>"},
      {titel: "Kabel", html:
        "<p>Ob gerades oder gekreuztes Kabel, spielt heute keine Rolle mehr: Die Ports erkennen die Belegung selbst (Auto-MDI-X). Kupfer-Ethernet reicht bis 100 m, darüber nimmt man Glasfaser.</p>"},
      {titel: "WLAN: der Link ohne Kabel", html:
        "<p>Ein <b>Access Point</b> (AP) ist die Brücke zwischen Funk und Kabel: auf der einen Seite die Antenne, auf der anderen ein Switchport. Die Funkzelle heißt BSS, ihr Name ist die <b>SSID</b>, die MAC des Funkmoduls die BSSID.</p>" +
        "<ul><li>Funk ist ein <b>geteiltes Medium</b>: Alle Geräte einer Zelle senden abwechselnd, die beworbene Bruttorate erreicht deshalb kein einzelnes Gerät.</li><li>Den Zugriff regelt <b>CSMA/CA</b> mit Bestätigung je Rahmen – gesendet wird, wenn die Luft frei ist; Kollisionen werden vermieden, nicht erkannt.</li><li>Funk arbeitet <b>halbduplex</b>: senden und empfangen nacheinander, anders als Ethernet am Kabel.</li><li>Die Verbindung entsteht per <b>Assoziation</b>: Das Gerät meldet sich am AP an. Ohne Assoziation gibt es keinen Link – dieselbe Rolle wie ein gestecktes Kabel.</li></ul>" +
        "<table><tr><th>Band</th><th>Kanäle</th><th>Eigenschaft</th></tr>" +
        "<tr><td>2,4 GHz</td><td>1 bis 13 – je nach Land und Regulierung (in den USA nur 1–11); überlappungsfrei sind 1, 6 und 11</td><td>weit, aber langsamer und oft belegt</td></tr>" +
        "<tr><td>5 GHz</td><td>viele Kanäle</td><td>schneller, kürzere Reichweite</td></tr>" +
        "<tr><td>6 GHz</td><td>nur mit neueren Geräten</td><td>viel Platz, wenige Störer</td></tr></table>" +
        "<p>Störer sind Nachbarzellen auf demselben Kanal, Mikrowellen und dicke Wände. Prüfen lässt sich die Verbindung über Feldstärke und Rate; ein Ping durchs Funknetz schwankt stärker als über Kabel.</p>"},
    ],
    merksatz: "Ohne Link keine Frames: Schicht 1 zuerst prüfen.",
    pruefungstipp: "Beschreib Fehlersuche immer nach OSI von unten: Kabel und Link, IP-Konfiguration, Gateway, DNS, Dienst.",
    quelle: "Fragen – Netzwerke planen",
    belege: "Cisco IOS Interface Command Reference (show ip interface brief, shutdown) · 04-AP1-Netzwerk (Ethernet/Kabel) · IEEE 802.3 · IEEE 802.11 (WLAN, CSMA/CA) · BSI IT-Grundschutz-Kompendium, NET.2.1 WLAN-Betrieb",
    siehe: ["lab.cli", "lab.ping", "lab.ip", "lab.vlan"],
  },
  "lab.ip": {
    titel: "IP-Adresse und Maske setzen",
    kurz: "Eine IPv4-Adresse besteht aus 32 Bit; die Maske sagt, welcher Teil das Netz und welcher den Rechner bezeichnet.",
    abschnitte: [
      {titel: "Aufbau", html:
        "<p>Vier Oktette zu je 8 Bit, jedes 0 bis 255, getrennt durch Punkte: <code>192.168.1.10</code>. Die <b>Subnetzmaske</b> besteht aus lauter Einsen (Netzanteil), gefolgt von lauter Nullen (Hostanteil): <code>255.255.255.0</code> = <code>/24</code>.</p>" +
        "<ul><li><b>Netz-ID</b>: alle Hostbits 0 – im Regelfall keine Hostadresse</li><li><b>Broadcast</b>: alle Hostbits 1 – im Regelfall keine Hostadresse</li><li>Jede Adresse darf im Netz nur <b>einmal</b> vorkommen, sonst gibt es einen Adresskonflikt.</li></ul>" +
        "<p><b>Ausnahme /31 (RFC 3021):</b> Bei Punkt-zu-Punkt-Verbindungen gibt es keine Netz- und keine Broadcastadresse – beide Adressen sind nutzbar. Ein <b>/32</b> bezeichnet genau einen Host (eine Adresse).</p>"},
      {titel: "Besondere Bereiche", html:
        "<table><tr><th>Bereich</th><th>Bedeutung</th></tr>" +
        "<tr><td>10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16</td><td>privat (RFC 1918), im Internet nicht geroutet</td></tr>" +
        "<tr><td>127.0.0.0/8</td><td>Loopback, der eigene Rechner</td></tr>" +
        "<tr><td>169.254.0.0/16</td><td>APIPA: selbst vergeben, wenn kein DHCP-Server antwortet</td></tr>" +
        "<tr><td>0.0.0.0</td><td>„noch keine Adresse“ bzw. Default-Route</td></tr>" +
        "<tr><td>255.255.255.255</td><td>Broadcast an alle im eigenen Netz</td></tr></table>" +
        "<p>Achtung: 172.16.0.0/12 reicht nur bis 172.31.255.255. 172.40.1.1 ist öffentlich.</p>"},
      {titel: "Im Labor setzen", html:
        "<p>PC, Server: im Inspektor unter „Schnittstellen“ IP-Adresse, Maske, Gateway und DNS eintragen. Router (Konsole):</p>" +
        "<pre>R1(config)# interface g0/0\nR1(config-if)# ip address 192.168.1.1 255.255.255.0\nR1(config-if)# no shutdown</pre>" +
        "<p>Kontrolle: <code>ipconfig</code> am PC, <code>show ip interface brief</code> am Router.</p>"},
      {titel: "IPv6: Adresse, Präfix und Adresstypen (Nachschlagen)", html:
        "<p>IPv6-Adressen sind 128 Bit lang und werden als acht Blöcke zu 16 Bit hexadezimal geschrieben: <code>2001:0db8:0000:0000:0000:ff00:0042:8329</code>. Zwei Regeln kürzen das: führende Nullen eines Blocks fallen weg, und <b>ein einziges Mal</b> darf eine Folge von Nullblöcken durch <code>::</code> ersetzt werden.</p>" +
        "<table><tr><th>Bereich</th><th>Bedeutung</th></tr>" +
        "<tr><td>2000::/3</td><td>Global Unicast: im Internet routingfähig, das Gegenstück zur öffentlichen Adresse</td></tr>" +
        "<tr><td>fe80::/10</td><td>Link-Local: nur im eigenen Link, wird automatisch gebildet und nie geroutet</td></tr>" +
        "<tr><td>fc00::/7</td><td>Unique Local, privat – das Gegenstück zu den RFC-1918-Bereichen</td></tr>" +
        "<tr><td>ff00::/8</td><td>Multicast: erreicht Gruppen und ersetzt den Broadcast</td></tr>" +
        "<tr><td>::1</td><td>Loopback, das Gegenstück zu 127.0.0.1</td></tr>" +
        "<tr><td>::</td><td>„noch keine Adresse“</td></tr></table>" +
        "<p>Eine Subnetzmaske gibt es nicht mehr: Die Präfixlänge steht direkt an der Adresse, zum Beispiel <code>2001:db8:aa00:1::1/64</code>. Einen <b>Broadcast</b> kennt IPv6 nicht, Multicast übernimmt seine Rolle. Für Dokumentation und Beispiele ist 2001:db8::/32 reserviert – diese Adressen gehören niemandem und gehören in kein echtes Netz.</p>" +
        "<p>Ein Gerät hat meist mehrere Adressen gleichzeitig: eine Link-Local und mindestens eine globale. Kommt kein Router Advertisement an, bleibt nur die Link-Local übrig – das IPv6-Gegenstück zur APIPA-Adresse. Dieses Labor rechnet mit IPv4; IPv6 steht hier zum Nachschlagen.</p>"},
    ],
    merksatz: "Jede Adresse nur einmal vergeben; im Regelfall nie die Netz-ID und nie den Broadcast – Ausnahme /31 nach RFC 3021 (zwei nutzbare Adressen), /32 ist eine Einzeladresse.",
    pruefungstipp: "Private Bereiche sicher können; 172.16.0.0/12 ist die häufigste Falle (nur 172.16 bis 172.31). In IPv6 gibt es keine Maske, nur die Präfixlänge.",
    quelle: "Network – Lernfassung",
    belege: "RFC 1918 · RFC 3927 (169.254.0.0/16) · RFC 5227 (Adresskonflikte) · RFC 3021 (/31 bei Punkt-zu-Punkt-Netzen) · Fragen – Netzwerk-Grundlagen · RFC 4291 (IPv6-Adressarchitektur) · RFC 3849 (2001:db8::/32) · RFC 4193 (Unique Local) · RFC 5952 (Schreibweise)",
    siehe: ["lab.netz", "lab.subnetz", "lab.gateway", "lab.dhcp", "lab.arp"],
  },
  "lab.netz": {
    titel: "Gleiches Netz? (Maske anwenden)",
    kurz: "Vor jedem Senden prüft ein Rechner mit seiner Maske, ob das Ziel im eigenen Netz liegt: dann direkt, sonst über das Gateway.",
    abschnitte: [
      {titel: "Die Entscheidung des Absenders", html:
        "<ul><li>Eigene IP mit eigener Maske verrechnen: ergibt die eigene Netz-ID.</li><li>Ziel-IP mit <b>derselben</b> Maske verrechnen: ergibt die Netz-ID des Ziels aus Sicht des Absenders.</li><li>Gleich: Ziel direkt per ARP suchen. Ungleich: Paket ans Standardgateway.</li></ul>"},
      {titel: "Beispiel mit /29", html:
        "<p>Maske <code>255.255.255.248</code>, Blockgröße 256 − 248 = 8. Die Netze beginnen bei .0, .8, .16, .24 …</p>" +
        "<table><tr><th>Adresse</th><th>Netz</th><th>Bereich</th></tr>" +
        "<tr><td>192.168.10.10/29</td><td>192.168.10.8</td><td>.8 bis .15</td></tr>" +
        "<tr><td>192.168.10.20/29</td><td>192.168.10.16</td><td>.16 bis .23</td></tr></table>" +
        "<p>Die beiden liegen in verschiedenen Netzen und brauchen einen Router, auch wenn sie am selben Switch hängen.</p>"},
      {titel: "Was eine falsche Maske anrichtet", html:
        "<ul><li><b>Zu groß</b> (z. B. /16 statt /24): Der Rechner hält Geräte hinter dem Router für Nachbarn, fragt per ARP ins Leere.</li><li><b>Zu klein</b> (z. B. /28 statt /24): Nachbarn wirken fremd, der Verkehr geht unnötig über das Gateway oder scheitert.</li></ul>"},
      {titel: "Drei Fragen vor dem Senden", html:
        "<p>Drei Fragen beantworten die Rechnung im Kopf: Welche Maske trägt der Absender? Welche Netz-ID ergibt die Zieladresse mit dieser Maske? Liegt sie im eigenen Netz? Erst wenn die dritte Antwort „nein“ lautet, geht das Paket an das Gateway – sonst direkt per ARP an das Ziel.</p>"},
    ],
    merksatz: "Gleiche Netz-ID mit derselben Maske: direkt. Sonst: ab zum Gateway.",
    pruefungstipp: "Rechne immer mit der Maske des Absenders, denn er entscheidet, wohin er sendet.",
    quelle: "Network – Lernfassung",
    belege: "04-AP1-Netzwerk (Subnetting-Verfahren) · Fragen – Subnetting",
    siehe: ["lab.subnetz", "lab.gateway", "lab.arp"],
  },
  "lab.gateway": {
    titel: "Standardgateway",
    kurz: "Das Standardgateway ist der Router im eigenen Netz, dem ein Rechner alle Pakete für fremde Netze übergibt.",
    abschnitte: [
      {titel: "Regeln", html:
        "<ul><li>Das Gateway muss <b>im eigenen Netz</b> liegen, sonst ist es nicht direkt erreichbar.</li><li>Meist ist es die Adresse der Router-Schnittstelle in diesem Netz, oft die .1.</li><li>Für ein fremdes Ziel fragt der Rechner per ARP nach der MAC des <b>Gateways</b>, nie nach der des Ziels. Im ARP-Cache eines PCs stehen deshalb nie MACs von Internet-Servern.</li></ul>"},
      {titel: "Fehlerbilder", html:
        "<table><tr><th>Beobachtung</th><th>Ursache</th></tr>" +
        "<tr><td>Nachbarn gehen, fremde Netze nicht, Meldung „Allgemeiner Fehler“</td><td>kein Gateway eingetragen</td></tr>" +
        "<tr><td>Windows warnt: Gateway nicht im selben Netzwerksegment</td><td>Gateway im falschen Netz (Tippfehler, falsche Maske)</td></tr>" +
        "<tr><td>„Zielhost nicht erreichbar“ von der eigenen Adresse</td><td>Gateway antwortet nicht auf ARP: falsche Adresse, Router-Port aus</td></tr></table>"},
      {titel: "Auch ein Switch braucht eins", html:
        "<p>Ein Layer-2-Switch verhält sich bei seiner Verwaltungsadresse wie ein PC. Soll er aus anderen Netzen erreichbar sein, braucht er ein Gateway:</p>" +
        "<pre>SW1(config)# ip default-gateway 192.168.1.1</pre>"},
      {titel: "Ohne Gateway: was noch geht", html:
        "<p>Ohne Standardgateway bleibt das eigene Netz erreichbar: Drucker, Dateiserver und Nachbarn im selben IP-Bereich funktionieren weiter. Fremde Netze und das Internet fallen aus, weil der Rechner kein Gerät kennt, dem er Pakete für unbekannte Ziele geben kann. Windows meldet dann „Allgemeiner Fehler“ oder gar keine Antwort.</p>"},
    ],
    merksatz: "Fremdes Netz? Dann geht der Frame an die MAC des Gateways, die IP bleibt die des Ziels.",
    pruefungstipp: "Frage „Welche Ziel-MAC hat der Frame an einen Internet-Server?“: die des Default Gateways.",
    quelle: "Network – Lernfassung",
    belege: "Fragen – Netzwerk-Grundlagen (net-15) · Netzwerk – Geschichten (Rita an der Grenze) · Cisco IOS Command Reference (ip default-gateway)",
    siehe: ["lab.netz", "lab.arp", "lab.route"],
  },
  "lab.arp": {
    titel: "ARP: IP zu MAC auflösen",
    kurz: "ARP findet im lokalen Netz zu einer IP-Adresse die MAC-Adresse, ohne die kein Frame adressiert werden kann.",
    abschnitte: [
      {titel: "Ablauf", html:
        "<ul><li>Absender schaut in seinen <b>ARP-Cache</b>. Kein Eintrag: Das Paket wartet.</li><li><b>ARP-Request als Broadcast</b> (Ziel-MAC ff:ff:ff:ff:ff:ff): „Wer hat 192.168.1.20? Sag es 192.168.1.10.“</li><li>Nur das gesuchte Gerät antwortet, per <b>Unicast</b>: „192.168.1.20 ist meine MAC.“</li><li>Der Absender trägt die Zuordnung ein, jetzt geht das eigentliche Paket los.</li></ul>" +
        "<p>ARP wird direkt in einem Ethernet-Frame transportiert (EtherType <code>0x0806</code>), ohne IP-Header.</p>"},
      {titel: "Ansehen", html:
        "<table><tr><th>Gerät</th><th>Befehl</th><th>Hinweis</th></tr>" +
        "<tr><td>Windows</td><td><code>arp -a</code></td><td>Cache anzeigen; <code>arp -d</code> leert ihn</td></tr>" +
        "<tr><td>Router</td><td><code>show ip arp</code></td><td>Die ARP-Tabelle des Geräts mit Protocol, Address, Age (min), Hardware Addr, Type und Interface; das Labor listet nur aufgelöste Einträge. Den Zustand „Incomplete“ für eine noch offene Anfrage zeigt erst echte IOS-Hardware.</td></tr></table>"},
      {titel: "Sicherheit", html:
        "<p>ARP kennt keine Anmeldung, jeder darf antworten. Beim <b>ARP-Spoofing</b> gibt sich ein Angreifer als Gateway aus und liest mit. Abwehr: Dynamic ARP Inspection am Switch, VLANs, Verschlüsselung. Eine Firewall zwischen Netzen sieht diesen Verkehr im LAN gar nicht.</p>"},
      {titel: "IPv6: Nachbarschaft statt ARP (NDP)", html:
        "<p>In IPv6 gibt es kein ARP. Diese Aufgabe übernimmt das <b>Neighbor Discovery Protocol</b> (NDP) mit ICMPv6:</p>" +
        "<table><tr><th>Nachricht</th><th>Typ</th><th>Aufgabe</th></tr>" +
        "<tr><td>Router Solicitation</td><td>133</td><td>„Welche Router sind da?“ – der Rechner fragt beim Start</td></tr>" +
        "<tr><td>Router Advertisement</td><td>134</td><td>Der Router nennt Präfix, Gateway und Flags</td></tr>" +
        "<tr><td>Neighbor Solicitation</td><td>135</td><td>„Wer hat diese Adresse?“ – nicht an alle, sondern an eine Gruppe</td></tr>" +
        "<tr><td>Neighbor Advertisement</td><td>136</td><td>„Ich“ – die Antwort mit der MAC-Adresse</td></tr></table>" +
        "<p>Gefragt wird über die Multicast-Adresse <code>ff02::1:ffXX:XXXX</code>, gebildet aus den letzten 24 Bit der gesuchten Adresse (Solicited-Node). Auf Ethernet wird daraus die MAC <code>33:33:ff:XX:XX:XX</code> – nur die zuständigen Geräte hören mit, nicht das ganze Netz.</p>" +
        "<p>Vor der ersten Benutzung prüft jeder Rechner seine eigene Adresse per <b>Duplicate Address Detection</b>: eine Neighbor Solicitation an sich selbst. Antwortet jemand, ist die Adresse doppelt vergeben. Nachsehen: <code>show ipv6 neighbors</code> (IOS), <code>netsh interface ipv6 show neighbors</code> (Windows).</p>" +
        "<p><b>Echte Geräte, nicht das Labor:</b> Dieses Labor rechnet mit IPv4; IPv6 steht hier zum Nachschlagen. Es kennt keine IPv6-Konfiguration und weist beide Nachschlage-Befehle ab – auf echter IOS-Hardware und echtem Windows liefern sie die Nachbartabelle.</p>"},
    ],
    merksatz: "Request an alle (Broadcast), Reply an einen (Unicast).",
    pruefungstipp: "Liegt das Ziel in einem anderen Netz, fragt ARP nach der MAC des Gateways. Das ist die häufigste Prüfungsfalle zu ARP. In IPv6 übernimmt NDP diese Aufgabe mit ICMPv6.",
    quelle: "Network – Lernfassung",
    belege: "RFC 826 · Fragen – Netzwerk-Grundlagen (net-14 bis net-16) · RFC 4861 (Neighbor Discovery) · RFC 4862 (Duplicate Address Detection)",
    siehe: ["lab.gateway", "lab.switch", "lab.ping", "lab.ip"],
  },
  "lab.ping": {
    titel: "Ping und Fehlermeldungen lesen",
    kurz: "Ping schickt ICMP-Echo-Anfragen und zeigt, ob Antworten kommen, oder wer unterwegs einen Fehler meldet.",
    abschnitte: [
      {titel: "ICMP in Kürze", html:
        "<p>Ping nutzt <b>ICMP</b>, das direkt auf IP liegt, ohne TCP, UDP und Ports.</p>" +
        "<table><tr><th>Typ</th><th>Name</th><th>Bedeutung</th></tr>" +
        "<tr><td>8</td><td>Echo Request</td><td>die Anfrage</td></tr>" +
        "<tr><td>0</td><td>Echo Reply</td><td>die Antwort</td></tr>" +
        "<tr><td>3</td><td>Destination Unreachable</td><td>jemand meldet: Netz, Host oder Port nicht erreichbar</td></tr>" +
        "<tr><td>11</td><td>Time Exceeded</td><td>TTL unterwegs auf 0 gefallen</td></tr></table>"},
      {titel: "Ausgaben lesen", html:
        "<table><tr><th>IOS</th><th>Windows</th><th>Bedeutung</th></tr>" +
        "<tr><td><code>!</code></td><td>Antwort von …</td><td>Antwort erhalten</td></tr>" +
        "<tr><td><code>.</code></td><td>Zeitüberschreitung der Anforderung.</td><td>still verworfen, niemand meldet sich</td></tr>" +
        "<tr><td><code>U</code></td><td>Zielhost/Zielnetz nicht erreichbar.</td><td>ein Gerät meldet den Fehler</td></tr>" +
        "<tr><td><code>&amp;</code></td><td>Gültigkeitsdauer … überschritten.</td><td>TTL abgelaufen</td></tr></table>" +
        "<p>IOS sendet standardmäßig 5 Anfragen und wartet je 2 s, Windows sendet 4 und wartet je 4 s.</p>"},
      {titel: "Timeout oder Unreachable?", html:
        "<p><b>Unreachable</b> ist die freundlichere Nachricht: Die Adresse hinter „Antwort von“ zeigt, wer aufgegeben hat. Kommt sie von der eigenen Adresse, blieb ARP im eigenen Netz ohne Antwort. Ein <b>Timeout</b> sagt nur, dass nichts zurückkam: Firewall, fehlende Rückroute, fehlendes NAT.</p>" +
        "<p><code>.!!!!</code> beim ersten Ping über einen Router ist normal: Das erste Paket geht verloren, während ARP noch auflöst.</p>"},
      {titel: "Was ein Ping nicht beweist", html:
        "<p>Ein erfolgreicher Ping zeigt nur, dass ICMP-Echo beantwortet wird – nicht, dass ein Dienst läuft. Umgekehrt kann ein Rechner erreichbar sein und Ping trotzdem schweigen, weil eine Firewall ICMP verwirft. Dienste prüft man deshalb am Port: Ein geschlossener TCP-Port antwortet mit RST („Verbindung abgelehnt“), ein verworfener Port schweigt.</p>"},
    ],
    merksatz: "Timeout = still verworfen, Unreachable = jemand meldet sich.",
    pruefungstipp: "Ping hat keinen Port: ICMP liegt direkt auf Schicht 3.",
    quelle: "Network – Lernfassung",
    belege: "RFC 792 · Cisco: Understanding the Ping and Traceroute Commands · Microsoft Learn: ping",
    siehe: ["lab.ttl", "lab.arp", "lab.route"],
  },
  "lab.switch": {
    titel: "Switch: MAC-Tabelle und Fluten",
    kurz: "Ein Switch lernt aus den Quell-MACs, an welchem Port welches Gerät hängt, und leitet Frames gezielt weiter.",
    abschnitte: [
      {titel: "Vier Entscheidungen", html:
        "<ul><li><b>Lernen</b>: Quell-MAC und Eingangsport in die MAC-Tabelle eintragen, immer über die Quell-MAC.</li><li><b>Weiterleiten</b>: Ziel-MAC bekannt, nur an diesen Port.</li><li><b>Fluten</b>: Ziel unbekannt oder Broadcast, an alle Ports außer dem Eingang (im selben VLAN).</li><li><b>Filtern</b>: Ziel hängt am Eingangsport, der Frame wird nicht weitergeleitet.</li></ul>" +
        "<p>Einträge verfallen nach 300 s ohne Verkehr (Cisco-Standard).</p>"},
      {titel: "Ansehen", html:
        "<pre>SW1# show mac address-table\nVlan  Mac Address     Type     Ports\n   1  0060.2f3a.1b01  DYNAMIC  Fa0/1</pre>"},
      {titel: "Domänen", html:
        "<table><tr><th>Gerät</th><th>Kollisionsdomänen</th><th>Broadcast-Domänen</th></tr>" +
        "<tr><td>Hub</td><td>eine für alle Ports</td><td>eine</td></tr>" +
        "<tr><td>Switch</td><td>eine je Port</td><td>eine (je VLAN eine)</td></tr>" +
        "<tr><td>Router</td><td>eine je Schnittstelle</td><td>eine je Schnittstelle</td></tr></table>"},
      {titel: "Lernen, Altern, Fluten", html:
        "<p>Ein Eintrag der MAC-Tabelle bleibt nicht ewig: Ohne neue Frames altert er (Cisco-Standard 300 s) und wird gelöscht, damit umgesteckte Geräte wieder gefunden werden. Solange eine Ziel-MAC unbekannt ist, flutet der Switch den Frame an alle Ports seines VLANs – normal, aber es kostet Bandbreite. Wandert dieselbe MAC ständig zwischen zwei Ports, deutet das auf eine Schleife hin.</p>"},
    ],
    merksatz: "Lernen über die Quelle, entscheiden über das Ziel.",
    pruefungstipp: "Domänen zählen: Jede Switch-Leitung ist eine eigene Kollisionsdomäne, Broadcasts stoppt nur der Router (oder die VLAN-Grenze).",
    quelle: "Network – Lernfassung",
    belege: "Fragen – Netzwerk-Grundlagen (net-04 bis net-07) · Cisco Catalyst Command Reference (show mac address-table)",
    siehe: ["lab.arp", "lab.vlan", "lab.portsec"],
  },
  "lab.subnetz": {
    titel: "Adressplan und Subnetting",
    kurz: "Subnetting teilt einen Adressbereich in passende Netze; gerechnet wird mit Blockgröße, Netz-ID und Broadcast.",
    abschnitte: [
      {titel: "Der Rechenweg in fünf Schritten", html:
        "<ul><li>Oktett finden, in dem die Maske nicht 255 ist.</li><li>Blockgröße = 256 − Maskenwert in diesem Oktett.</li><li>Netz-ID = größtes Vielfaches der Blockgröße, das nicht über dem Wert liegt.</li><li>Broadcast = nächste Netz-ID − 1.</li><li>Nutzbare Hosts = 2<sup>Hostbits</sup> − 2 – Ausnahme /31 nach RFC 3021: zwei nutzbare Adressen, /32: eine Adresse.</li></ul>"},
      {titel: "Masken-Tabelle", html:
        "<table><tr><th>Präfix</th><th>Maske (letztes Oktett)</th><th>Block</th><th>Hosts</th></tr>" +
        "<tr><td>/24</td><td>0</td><td>256</td><td>254</td></tr>" +
        "<tr><td>/25</td><td>128</td><td>128</td><td>126</td></tr>" +
        "<tr><td>/26</td><td>192</td><td>64</td><td>62</td></tr>" +
        "<tr><td>/27</td><td>224</td><td>32</td><td>30</td></tr>" +
        "<tr><td>/28</td><td>240</td><td>16</td><td>14</td></tr>" +
        "<tr><td>/29</td><td>248</td><td>8</td><td>6</td></tr>" +
        "<tr><td>/30</td><td>252</td><td>4</td><td>2</td></tr>" +
        "<tr><td>/31</td><td>254</td><td>2</td><td>2</td></tr>" +
        "<tr><td>/32</td><td>255</td><td>1</td><td>1</td></tr></table>" +
        "<p>Die Zeilen /31 und /32 folgen RFC 3021: Bei /31 sind beide Adressen im Block nutzbare Endpunkte (direkte Leitung zwischen zwei Routern), bei /32 ist die eine Adresse für genau einen Host nutzbar. Die Formel „2<sup>Hostbits</sup> − 2“ gilt für /24 bis /30.</p>"},
      {titel: "Präfix zur Hostzahl und VLSM", html:
        "<p>Gesucht ist das kleinste h mit 2<sup>h</sup> − 2 ≥ Hosts, Präfix = 32 − h. 50 Hosts: h = 6, also /26. 63 Hosts passen <b>nicht</b> in /26 (nur 62), also /25.</p>" +
        "<p>Für eine direkte Leitung zwischen zwei Routern ist <b>/31</b> die kleinste sinnvolle Maske (RFC 3021): zwei Adressen im Block, beide nutzbar – eine Netz-ID und ein Broadcast werden dafür nicht reserviert.</p>" +
        "<p><b>VLSM</b>: größtes Netz zuerst vergeben, dann absteigend. Beispiel 10.0.0.0/22: Verwaltung 500 Hosts = 10.0.0.0/23, Produktion 250 = 10.0.2.0/24, Gäste 100 = 10.0.3.0/25, Server 50 = 10.0.3.128/26.</p>"},
      {titel: "IPv6: Präfixe planen und rechnen (Nachschlagen)", html:
        "<p>In IPv6 plant man mit Präfixlängen statt mit Masken. Übliche Vorgaben: <b>/48</b> je Standort, <b>/56</b> für kleine Standorte, <b>/64</b> je LAN. Aus einem /48 werden 65536 /64-Netze – genug für jedes VLAN und jedes Gästenetz.</p>" +
        "<p>Gerechnet wird im Hexadezimalblock, am einfachsten an Nibble-Grenzen (je 4 Bit): /52, /56, /60 und /64 teilen eine Gruppe sauber. Beispiel 2001:db8:aa00::/48:</p>" +
        "<table><tr><th>Netz</th><th>Verwendung</th></tr>" +
        "<tr><td>2001:db8:aa00:0000::/64</td><td>Verwaltung</td></tr>" +
        "<tr><td>2001:db8:aa00:0001::/64</td><td>Behandlung</td></tr>" +
        "<tr><td>2001:db8:aa00:0002::/64</td><td>Gäste</td></tr>" +
        "<tr><td>2001:db8:aa00:00ff::/64</td><td>Reserve, zum Beispiel für Server</td></tr></table>" +
        "<p>Ein /64 hat 64 Hostbits; die Netz-ID liest man aus den ersten vier Blöcken, statt sie auszurechnen. Sonderadressen wie Netz-ID und Broadcast gibt es nicht – jedes Präfix stellt seine Adressen den Geräten zur Verfügung, die letzten 64 Bit sind die Interface-ID. Nur die Interface-ID aus lauter Nullen ist als Subnet-Router-Anycast reserviert (RFC 4291) und wird keinem Gerät gegeben.</p>" +
        "<p><b>Rezept:</b> Standort-Präfix (/48) vom Provider oder aus dem Unique-Local-Bereich nehmen, VLANs nummerieren (VLAN 10 wird Netz 000a), je VLAN ein /64 vergeben, die Router-Advertisements daraus speisen und die Vergabe dokumentieren.</p>" +
        "<p>Ein LAN-Präfix, das nicht /64 lang ist – kürzer wie /48 oder länger wie /80 – bricht SLAAC und einzelne Dienste; deshalb bleibt /64 die Regel. Dieses Labor rechnet mit IPv4; IPv6 steht hier zum Nachschlagen.</p>"},
    ],
    merksatz: "Blockgröße = 256 − Maske; Netz-ID auf dem Pfahl davor, Broadcast kurz vor dem nächsten.",
    pruefungstipp: "Rechenweg hinschreiben (Präfix, Maske, Block, Netz, Broadcast, Hosts). Bei VLSM den Restbereich nennen, das gibt Zusatzpunkte. In IPv6: /48 je Standort, /64 je LAN.",
    quelle: "04-AP1-Netzwerk",
    belege: "07-Uebungen-Subnetting-Szenarien · Fragen – Subnetting · Network – Lernfassung (§ 8) · RFC 3021 (/31 bei Punkt-zu-Punkt-Netzen) · RFC 4291 (IPv6-Adressarchitektur) · RFC 4862 (SLAAC braucht /64) · RFC 4193 (Unique Local)",
    siehe: ["lab.netz", "lab.ip", "lab.vlan"],
  },
  "lab.dhcp": {
    titel: "DHCP (DORA, Pool, Relay)",
    kurz: "DHCP verteilt IP-Adresse, Maske, Gateway und DNS-Server automatisch, in vier Schritten: Discover, Offer, Request, Acknowledge.",
    abschnitte: [
      {titel: "DORA", html:
        "<ul><li><b>Discover</b> (Broadcast, Absender 0.0.0.0): „Gibt es hier einen DHCP-Server?“</li><li><b>Offer</b>: Der Server bietet eine Adresse an.</li><li><b>Request</b> (noch Broadcast): „Ich nehme sie“, so erfahren andere Server, dass ihr Angebot abgelehnt ist.</li><li><b>Acknowledge</b>: Bestätigung samt Leasedauer, Gateway und DNS.</li></ul>" +
        "<p>Ports: Server UDP 67, Client UDP 68. Antwortet niemand, vergibt sich Windows eine APIPA-Adresse aus 169.254.0.0/16.</p>"},
      {titel: "DHCP-Server am Router", html:
        "<pre>R1(config)# ip dhcp excluded-address 192.168.10.1 192.168.10.9\nR1(config)# ip dhcp pool LAN\nR1(dhcp-config)# network 192.168.10.0 255.255.255.0\nR1(dhcp-config)# default-router 192.168.10.1\nR1(dhcp-config)# dns-server 192.168.10.5</pre>" +
        "<p>Ausgeschlossene Adressen bleiben für Router, Server und Drucker. Kontrolle: <code>show ip dhcp binding</code>.</p>"},
      {titel: "Relay über Router hinweg", html:
        "<p>Broadcasts enden am Router. Steht der DHCP-Server in einem anderen Netz oder VLAN, leitet das Gateway der Clients die Anfragen gezielt weiter:</p>" +
        "<pre>R1(config)# interface g0/0.20\nR1(config-subif)# ip helper-address 192.168.10.5</pre>" +
        "<p>Am Client: <code>ipconfig /release</code>, <code>ipconfig /renew</code>, <code>ipconfig /all</code>.</p>"},
      {titel: "IPv6: SLAAC, Router Advertisement und DHCPv6 (Nachschlagen)", html:
        "<p>In IPv6 muss kein Server Adressen verteilen. Ein Router im Netz verschickt regelmäßig <b>Router Advertisements</b> (ICMPv6 Typ 134) mit dem Präfix; daraus bildet sich ein Rechner seine Adresse selbst. Das heißt <b>SLAAC</b>.</p>" +
        "<table><tr><th>Weg</th><th>Wie</th></tr>" +
        "<tr><td>SLAAC</td><td>Präfix aus dem Router Advertisement plus Interface-ID, gebildet aus der MAC oder zufällig</td></tr>" +
        "<tr><td>DHCPv6 mit Adresse</td><td>Setzt der Router das M-Flag, holt der Client die Adresse vom Server</td></tr>" +
        "<tr><td>DHCPv6 ohne Adresse</td><td>Setzt er nur das O-Flag, kommt die Adresse aus SLAAC und DHCPv6 liefert Zusatzangaben wie den DNS-Server</td></tr></table>" +
        "<p>DHCPv6 nutzt UDP 546 am Client und UDP 547 am Server. Statt Discover, Offer, Request, Acknowledge heißen die Nachrichten Solicit, Advertise, Request, Reply.</p>" +
        "<pre>R1(config)# ipv6 unicast-routing\nR1(config)# interface g0/0\nR1(config-if)# ipv6 address 2001:db8:aa00:1::1/64\nR1(config-if)# no shutdown</pre>" +
        "<p><b>Echtes IOS, nicht das Labor:</b> <code>ipv6 unicast-routing</code> und <code>ipv6 address</code> gehören auf echte Router; das Labor kennt keine IPv6-Konfiguration und weist beide Befehle ab.</p>" +
        "<p>Ohne <b>ipv6 unicast-routing</b> verschickt ein Router keine Router Advertisements, dann bleibt den Clients nur die Link-Local-Adresse. Am Provider holt sich ein Router sein Präfix per <b>DHCPv6-Prefix-Delegation</b>. Dieses Labor rechnet mit IPv4; IPv6 steht hier zum Nachschlagen.</p>"},
    ],
    merksatz: "169.254.x.x heißt: DHCP hat nicht geantwortet. Kabel, VLAN, Dienst und Relay prüfen.",
    pruefungstipp: "DORA in der richtigen Reihenfolge, Ports 67/68 und die Bedeutung von APIPA sind Dauerbrenner. In IPv6: SLAAC aus dem Router Advertisement, DHCPv6 nur bei gesetztem M- oder O-Flag.",
    quelle: "Network – Lernfassung",
    belege: "RFC 2131 · RFC 3927 · Cisco IOS DHCP Server Configuration Guide · Fragen – Netzwerk-Grundlagen (net-13, net-17) · RFC 4861 (Router Advertisement) · RFC 4862 (SLAAC) · RFC 8415 (DHCPv6) · Cisco IOS IPv6 Addressing and Basic Connectivity Configuration Guide",
    siehe: ["lab.ip", "lab.rostick", "lab.dns"],
  },
  "lab.dns": {
    titel: "DNS-Namensauflösung",
    kurz: "DNS übersetzt Namen wie server.praxis.local in IP-Adressen, meist per UDP auf Port 53.",
    abschnitte: [
      {titel: "Wie ein Name aufgelöst wird", html:
        "<ul><li>Client schaut in seinen Cache und die hosts-Datei.</li><li>Client fragt seinen eingetragenen DNS-Server (Resolver).</li><li>Der Resolver fragt sich durch: Root-Server, dann TLD-Server (.de), dann den zuständigen (autoritativen) Server.</li><li>Die Antwort wird zwischengespeichert.</li></ul>" +
        "<p>Normale Anfragen laufen über <b>UDP 53</b>, große Antworten über TCP 53.</p>"},
      {titel: "Fehlersuche", html:
        "<table><tr><th>Test</th><th>Ergebnis</th><th>Schluss</th></tr>" +
        "<tr><td>ping per IP</td><td>geht</td><td>Netz in Ordnung</td></tr>" +
        "<tr><td>ping per Name</td><td>„konnte Host … nicht finden“</td><td>DNS-Problem</td></tr>" +
        "<tr><td><code>nslookup name</code></td><td>„Non-existent domain“</td><td>Server erreicht, Eintrag fehlt</td></tr>" +
        "<tr><td><code>ipconfig /all</code></td><td>DNS-Server leer oder extern</td><td>falscher oder kein DNS-Server</td></tr></table>" +
        "<p>Interne Namen kennt nur der interne DNS-Server. Trägt ein PC einen externen DNS-Server ein, gehen Webseiten, aber das Intranet nicht.</p>"},
      {titel: "Eintragstypen und Zonen", html:
        "<table><tr><th>Typ</th><th>Inhalt</th><th>wofür</th></tr>" +
        "<tr><td>A</td><td>IPv4-Adresse</td><td>Name zu Rechner</td></tr>" +
        "<tr><td>AAAA</td><td>IPv6-Adresse</td><td>dasselbe für IPv6</td></tr>" +
        "<tr><td>CNAME</td><td>anderer Name</td><td>Alias, zum Beispiel www auf den Server</td></tr>" +
        "<tr><td>MX</td><td>Mailserver mit Priorität</td><td>Zustellung von E-Mail</td></tr>" +
        "<tr><td>NS</td><td>zuständiger Nameserver</td><td>Delegation einer Zone</td></tr>" +
        "<tr><td>PTR</td><td>Name zur Adresse</td><td>Rückwärtssuche</td></tr>" +
        "<tr><td>TXT</td><td>freier Text</td><td>Nachweise, zum Beispiel SPF für Mail</td></tr></table>" +
        "<p>Derselbe Name darf mehrere A- und AAAA-Einträge haben – der Client nimmt einen erreichbaren. Die Rückwärtssuche läuft über eigene Zonen: <code>in-addr.arpa</code> für IPv4, <code>ip6.arpa</code> für IPv6; dort stehen PTR-Einträge.</p>"},
      {titel: "Cache, TTL und Zonenrand", html:
        "<p>Jeder Eintrag trägt eine <b>TTL</b> in Sekunden: So lange darf ein Resolver die Antwort behalten. Kurze Werte (300 s) helfen vor einem Umzug, lange Werte (86400 s) sparen Anfragen.</p>" +
        "<p>Ein Server ist nur für seine Zone <b>autoritativ</b>; für alles andere fragt er weiter. Deshalb dauert es nach einer Änderung, bis sie überall ankommt – der alte Eintrag liegt noch im Cache. Nachsehen mit <code>nslookup name</code> oder <code>dig</code>; auf echten Systemen fragt <code>nslookup -type=AAAA name</code> gezielt nach IPv6-Adressen – das Labor kennt nur die einfache Form.</p>" +
        "<p><b>Echtes DNS, nicht das Labor:</b> Eintragstypen, Zonen und die TTL-Regeln gelten auf echten DNS-Servern. Die Simulation fragt nur A-Einträge ab (ein Name, eine Adresse) und merkt sich die Antwort für die nächste Auflösung nicht – jede Frage geht wieder über das Netz. Die Konsole zeigt dagegen einen Cache: <code>ipconfig /displaydns</code> listet Einträge mit „Gültigkeitsdauer“ 300 s, <code>ipconfig /flushdns</code> leert ihn; <code>dig</code> zeigt die feste Anzeige-TTL <code>300 IN A</code>.</p>"},
    ],
    merksatz: "Per IP geht, per Name nicht: Es ist DNS.",
    pruefungstipp: "DNS ist der erste Diagnosepunkt, wenn „der Server nicht erreichbar“ ist. Erst IP testen, dann Namen.",
    quelle: "Network – Lernfassung",
    belege: "RFC 1034 · RFC 1035 · Fragen – Netzwerk-Grundlagen (net-18, net-21) · 05-AP2-Infrastruktur-Sicherheit (Serverdienste) · RFC 3596 (AAAA und ip6.arpa)",
    siehe: ["lab.dhcp", "lab.ports", "lab.ping"],
  },
  "lab.ports": {
    titel: "Ports und Dienste (TCP/UDP)",
    kurz: "Ports sind die Adressen auf Schicht 4: Sie sagen, welcher Dienst in einem Rechner gemeint ist.",
    abschnitte: [
      {titel: "Port ist nicht gleich Port", html:
        "<p><b>Fa0/3</b> ist eine Buchse am Switch (Schicht 1/2). <b>443</b> ist eine 16-Bit-Nummer für einen Dienst (Schicht 4). IP-Adresse plus Port heißt <b>Socket</b>. Einen Port öffnet die Anwendung, die auf ihm lauscht.</p>" +
        "<table><tr><th>Bereich</th><th>Name</th></tr><tr><td>0 bis 1023</td><td>Well-known</td></tr><tr><td>1024 bis 49151</td><td>Registered</td></tr><tr><td>49152 bis 65535</td><td>Dynamic (Client-Seite)</td></tr></table>"},
      {titel: "Wichtige Ports", html:
        "<table><tr><th>Port</th><th>Dienst</th><th>Port</th><th>Dienst</th></tr>" +
        "<tr><td>20/21</td><td>FTP</td><td>110/995</td><td>POP3/POP3S</td></tr>" +
        "<tr><td>22</td><td>SSH</td><td>143/993</td><td>IMAP/IMAPS</td></tr>" +
        "<tr><td>25, 587</td><td>SMTP</td><td>443</td><td>HTTPS</td></tr>" +
        "<tr><td>53</td><td>DNS</td><td>445</td><td>SMB (Dateifreigabe)</td></tr>" +
        "<tr><td>67/68</td><td>DHCP</td><td>3389</td><td>RDP</td></tr>" +
        "<tr><td>80</td><td>HTTP</td><td>9100</td><td>Druck (RAW)</td></tr></table>"},
      {titel: "Erreichbar, aber der Dienst nicht", html:
        "<p>Ping klappt, die Verbindung nicht? Dann antwortet der Server auf einen geschlossenen TCP-Port mit <b>RST</b> (Verbindung abgelehnt). Prüf die Portnummer und ob der Dienst unter „Dienste“ eingeschaltet ist. Kommt gar keine Antwort, filtert eher eine Firewall.</p>"},
      {titel: "Drei Bereiche für Portnummern", html:
        "<p>Ports sind 16 Bit lang, also 0 bis 65535, und in drei Bereiche geteilt: 0–1023 sind die bekannten Systemports (HTTP 80, SSH 22), 1024–49151 die registrierten Ports für Anwendungen, 49152–65535 die dynamischen Ports, die ein Client für seine Verbindung wählt. Ein Serverdienst lauscht auf einem festen Port; der Client braucht nur einen freien Port auf seiner Seite.</p>"},
    ],
    merksatz: "Die IP-Adresse findet den Rechner, der Port findet den Dienst.",
    pruefungstipp: "Portliste auswendig, mit Richtung: SMTP sendet (25/587), POP3 und IMAP holen ab.",
    quelle: "04-AP1-Netzwerk",
    belege: "Fragen – Netzwerk-Grundlagen (net-22 bis net-34) · VLAN – Visuelle Lernnotiz (§ 1) · IANA Service Name and Port Number Registry · RFC 6335 (Portnummern-Bereiche)",
    siehe: ["lab.tcp", "lab.fw", "lab.portfwd"],
  },
  "lab.tcp": {
    titel: "TCP-Handshake",
    kurz: "TCP baut vor dem Senden eine Verbindung auf (SYN, SYN/ACK, ACK), nummeriert jedes Byte und bestätigt lückenlos.",
    abschnitte: [
      {titel: "Aufbau mit Nummern", html:
        "<table><tr><th>Richtung</th><th>Flags</th><th>Seq</th><th>Ack</th></tr>" +
        "<tr><td>Client → Server</td><td>SYN</td><td>5000</td><td>–</td></tr>" +
        "<tr><td>Server → Client</td><td>SYN, ACK</td><td>9000</td><td>5001</td></tr>" +
        "<tr><td>Client → Server</td><td>ACK</td><td>5001</td><td>9001</td></tr></table>" +
        "<p>SYN und FIN belegen je eine Sequenznummer, deshalb ist Ack = Seq + 1.</p>"},
      {titel: "Bytes statt Segmente", html:
        "<ul><li><b>Seq</b> = Nummer des ersten Bytes im Segment.</li><li><b>Ack</b> = nächstes erwartetes Byte, kumulativ: Ack 6001 heißt „bis 6000 alles lückenlos da“.</li><li>Fehlt ein Segment, bleibt das Ack an der Lücke stehen; nach drei doppelten Acks sendet der Sender sofort neu.</li></ul>"},
      {titel: "Ende und Abbruch", html:
        "<p><b>FIN</b> setzt der Sender einer Richtung, wenn er nichts mehr senden will; Abbau mit FIN, ACK, FIN, ACK. <b>RST</b> ist kein geordneter Abbau, sondern ein Abbruch, zum Beispiel als Antwort auf einen geschlossenen Port.</p>"},
      {titel: "Das Fenster: Flusskontrolle", html:
        "<p>TCP nummeriert nicht nur Bytes, es bremst auch: Der Empfänger meldet im Feld <b>Window</b>, wie viele Bytes er noch aufnehmen kann. Der Sender darf höchstens so viel Ungesichertes schicken; geht das Fenster auf 0, pausiert er. So überrollt ein schneller Sender keinen langsamen Empfänger – fehlende Segmente werden per Fast Retransmit wiederholt.</p>"},
    ],
    merksatz: "SYN, SYN/ACK, ACK: erst anklopfen, dann reden.",
    pruefungstipp: "Ack ist das nächste erwartete Byte, nicht das zuletzt empfangene.",
    quelle: "TCP – Lernfassung",
    belege: "RFC 9293 · RFC 5681 (Fast Retransmit) · Fragen – Netzwerk-Grundlagen (net-42 bis net-49)",
    siehe: ["lab.ports", "lab.fw"],
  },
  "lab.cli": {
    titel: "IOS-Konsole: Modi und Grundbefehle",
    kurz: "Die Konsole von Router und Switch arbeitet in Modi; der Prompt zeigt dir immer, wo du gerade bist.",
    abschnitte: [
      {titel: "Modi und Prompts", html:
        "<table><tr><th>Prompt</th><th>Modus</th><th>Hinein mit</th></tr>" +
        "<tr><td><code>R1&gt;</code></td><td>Benutzermodus (nur ansehen)</td><td>Anmelden</td></tr>" +
        "<tr><td><code>R1#</code></td><td>Privilegierter Modus</td><td><code>enable</code></td></tr>" +
        "<tr><td><code>R1(config)#</code></td><td>Globale Konfiguration</td><td><code>configure terminal</code></td></tr>" +
        "<tr><td><code>R1(config-if)#</code></td><td>Schnittstelle</td><td><code>interface g0/0</code></td></tr>" +
        "<tr><td><code>R1(config-subif)#</code></td><td>Unterschnittstelle</td><td><code>interface g0/0.10</code></td></tr>" +
        "<tr><td><code>SW1(config-vlan)#</code></td><td>VLAN</td><td><code>vlan 10</code></td></tr></table>" +
        "<p><code>exit</code> geht eine Ebene zurück, <code>end</code> direkt in den privilegierten Modus.</p>"},
      {titel: "Bedienung", html:
        "<ul><li><b>Abkürzen</b>, solange eindeutig: <code>sh ip int br</code> = <code>show ip interface brief</code>.</li><li><b>?</b> zeigt die möglichen Wörter an dieser Stelle, <b>Tab</b> vervollständigt.</li><li><b>no</b> vor einem Befehl nimmt ihn zurück: <code>no shutdown</code>.</li><li><b>do</b> führt im Konfigurationsmodus einen show-Befehl aus: <code>do show ip route</code>.</li></ul>"},
      {titel: "Fehlermeldungen", html:
        "<table><tr><th>Meldung</th><th>Bedeutung</th></tr>" +
        "<tr><td>% Invalid input detected at '^' marker.</td><td>Tippfehler oder falscher Modus; das ^ zeigt die Stelle</td></tr>" +
        "<tr><td>% Incomplete command.</td><td>Es fehlt noch etwas, zum Beispiel die Maske</td></tr>" +
        "<tr><td>% Ambiguous command: \"…\"</td><td>Abkürzung passt auf mehrere Befehle</td></tr></table>"},
      {titel: "Der Kontext entscheidet", html:
        "<p>Derselbe Befehl bedeutet je Modus etwas anderes: <code>show ip interface brief</code> gehört in den privilegierten Modus, <code>interface Gi0/0</code> in die globale Konfiguration, <code>shutdown</code> in den Schnittstellenmodus. Der Prompt verrät den Kontext. Mit <code>end</code> springt man aus jeder Konfiguration zurück in den privilegierten Modus, mit <code>exit</code> eine Ebene nach oben.</p>"},
    ],
    merksatz: "Erst den Prompt lesen, dann tippen.",
    pruefungstipp: "Befehle in der Prüfung mit Modus angeben, zum Beispiel „im Schnittstellenmodus: ip address …“.",
    quelle: "VLAN – Lernfassung",
    belege: "Cisco IOS Configuration Fundamentals Configuration Guide: Using the Command-Line Interface",
    siehe: ["lab.speichern", "lab.link", "lab.vlan"],
  },
  "lab.speichern": {
    titel: "running- und startup-config",
    kurz: "Änderungen gelten sofort, sind aber nur im RAM; erst das Speichern schreibt sie dauerhaft in den NVRAM.",
    abschnitte: [
      {titel: "Wo was liegt", html:
        "<table><tr><th>Speicher</th><th>Inhalt</th><th>nach Stromausfall</th></tr>" +
        "<tr><td>RAM</td><td>running-config: was gerade gilt</td><td>weg</td></tr>" +
        "<tr><td>NVRAM</td><td>startup-config: wird beim Start geladen</td><td>bleibt</td></tr>" +
        "<tr><td>Flash</td><td>Betriebssystem, beim Switch die VLAN-Datenbank vlan.dat</td><td>bleibt</td></tr></table>"},
      {titel: "Befehle", html:
        "<pre>R1# copy running-config startup-config\nDestination filename [startup-config]?   ← Enter\nR1# write memory\nR1# show startup-config\nR1# reload</pre>" +
        "<p><code>copy running-config startup-config</code> und <code>write memory</code> tun dasselbe. Im Labor fragt der Router nach dem Zielnamen – <b>Enter</b> bestätigt ihn; wer stattdessen den nächsten Befehl tippt, beantwortet damit die Rückfrage und bekommt eine Fehlermeldung. Auch <code>reload</code> fragt nach: ungesicherte Änderungen speichern? Wer vor dem Stromausfall nicht gespeichert hat, startet mit der alten startup-config.</p>"},
      {titel: "Zurücksetzen und die VLAN-Falle", html:
        "<p><code>erase startup-config</code> (oder <code>write erase</code>) löscht nur die startup-config. Die VLANs eines Switches stehen aber in <code>flash:vlan.dat</code> und überleben das. Vollständig zurücksetzen:</p>" +
        "<pre>SW1# erase startup-config\nSW1# delete flash:vlan.dat\nSW1# reload</pre>" +
        "<p><b>Rückfragen beantworten:</b> „Erasing the nvram filesystem … Continue? [confirm]“ → <b>Enter</b> · " +
        "bei <code>delete flash:vlan.dat</code> zweimal <b>Enter</b> (Dateiname und Bestätigung) · " +
        "<code>reload</code> fragt „System configuration has been modified. Save? [yes/no]:“ → <b>no</b> · " +
        "„Proceed with reload? [confirm]“ → <b>Enter</b>. Wichtig: Auf „Save? [yes/no]“ mit Enter zu antworten sichert die " +
        "laufende Konfiguration und macht das Zurücksetzen zunichte – die VLANs wären dann zwar weg, die alte Konfiguration käme " +
        "beim Neustart aber zurück.</p>" +
        "<p>Bei gebrauchten Geräten deshalb immer auch vlan.dat prüfen (<code>show flash:</code>).</p>"},
      {titel: "Speichern ist keine Sicherung", html:
        "<p>Die startup-config ist eine Arbeitskopie im Gerät, keine Sicherung: Sie liegt im selben Gerät und ist nach einem Defekt oder einem <code>erase</code> weg. Eine echte Sicherung kopiert die Konfiguration heraus (etwa per TFTP), hält mehrere Stände und liegt getrennt vom Gerät. Nach jeder Änderung: speichern, Stand sichern, Änderung notieren.</p>"},
    ],
    merksatz: "Nicht gespeichert heißt: beim nächsten Neustart vergessen.",
    pruefungstipp: "RAM, NVRAM und Flash sauber zuordnen können; running = RAM, startup = NVRAM.",
    quelle: "Netzwerk 29.09",
    belege: "Cisco IOS Configuration Fundamentals Configuration Guide (Managing Configuration Files) · Cisco Catalyst Software Configuration Guide: Configuring VLANs (vlan.dat)",
    siehe: ["lab.cli", "lab.vlan"],
  },
  "lab.vlan": {
    titel: "VLANs und Access-Ports",
    kurz: "Ein VLAN teilt einen Switch in mehrere logische Switches; jedes VLAN ist eine eigene Broadcast-Domäne und bekommt ein eigenes IP-Netz.",
    abschnitte: [
      {titel: "Wozu", html:
        "<ul><li><b>Sicherheit</b>: Abteilungen und Gäste getrennt, Übergänge nur über Router oder Firewall mit Regeln.</li><li><b>Weniger Broadcasts</b>: Eine Durchsage erreicht nur das eigene VLAN.</li><li><b>Ordnung</b>: Ein Umzug ist eine Portänderung, kein Umstecken.</li></ul>"},
      {titel: "Einrichten in drei Schritten", html:
        "<pre>SW1(config)# vlan 10\nSW1(config-vlan)# name Verwaltung\nSW1(config)# interface fa0/1\nSW1(config-if)# switchport mode access\nSW1(config-if)# switchport access vlan 10</pre>" +
        "<p>Kontrolle mit <code>show vlan brief</code>: Welche Ports stecken in welchem VLAN? Ein Access-Port gehört zu genau einem VLAN, Frames laufen dort ohne Tag.</p>"},
      {titel: "VLAN 1 und der Weg zwischen VLANs", html:
        "<p>Ab Werk steckt jeder Port in <b>VLAN 1</b> (Default VLAN). Ein Port, den du vergessen hast, bleibt also im VLAN 1. Zwischen zwei VLANs gibt es nur einen Weg: über <b>Schicht 3</b>, also einen Router (Router-on-a-Stick) oder einen Layer-3-Switch.</p>"},
      {titel: "WLAN und VLAN: eine SSID, ein Netz", html:
        "<p>Jede SSID gehört zu genau einem VLAN. Der Access Point taggt die Frames seiner Funknetze und schiebt sie über einen <b>Trunk</b> zum Switch: Für den Switch ist der AP ein Gerät mit mehreren VLANs, für den Funkclient ist seine SSID ein Access-Port.</p>" +
        "<pre>SW1(config)# interface g0/2\nSW1(config-if)# switchport mode trunk\nSW1(config-if)# switchport trunk allowed vlan 10,20,30</pre>" +
        "<ul><li><b>Gästenetz</b>: eigene SSID im eigenen VLAN und eigenen IP-Bereich, Übergang nur ins Internet – nie ins Verwaltungsnetz.</li><li><b>Management</b>: eigenes VLAN für die APs selbst; die Verwaltungsoberfläche gehört nicht ins Gästenetz.</li><li><b>Ein IP-Netz je VLAN</b>: Jede SSID bekommt ihren eigenen Adressbereich und ihr eigenes Gateway – genau wie eine Abteilung am Kabel.</li><li><b>Mehrere APs, eine SSID</b>: Geräte wechseln die Zelle, wenn die Feldstärke nachlässt (Roaming). Damit das ohne Adresswechsel klappt, hängen alle APs im selben VLAN.</li></ul>" +
        "<p>Größere Anlagen steuert ein <b>WLAN-Controller</b>: Er verteilt SSIDs und Kanäle an alle APs. Ob der Datenverkehr am AP lokal ins Kabel geht oder gebündelt über den Controller läuft, hängt von der Betriebsart ab; im lokalen Betrieb bleibt die Trennung der Netze am Switch.</p>"},
    ],
    merksatz: "Ein VLAN = eine Broadcast-Domäne = ein IP-Netz.",
    pruefungstipp: "Kommunikation zwischen VLANs braucht immer einen Router oder Layer-3-Switch, das ist eine klassische AP-Frage. Im WLAN gilt dasselbe: eine SSID, ein VLAN, ein IP-Netz.",
    quelle: "VLAN – Lernfassung",
    belege: "VLAN – Visuelle Lernnotiz · IEEE 802.1Q · Fragen – Netzwerke planen (nwp-01 bis nwp-03) · IEEE 802.11 (SSID und Funkzelle) · BSI IT-Grundschutz-Kompendium, NET.2.1 WLAN-Betrieb",
    siehe: ["lab.trunk", "lab.rostick", "lab.switch", "lab.link"],
  },
  "lab.trunk": {
    titel: "Trunk und 802.1Q",
    kurz: "Ein Trunk ist eine Verbindung, die Frames mehrerer VLANs transportiert und sie dafür mit einem 802.1Q-Tag markiert.",
    abschnitte: [
      {titel: "Der Tag", html:
        "<p>4 Byte, eingefügt zwischen Quell-MAC und EtherType:</p>" +
        "<table><tr><th>Feld</th><th>Bit</th><th>Inhalt</th></tr><tr><td>TPID</td><td>16</td><td>0x8100, kündigt den Tag an</td></tr><tr><td>PCP</td><td>3</td><td>Priorität</td></tr><tr><td>DEI</td><td>1</td><td>darf bei Überlast verworfen werden</td></tr><tr><td>VID</td><td>12</td><td>VLAN-Nummer, 1 bis 4094</td></tr></table>"},
      {titel: "Einrichten und prüfen", html:
        "<pre>SW1(config)# interface g0/1\nSW1(config-if)# switchport mode trunk\nSW1(config-if)# switchport trunk allowed vlan 10,20,30\nSW1(config-if)# switchport trunk native vlan 99</pre>" +
        "<p><code>show interfaces trunk</code> zeigt Trunks, Native VLAN und erlaubte VLANs. Auf echter Hardware schaltet zusätzlich <code>switchport nonegotiate</code> das Aushandeln ab – das Labor kennt dieses Kommando nicht und weist es ab.</p>"},
      {titel: "Die drei Fallen", html:
        "<ul><li><code>switchport trunk allowed vlan 40</code> <b>ersetzt</b> die Liste. Ergänzen geht mit <code>switchport trunk allowed vlan add 40</code>.</li><li>Das <b>Native VLAN</b> läuft ohne Tag und muss auf beiden Seiten gleich sein, sonst laufen zwei VLANs ineinander.</li><li>Endgeräte gehören an Access-Ports: Am Trunk könnten sie selbst Tags setzen und in fremde VLANs senden.</li></ul>"},
      {titel: "Trunk oder Access: wer entscheidet", html:
        "<p>Ob ein Port Trunk oder Access wird, entscheidet die Gegenstelle: Endgeräte wie PCs, Drucker und Server hängen fast immer an Access-Ports und kennen keine Tags; Switches und Router verbinden sich über Trunks, wenn mehrere VLANs über eine Leitung sollen. Ein Access-Port am Uplink schneidet alle VLANs bis auf eines ab – ein häufiger Grund, warum ein Raum kein Netz hat.</p>"},
    ],
    merksatz: "Native = nackt: das VLAN ohne Tag auf dem Trunk.",
    pruefungstipp: "Tag 4 Byte, VLAN-ID 12 Bit: zwei verschiedene Fragen, zwei verschiedene Antworten.",
    quelle: "VLAN – Lernfassung",
    belege: "IEEE 802.1Q · VLAN – Visuelle Lernnotiz (§ 5, § 8) · Cisco Catalyst Software Configuration Guide: Configuring VLAN Trunks",
    siehe: ["lab.vlan", "lab.rostick"],
  },
  "lab.rostick": {
    titel: "Router-on-a-Stick",
    kurz: "Ein Router verbindet mehrere VLANs über eine einzige Leitung: ein Trunk, eine Unterschnittstelle je VLAN.",
    abschnitte: [
      {titel: "Aufbau", html:
        "<ul><li>Switchport zum Router: <b>Trunk</b>.</li><li>Router: physische Schnittstelle einschalten, keine IP darauf.</li><li>Je VLAN eine <b>Unterschnittstelle</b> mit Tag-Nummer und IP. Diese IP ist das <b>Gateway</b> der PCs in diesem VLAN.</li></ul>"},
      {titel: "Konfiguration", html:
        "<pre>R1(config)# interface g0/0\nR1(config-if)# no shutdown\nR1(config)# interface g0/0.10\nR1(config-subif)# encapsulation dot1Q 10\nR1(config-subif)# ip address 192.168.10.1 255.255.255.0\nR1(config)# interface g0/0.20\nR1(config-subif)# encapsulation dot1Q 20\nR1(config-subif)# ip address 192.168.20.1 255.255.255.0</pre>" +
        "<p>Reihenfolge beachten: erst <code>encapsulation dot1Q</code>, dann die IP-Adresse. Die Zahl hinter <code>dot1Q</code> muss zur VLAN-Nummer passen, die Nummer hinter dem Punkt ist nur ein Name.</p>"},
      {titel: "Typische Fehler", html:
        "<table><tr><th>Fehler</th><th>Folge</th></tr>" +
        "<tr><td>Switchport zum Router ist Access</td><td>keine getaggten Frames, die VLANs erreichen den Router nicht</td></tr>" +
        "<tr><td>falsche Zahl bei encapsulation dot1Q</td><td>dieses VLAN erreicht sein Gateway nicht</td></tr>" +
        "<tr><td>physische Schnittstelle shutdown</td><td>alle Unterschnittstellen sind mit aus</td></tr>" +
        "<tr><td>VLAN auf dem Trunk nicht erlaubt</td><td>nur dieses VLAN bleibt stumm</td></tr></table>"},
      {titel: "Warum die physische Schnittstelle leer bleibt", html:
        "<p>Die physische Schnittstelle ist nur das Transportrohr zum Trunk und trägt keine eigene IP. Jede Unterschnittstelle bekommt die Gateway-Adresse ihres VLANs; anhand des 802.1Q-Tags entscheidet der Router, welche Unterschnittstelle den Frame bearbeitet. Eine Adresse auf der physischen Schnittstelle würde die Zuordnung ungetaggter Frames unklar machen – deshalb bleibt sie leer.</p>"},
    ],
    merksatz: "Eine Leitung, viele VLANs: Trunk am Switch, Unterschnittstellen am Router.",
    pruefungstipp: "Als Alternative immer den Layer-3-Switch nennen können.",
    quelle: "VLAN – Visuelle Lernnotiz",
    belege: "VLAN – Lernfassung (§ 1 Korrektur 6) · Cisco IOS: Configuring Routing Between VLANs with IEEE 802.1Q Encapsulation",
    siehe: ["lab.trunk", "lab.vlan", "lab.gateway", "lab.acl"],
  },
  "lab.acl": {
    titel: "Access-Listen (ACL)",
    kurz: "Eine ACL ist eine Regelliste am Router, die Pakete nach Adresse, Protokoll und Port erlaubt oder verwirft.",
    abschnitte: [
      {titel: "Standard und erweitert", html:
        "<table><tr><th></th><th>Standard</th><th>Erweitert</th></tr>" +
        "<tr><td>Nummern</td><td>1 bis 99, 1300 bis 1999</td><td>100 bis 199, 2000 bis 2699</td></tr>" +
        "<tr><td>prüft</td><td>nur die Quelladresse</td><td>Quelle, Ziel, Protokoll, Port</td></tr>" +
        "<tr><td>Platz</td><td>möglichst nah am Ziel</td><td>möglichst nah an der Quelle</td></tr></table>" +
        "<p>Statt Nummern gehen auch Namen: <code>ip access-list extended GAST</code>.</p>"},
      {titel: "Regeln lesen", html:
        "<ul><li>Von oben nach unten, die <b>erste passende Regel</b> gewinnt, danach wird nicht weitergesucht.</li><li>Am Ende steht unsichtbar <b>deny any</b>: Was nicht erlaubt ist, ist verboten.</li><li><b>Wildcard</b>: 0 = muss passen, 1 = egal. /24 → <code>0.0.0.255</code>, einzelner Host → <code>host 10.0.0.5</code>, alles → <code>any</code>.</li></ul>"},
      {titel: "Beispiel: Gäste vom Praxisnetz trennen", html:
        "<pre>R1(config)# ip access-list extended GAST\nR1(config-ext-nacl)# deny ip 192.168.30.0 0.0.0.255 192.168.10.0 0.0.0.255\nR1(config-ext-nacl)# permit ip any any\nR1(config)# interface g0/0.30\nR1(config-subif)# ip access-group GAST in</pre>" +
        "<p><code>show access-lists</code> zeigt jede Regel mit ihren Treffern („matches“).</p>"},
      {titel: "Was eine ACL nicht kann", html:
        "<p>Eine ACL ist zustandslos: Sie prüft jedes Paket für sich, ohne Verbindungen zu kennen. Der Rückverkehr einer erlaubten Verbindung braucht deshalb eine eigene Regel – oder man überlässt das einer zustandsbehafteten Firewall. Zwischen zwei Ports desselben Switches filtert eine Router-ACL nicht; dort helfen VLANs oder Port-Security.</p>"},
    ],
    merksatz: "Erste passende Regel gewinnt, am Ende ist alles verboten.",
    pruefungstipp: "Eine zu allgemeine Regel oben verdeckt alle darunter; die Reihenfolge ist fast immer der Kern der Aufgabe.",
    quelle: "Infrastruktur & Sicherheit – Visuelle Lernnotiz",
    belege: "Cisco IOS Security Configuration Guide: IP Access Lists · 05-AP2-Infrastruktur-Sicherheit (Firewall-Grundregeln)",
    siehe: ["lab.fw", "lab.rostick", "lab.nat"],
  },
  "lab.route": {
    titel: "Statische Routen und Default-Route",
    kurz: "Ein Router kennt von selbst nur seine direkt angeschlossenen Netze; alle anderen lernt er über Routen.",
    abschnitte: [
      {titel: "Die Routingtabelle", html:
        "<table><tr><th>Kennung</th><th>Bedeutung</th></tr>" +
        "<tr><td>C</td><td>direkt angeschlossen (connected)</td></tr>" +
        "<tr><td>L</td><td>eigene Adresse der Schnittstelle (local, /32)</td></tr>" +
        "<tr><td>S</td><td>statisch eingetragen</td></tr>" +
        "<tr><td>S*</td><td>statische Default-Route</td></tr></table>" +
        "<p>Gibt es mehrere passende Einträge, gewinnt der mit dem <b>längsten Präfix</b> (der genaueste).</p>"},
      {titel: "Befehle", html:
        "<pre>R1(config)# ip route 10.0.2.0 255.255.255.0 10.0.1.2\nR1(config)# ip route 0.0.0.0 0.0.0.0 203.0.113.1\nR1# show ip route</pre>" +
        "<p>Die erste Zeile: Netz 10.0.2.0/24 liegt hinter dem Nachbarn 10.0.1.2. Die zweite: alles andere zum Provider (Default-Route, „Gateway of last resort“).</p>"},
      {titel: "Die Rückroute nicht vergessen", html:
        "<p>Routen gelten nur in eine Richtung. Kommt der Ping an, die Antwort aber nicht zurück, fehlt auf einem Router des Rückwegs die Route zum Netz des Absenders. Symptom: Zeitüberschreitung statt „nicht erreichbar“.</p>"},
      {titel: "Der längste Treffer gewinnt", html:
        "<p>Passen mehrere Routen zu einer Zieladresse, gewinnt die mit dem längsten Präfix – nicht die mit der kleinsten Metrik. Ein /24 schlägt also eine /16, und beide schlagen die Default-Route 0.0.0.0/0, die nur als letzter Ausweg dient. Deshalb ist die Default-Route kein Internet-Befehl, sondern die allgemeinste Regel der Tabelle.</p>"},
    ],
    merksatz: "Hin braucht eine Route, zurück auch.",
    pruefungstipp: "Default-Route = 0.0.0.0/0. Statisch: einfach, aber passt sich nicht an Ausfälle an; dynamisch: Router tauschen Routen per Protokoll.",
    quelle: "Fragen – Netzwerke planen",
    belege: "Cisco IOS IP Routing: Static Routing Configuration Guide · Network – Lernfassung (§ 0)",
    siehe: ["lab.gateway", "lab.ttl", "lab.nat"],
  },
  "lab.ttl": {
    titel: "TTL und Traceroute",
    kurz: "Die TTL im IP-Header begrenzt, über wie viele Router ein Paket laufen darf; Traceroute macht sich das zunutze.",
    abschnitte: [
      {titel: "TTL", html:
        "<ul><li>8-Bit-Feld im IP-Header, gesetzt vom Absender (Windows meist 128, Linux 64).</li><li>Jeder Router zieht <b>1 ab</b>. Bei 0 wird das Paket verworfen, der Absender bekommt ICMP <b>Time Exceeded</b> (Typ 11).</li><li>So kreist ein Paket in einer Routingschleife nicht ewig.</li></ul>" +
        "<p>Aus der TTL einer Antwort lässt sich schätzen, wie viele Router dazwischen lagen: TTL=126 bei Start 128 heißt zwei Router.</p>"},
      {titel: "Traceroute", html:
        "<p>Traceroute sendet Pakete mit TTL 1, 2, 3 … Jeder Router, bei dem die TTL auf 0 fällt, meldet sich und verrät so seine Adresse. Windows: <code>tracert</code> (ICMP), Router: <code>traceroute</code>.</p>" +
        "<table><tr><th>Ausgabe</th><th>Bedeutung</th></tr>" +
        "<tr><td>Zeile mit Adresse</td><td>dieser Router ist Station n</td></tr>" +
        "<tr><td><code>*</code> bzw. Zeitüberschreitung</td><td>keine Antwort von dieser Station</td></tr>" +
        "<tr><td>zwei Adressen wechseln sich ab</td><td>Routingschleife</td></tr></table>"},
      {titel: "Traceroute in der Praxis", html:
        "<p>Jede Station wird mehrfach gefragt, deshalb stehen je Zeile meist drei Zeiten. Die Namen der Router verraten oft den Standort – und den Provider.</p>" +
        "<table><tr><th>Werkzeug</th><th>sendet</th><th>Hinweis</th></tr>" +
        "<tr><td><code>tracert</code> (Windows)</td><td>ICMP-Echo</td><td>ohne Zusatzprogramm nutzbar</td></tr>" +
        "<tr><td><code>traceroute</code> (Linux)</td><td>UDP auf hohe Ports</td><td>die Antwort kommt als ICMP-Fehler zurück</td></tr>" +
        "<tr><td><code>traceroute</code> (IOS)</td><td>UDP oder ICMP</td><td>am Router auch im Konfigurationsmodus mit <code>do</code></td></tr></table>" +
        "<p>Filtert ein Netz ICMP, bleiben Zeilen leer: Die Station ist da, sie meldet sich nur nicht. Wiederholen sich zwei Adressen mehrfach, läuft der Verkehr im Kreis – dieselbe Vermutung wie bei einem Ping, der nie ankommt. Auf echtem Windows sendet <code>pathping</code> mehr Pakete und rechnet den Verlust je Station aus; im Labor zeigt <code>pathping</code> sofort dieselben Stationen wie <code>tracert</code> und rechnet 0 % Verlust, solange Antworten kommen.</p>"},
      {titel: "IPv6: Hop Limit statt TTL", html:
        "<p>IPv6 führt kein Feld „TTL“, sondern das <b>Hop Limit</b> – ebenfalls 8 Bit und mit derselben Aufgabe: Jeder Router zieht eins ab, bei 0 wird das Paket verworfen, und der Absender bekommt ICMPv6 „Time Exceeded“ (Typ 3).</p>" +
        "<ul><li>Der IPv6-Kopf ist fest 40 Byte lang, Erweiterungen hängen dahinter.</li><li>Der Absender setzt meist 64 (Linux) oder 128 (Windows) – wie bei IPv4.</li><li>Traceroute arbeitet gleich: Pakete mit Hop Limit 1, 2, 3 …</li><li>Ein Router, der kein ICMPv6 sendet, erscheint als leere Zeile.</li></ul>" +
        "<p>Dieses Labor rechnet mit IPv4; dieses Feld steht hier zum Nachschlagen für die Prüfung und für echte Netze.</p>"},
    ],
    merksatz: "Die TTL sinkt an jedem Router um 1, nie steigt sie.",
    pruefungstipp: "Beliebter Fehler: „TTL wird erhöht“. Richtig ist: verringert, bei 0 verworfen. In IPv6 heißt dasselbe Feld Hop Limit.",
    quelle: "Network – Lernfassung",
    belege: "RFC 791 · RFC 792 · Netzwerk – Geschichten (Station für Station) · Cisco: Understanding the Ping and Traceroute Commands · Microsoft Learn: tracert, pathping · RFC 8200 (Hop Limit) · RFC 4443 (ICMPv6 Time Exceeded)",
    siehe: ["lab.route", "lab.ping", "lab.ip"],
  },
  "lab.nat": {
    titel: "NAT und PAT",
    kurz: "NAT ersetzt private Absenderadressen durch eine öffentliche, weil private Adressen im Internet nicht geroutet werden.",
    abschnitte: [
      {titel: "Warum und wie", html:
        "<ul><li>Private Bereiche (RFC 1918) darf jedes LAN verwenden, im Internet werden sie nicht geroutet.</li><li>Der Router tauscht auf dem Weg nach draußen die Quelladresse gegen seine öffentliche und merkt sich die Zuordnung, damit die Antwort zurückfindet.</li><li><b>PAT</b> (NAT-Overload): Viele Innenadressen teilen sich eine Außenadresse, unterschieden über die Ports.</li></ul>"},
      {titel: "PAT am Router", html:
        "<pre>R1(config)# access-list 1 permit 192.168.1.0 0.0.0.255\nR1(config)# ip nat inside source list 1 interface g0/1 overload\nR1(config)# interface g0/0\nR1(config-if)# ip nat inside\nR1(config)# interface g0/1\nR1(config-if)# ip nat outside</pre>" +
        "<p><b>inside</b> = LAN-Seite, <b>outside</b> = Internet-Seite. Kontrolle: <code>show ip nat translations</code>.</p>"},
      {titel: "Fehlerbilder", html:
        "<ul><li>inside und outside vertauscht: keine Übersetzung, Timeout.</li><li>Die Access-Liste erfasst das LAN nicht: nur manche Rechner kommen raus.</li><li>Keine Default-Route zum Provider: Das Paket kommt gar nicht bis zur Übersetzung.</li></ul>"},
      {titel: "Was die NAT-Tabelle hält", html:
        "<p>Für jede übersetzte Verbindung merkt sich der Router die Zuordnung von privater Adresse und Port zu öffentlicher Adresse und Port samt Zeitstempel. Antworten von außen findet er über diesen Eintrag zurück. Bleibt lange kein Paket einer Verbindung, verfällt der Eintrag; PAT kann dieselbe öffentliche Adresse deshalb für viele Clients gleichzeitig nutzen – unterschieden werden sie über den Port.</p>"},
    ],
    merksatz: "inside = drinnen (LAN), outside = draußen (Internet).",
    pruefungstipp: "NAT gegen PAT: NAT übersetzt Adressen, PAT bildet viele Adressen über Ports auf eine ab, wie am DSL-Router.",
    quelle: "Network – Lernfassung",
    belege: "RFC 1918 · RFC 3022 · Cisco IOS NAT Configuration Guide · Fragen – Netzwerke planen (nwp-10)",
    siehe: ["lab.portfwd", "lab.route", "lab.acl"],
  },
  "lab.portfwd": {
    titel: "Port-Weiterleitung",
    kurz: "Eine Port-Weiterleitung (statisches NAT mit Port) macht einen Dienst im LAN von außen erreichbar.",
    abschnitte: [
      {titel: "Warum PAT allein nicht reicht", html:
        "<p>PAT legt Einträge nur an, wenn eine Verbindung <b>von innen</b> startet. Kommt eine Anfrage von außen, weiß der Router ohne festen Eintrag nicht, welcher Rechner gemeint ist.</p>"},
      {titel: "Befehl", html:
        "<pre>R1(config)# ip nat inside source static tcp 192.168.1.50 443 203.0.113.2 443</pre>" +
        "<p>Anfragen an 203.0.113.2, TCP-Port 443, landen bei 192.168.1.50, Port 443. Außen- und Innenport dürfen verschieden sein, zum Beispiel außen 2222 auf innen 22.</p>"},
      {titel: "Mit Bedacht", html:
        "<ul><li>Nur weiterleiten, was wirklich gebraucht wird (Least Privilege).</li><li>Öffentliche Dienste gehören besser in eine <b>DMZ</b>, dann steht ein übernommener Server nicht mitten im LAN.</li><li>Für Fernzugriff auf Arbeitsplätze ist ein <b>VPN</b> die bessere Wahl als offene Ports.</li></ul>"},
      {titel: "Ein Port, ein Ziel", html:
        "<p>Eine Port-Weiterleitung bildet einen öffentlichen Port auf genau einen Rechner und Port im LAN ab – zwei Server können sich denselben Außenport nicht teilen. Braucht man mehrere Dienste, wählt man unterschiedliche Außenports oder setzt einen Reverse-Proxy davor. Grundsatz: nur die Ports weiterleiten, die wirklich von außen erreichbar sein müssen.</p>"},
    ],
    merksatz: "Von außen findet nur, wer einen festen Eintrag hat.",
    pruefungstipp: "Begründung für DMZ statt Weiterleitung ins LAN: Wird der Server übernommen, schützt die zweite Grenze das interne Netz.",
    quelle: "05-AP2-Infrastruktur-Sicherheit",
    belege: "Cisco IOS NAT Configuration Guide (Static NAT with port) · RFC 3022 · Infrastruktur & Sicherheit – Visuelle Lernnotiz (DMZ)",
    siehe: ["lab.nat", "lab.dmz", "lab.fw"],
  },
  "lab.fw": {
    titel: "Firewall-Regeln und Zonen",
    kurz: "Eine Firewall erlaubt oder verwirft Verkehr zwischen Zonen nach einer Regeltabelle, die von oben nach unten gelesen wird.",
    abschnitte: [
      {titel: "Zonen und Regeln", html:
        "<p>Jede Schnittstelle gehört zu einer Zone: <b>innen</b> (LAN), <b>außen</b> (Internet), <b>DMZ</b>. Eine Regel sagt: von Zone, nach Zone, Protokoll, Port, erlauben oder verwerfen.</p>" +
        "<table><tr><th>Nr</th><th>von</th><th>nach</th><th>Dienst</th><th>Aktion</th></tr>" +
        "<tr><td>1</td><td>innen</td><td>außen</td><td>tcp 443</td><td>erlauben</td></tr>" +
        "<tr><td>2</td><td>innen</td><td>außen</td><td>udp 53</td><td>erlauben</td></tr>" +
        "<tr><td>3</td><td>alle</td><td>alle</td><td>alles</td><td>verwerfen</td></tr></table>"},
      {titel: "Grundsätze", html:
        "<ul><li><b>Deny by default</b>: Was nicht ausdrücklich erlaubt ist, ist verboten.</li><li><b>Erste passende Regel gewinnt</b>: Eine „alles verbieten“-Regel ganz oben sperrt alles.</li><li><b>Zustandsbehaftet</b>: Antworten auf erlaubte Verbindungen kommen automatisch zurück, dafür braucht es keine eigene Regel.</li><li>Nur benötigte Ports öffnen und jede Regel dokumentieren.</li></ul>"},
      {titel: "Arten von Firewalls", html:
        "<table><tr><th>Art</th><th>Blick auf</th><th>Grenze</th></tr>" +
        "<tr><td>Paketfilter</td><td>Kopfzeilen: Adresse, Protokoll, Port</td><td>kennt keinen Zusammenhang, Regeln in beide Richtungen nötig</td></tr>" +
        "<tr><td>Stateful Inspection</td><td>Verbindungen samt Zustand</td><td>verschlüsselte Inhalte bleiben unsichtbar</td></tr>" +
        "<tr><td>Application Firewall / NGFW</td><td>Anwendung, Benutzer, Inhalte</td><td>mehr Prüftiefe, mehr Pflege und Rechenlast</td></tr>" +
        "<tr><td>Proxy</td><td>vermittelt selbst, oft mit Zwischenspeicher</td><td>muss die Anwendung kennen, kein reiner Durchlauf</td></tr></table>" +
        "<p>Am Rand eines Netzes steht heute meist ein Gerät, das mehrere Arten verbindet. Für die Prüfung zählt der Unterschied: Der Paketfilter sieht nur Kopfzeilen, der Proxy vermittelt selbst, und eine Firewall mit Anwendungssicht muss mehr wissen – und mehr gepflegt werden.</p>"},
      {titel: "Regeln pflegen und prüfen", html:
        "<ul><li><b>Aufnehmen</b>, welche Dienste wirklich gebraucht werden – Bedarf, nicht Wunsch. Je Regel: Nummer, von, nach, Dienst, Zweck, verantwortlich, Datum.</li><li><b>Testen</b>: Verkehr aus der erlaubten Richtung muss gehen, alles andere nicht. Ein Portscan ist nur mit Auftrag und Erlaubnis zulässig.</li><li><b>Beobachten</b>: Trefferzähler und Log zeigen, welche Regel greift – und welche seit Monaten niemand braucht.</li><li><b>Ändern</b>: über einen Change mit Rückweg; zeitlich befristete Regeln nach Ablauf entfernen.</li><li><b>Prüfen</b>: Regeln von oben nach unten durchgehen. Eine Regel, die nie greifen kann, ist ein Denkfehler.</li></ul>"},
      {titel: "Was eine Firewall nicht kann", html:
        "<p>Eine Firewall ist eine Grenze, kein Rundumschutz. Sie hilft nicht gegen:</p>" +
        "<ul><li>Angriffe <b>aus dem eigenen LAN</b>: Wer schon drinnen ist, darf oft viel.</li><li><b>Phishing, USB-Stick, E-Mail-Anhang</b>: Der Schadcode kommt auf einem erlaubten Weg herein.</li><li><b>Ungepatchte Systeme und zu weite Rechte</b>: Dafür gibt es Patch- und Rechteverwaltung.</li><li><b>Verschlüsselten Verkehr</b>, dessen Inhalt sie nicht aufbricht – die Verbindung darf sein, der Inhalt bleibt verborgen.</li><li><b>Ausfälle</b>: Gegen einen Geräte- oder Stromausfall hilft nur Redundanz.</li></ul>" +
        "<p>Und wer von zu Hause arbeitet, sitzt außerhalb der Firmengrenze. Dort schützt die Firewall nicht – dafür braucht es VPN und einen geschützten Arbeitsplatz.</p>"},
    ],
    merksatz: "Alles zu, nur Benötigtes auf, und die Reihenfolge entscheidet.",
    pruefungstipp: "Regeln immer mit Bedarf begründen: „Port 443 nach außen, weil die Mitarbeiter Webseiten per HTTPS nutzen.“ Und die Grenze nennen: Eine Firewall schützt nicht vor Angriffen aus dem eigenen LAN.",
    quelle: "Infrastruktur & Sicherheit – Visuelle Lernnotiz",
    belege: "05-AP2-Infrastruktur-Sicherheit (Firewall-Grundregeln) · BSI IT-Grundschutz-Kompendium, NET.1.1 Netzarchitektur und -design",
    siehe: ["lab.dmz", "lab.acl", "lab.ports"],
  },
  "lab.dmz": {
    titel: "DMZ",
    kurz: "Die DMZ ist eine eigene Zone für Dienste, die aus dem Internet erreichbar sein müssen, getrennt vom internen Netz.",
    abschnitte: [
      {titel: "Aufbau", html:
        "<p>Öffentliche Dienste wie Webserver, Kundenportal oder Mail-Gateway stehen in der DMZ. Die Firewall regelt drei Übergänge: Internet zur DMZ, LAN zur DMZ und DMZ zum LAN.</p>"},
      {titel: "Typisches Regelwerk", html:
        "<table><tr><th>von</th><th>nach</th><th>Regel</th></tr>" +
        "<tr><td>außen</td><td>DMZ</td><td>nur der veröffentlichte Dienst, zum Beispiel tcp 443</td></tr>" +
        "<tr><td>innen</td><td>DMZ</td><td>erlaubt, was die Mitarbeiter brauchen</td></tr>" +
        "<tr><td>DMZ</td><td>innen</td><td><b>verboten</b> (höchstens einzelne, begründete Ausnahmen)</td></tr>" +
        "<tr><td>außen</td><td>innen</td><td>verboten</td></tr></table>"},
      {titel: "Warum", html:
        "<p>Ein Server, der aus dem Internet erreichbar ist, ist angreifbar. Wird er übernommen, schützt die Grenze zwischen DMZ und LAN das interne Netz.</p>"},
      {titel: "DMZ betreiben: patchen, überwachen, begrenzen", html:
        "<p>Eine DMZ ist kein Selbstläufer: Die Server darin brauchen Updates, und der Update-Weg darf nicht am Regelwerk scheitern. Protokolle der Firewall zeigen, was aus der DMZ nach innen versucht wird – ein Alarmzeichen. Je mehr Dienste in derselben DMZ stehen, desto größer der Schaden, wenn ein Angreifer einen davon kontrolliert; getrennte Zonen begrenzen ihn.</p>"},
    ],
    merksatz: "Aus der DMZ führt kein Weg ins LAN.",
    pruefungstipp: "In Situationsaufgaben: öffentlicher Dienst → DMZ, mit Begründung „Schutz des internen Netzes bei Kompromittierung“.",
    quelle: "05-AP2-Infrastruktur-Sicherheit",
    belege: "Infrastruktur & Sicherheit – Visuelle Lernnotiz (Firmennetz mit DMZ und VLANs) · 07-Uebungen-Subnetting-Szenarien (Aufgabe 5)",
    siehe: ["lab.fw", "lab.portfwd"],
  },
  "lab.portsec": {
    titel: "Port-Security",
    kurz: "Port-Security legt fest, welche und wie viele MAC-Adressen an einem Switchport senden dürfen.",
    abschnitte: [
      {titel: "Einrichten", html:
        "<pre>SW1(config)# interface fa0/5\nSW1(config-if)# switchport mode access\nSW1(config-if)# switchport port-security\nSW1(config-if)# switchport port-security maximum 1\nSW1(config-if)# switchport port-security mac-address sticky\nSW1(config-if)# switchport port-security violation shutdown</pre>" +
        "<p>Standard ist höchstens eine MAC und die Aktion shutdown. Mit <code>sticky</code> merkt sich der Switch die erste gelernte MAC. Port-Security geht nur auf Access-Ports – das Labor weist sie auf einem Trunk-Port ausdrücklich ab. Auf echten Geräten ist sie auch auf fest eingestellten Trunks möglich, nicht auf aushandelnden Ports.</p>"},
      {titel: "Was bei einem Verstoß passiert", html:
        "<table><tr><th>Modus</th><th>fremde Frames</th><th>Meldung</th><th>Port</th></tr>" +
        "<tr><td>protect</td><td>verworfen</td><td>keine</td><td>bleibt an</td></tr>" +
        "<tr><td>restrict</td><td>verworfen</td><td>Log, Zähler</td><td>bleibt an</td></tr>" +
        "<tr><td>shutdown</td><td>verworfen</td><td>Log, Zähler</td><td>err-disabled</td></tr></table>" +
        "<p>Wieder einschalten: Ursache klären, dann in der Schnittstelle <code>shutdown</code> und <code>no shutdown</code>. Übersicht: <code>show port-security interface fa0/5</code>.</p>"},
      {titel: "Wogegen es hilft", html:
        "<p>Gegen fremde Geräte an Netzwerkdosen und gegen <b>MAC Flooding</b>, bei dem ein Angreifer die MAC-Tabelle des Switches überflutet. Gegen ARP-Spoofing hilft dagegen Dynamic ARP Inspection.</p>"},
      {titel: "WLAN: warum Port-Security hier nicht greift", html:
        "<p>Port-Security sichert eine <b>Buchse</b>: ein Kabel, ein Gerät, eine gelernte MAC. Im Funk gibt es keine Buchse – alle Geräte einer Zelle teilen sich das Medium, und die MAC-Adresse darf jedes Gerät selbst wählen. Ein MAC-Filter am Access Point ist deshalb keine Sicherheit, sondern nur eine Hürde.</p>" +
        "<table><tr><th>Maßnahme</th><th>Was sie leistet</th></tr>" +
        "<tr><td>WPA2 (CCMP/AES)</td><td>Verschlüsselt den Funkverkehr; der Schlüssel kommt aus einem Passwort (PSK) oder aus der Anmeldung</td></tr>" +
        "<tr><td>WPA3</td><td>Wie WPA2, dazu Schutz gegen Mitschneiden und gegen das Raten des Passworts (SAE)</td></tr>" +
        "<tr><td>802.1X mit RADIUS</td><td>Jeder Nutzer meldet sich einzeln an; im Betrieb der übliche Weg (WPA2-/WPA3-Enterprise)</td></tr>" +
        "<tr><td>Offenes Netz</td><td>Keine Verschlüsselung – nur mit vorgeschaltetem Portal und getrenntem VLAN vertretbar</td></tr></table>" +
        "<p>Die alten Verfahren WEP und WPA mit TKIP gelten als gebrochen. Ein Gästenetz trennt die Geräte zusätzlich voneinander, damit Besucher sich nicht gegenseitig sehen. Und wie am Kabel gilt: Wer am Netz ist, darf nicht mehr dürfen, als er muss.</p>"},
    ],
    merksatz: "Fremde MAC am gesicherten Port: Port aus, bis jemand nachsieht.",
    pruefungstipp: "Die drei Modi protect, restrict und shutdown unterscheiden können; shutdown ist Standard. Am Funk greift Port-Security nicht – dort sichern WPA2/WPA3 und 802.1X.",
    quelle: "Network – Lernfassung",
    belege: "Cisco Catalyst Software Configuration Guide: Configuring Port Security · VLAN – Lernfassung (§ 3 Sicherheit) · IEEE 802.11i (WPA2, CCMP/AES) · IEEE 802.1X (Anmeldung im Netz) · WPA3 Specification (Wi-Fi Alliance) · BSI IT-Grundschutz-Kompendium, NET.2.1 WLAN-Betrieb",
    siehe: ["lab.switch", "lab.vlan", "lab.link"],
  },
  "lab.stp": {
    titel: "Schleifen und Spanning Tree",
    kurz: "Spanning Tree schaltet redundante Wege zwischen Switches ab, damit keine Schleife entsteht.",
    abschnitte: [
      {titel: "Das Problem", html:
        "<p>Zwei Switches, zwei Kabel dazwischen: Ein Broadcast wird an jedem Switch geflutet und kommt über das andere Kabel zurück. Ethernet-Frames haben <b>keine TTL</b>, sie kreisen also endlos und vervielfachen sich: ein <b>Broadcast-Sturm</b>. Nebenbei springen die MAC-Tabellen hin und her.</p>"},
      {titel: "Die Lösung", html:
        "<p><b>STP</b> (IEEE 802.1D; RSTP 802.1w ist seit 802.1D-2004 Teil desselben Standards) wählt eine Wurzel (Root-Bridge) und blockiert Ports so, dass ein Baum ohne Kreise entsteht. Fällt ein Weg aus, gibt STP einen blockierten Port frei. <b>BPDU Guard</b> schaltet einen Access-Port ab, an dem plötzlich ein Switch STP spricht.</p>"},
      {titel: "Wer wird Wurzel? (Root-Bridge wählen)", html:
        "<p>Jedes VLAN wählt seine eigene Wurzel. Verglichen wird die <b>Bridge-ID</b>: zuerst die Priorität, bei Gleichstand die kleinere MAC-Adresse. Die Priorität läuft in Schritten von 4096 und steht ab Werk auf 32768; die VLAN-Nummer zählt mit, deshalb kann die Wurzel je VLAN eine andere sein.</p>" +
        "<table><tr><th>Rolle</th><th>Bedeutung</th></tr>" +
        "<tr><td>Root-Bridge</td><td>sitzt in der Mitte des Baums, alle ihre Ports leiten weiter</td></tr>" +
        "<tr><td>Root-Port</td><td>der beste Weg zur Wurzel, je Nicht-Wurzel-Switch genau einer</td></tr>" +
        "<tr><td>Designated Port</td><td>leitet auf einem Segment weiter</td></tr>" +
        "<tr><td>Alternate Port</td><td>blockiert und springt bei Ausfall ein</td></tr></table>" +
        "<p>Der Weg wird über die Pfadkosten bewertet, klein gewinnt. Kurzverfahren (IEEE): 100 Mbit/s = 19, 1 Gbit/s = 4, 10 Gbit/s = 2. Cisco rechnet beim Langverfahren mit 20000 für 1 Gbit/s. Damit die Wurzel dort steht, wo du sie haben willst, setzt du die Priorität:</p>" +
        "<pre>SW1(config)# spanning-tree vlan 10 root primary\nSW1# show spanning-tree vlan 10</pre>" +
        "<p><b>Echtes IOS, nicht das Labor:</b> Beide Zeilen gehören auf echte Hardware. Das Labor kennt keinen <code>spanning-tree</code>-Befehl – STP ist dort <b>nicht nachgebaut</b>: Es lässt sich weder einstellen noch mit <code>show spanning-tree</code> anzeigen, und in der running-config steht keine STP-Zeile (dort stehen nur Befehle, die das Gerät selbst wieder annimmt).</p>"},
      {titel: "Zustände, Wartezeit und Schutz", html:
        "<p>Ein Port leitet nicht sofort weiter. Klassisches STP (802.1D) kennt fünf Zustände; bis zum Weiterleiten vergehen rund 30 bis 50 s.</p>" +
        "<table><tr><th>802.1D</th><th>RSTP (802.1w)</th><th>Was passiert</th></tr>" +
        "<tr><td>Blocking</td><td>Discarding</td><td>Frames werden verworfen, BPDUs werden gehört</td></tr>" +
        "<tr><td>Listening</td><td>Discarding</td><td>die Wahl läuft, es wird noch nicht gelernt</td></tr>" +
        "<tr><td>Learning</td><td>Learning</td><td>die MAC-Tabelle füllt sich, weitergeleitet wird noch nicht</td></tr>" +
        "<tr><td>Forwarding</td><td>Forwarding</td><td>der Port arbeitet normal</td></tr>" +
        "<tr><td>Disabled</td><td>Discarding</td><td>der Port ist abgeschaltet, kein STP</td></tr></table>" +
        "<p><b>RSTP</b> ist in unter einer Sekunde auf Forwarding, weil Nachbarn sich per Proposal und Agreement einigen. Ein Port zu einem Endgerät braucht keine Wartezeit: <code>spanning-tree portfast</code>, bei RSTP Edge-Port. Weil an einem Endgeräteport kein Switch hängen darf, schaltet <b>BPDU Guard</b> den Port ab, sobald dort doch BPDUs ankommen. <b>Root Guard</b> verhindert, dass ein fremder Switch die Wurzel wird. PortFast, BPDU Guard und Root Guard sind echte IOS-Konfiguration. STP ist im Labor <b>nicht nachgebaut</b>: Es gibt weder die Konfigurationsbefehle noch eine eigene <code>show spanning-tree</code>-Ausgabe.</p>"},
    ],
    merksatz: "Redundanz ja, Schleife nein: dafür gibt es Spanning Tree.",
    pruefungstipp: "STP verhindert Schleifen und Broadcast-Stürme; LACP bündelt Leitungen, das ist etwas anderes.",
    quelle: "Fragen – Netzwerke planen",
    belege: "IEEE 802.1D · IEEE 802.1w · VLAN – Lernfassung (§ 3: STP, BPDU Guard) · Cisco Catalyst Software Configuration Guide: Configuring Spanning Tree Protocol (root primary, PortFast, BPDU Guard, Root Guard)",
    siehe: ["lab.switch", "lab.vlan"],
  },
  "lab.storage": {
    titel: "NAS, SAN und Speichernetze",
    kurz: "Zentraler Speicher kommt als Dateiablage (NAS) oder als Blockspeicher über ein Speichernetz (SAN) zu den Rechnern.",
    abschnitte: [
      {titel: "Drei Orte für Speicher", html:
        "<table><tr><th>Art</th><th>Was</th><th>Zugriff</th></tr>" +
        "<tr><td>DAS</td><td>Platte direkt im oder am Rechner</td><td>nur dieser Rechner</td></tr>" +
        "<tr><td>NAS</td><td>Dateiserver im LAN</td><td>Dateien über SMB (TCP 445) oder NFS (2049)</td></tr>" +
        "<tr><td>SAN</td><td>Speichernetz für Blockspeicher</td><td>iSCSI (TCP 3260) oder Fibre Channel</td></tr></table>"},
      {titel: "Datei oder Block?", html:
        "<p>Ein <b>NAS</b> liefert Dateien, das Dateisystem verwaltet das NAS; gut für gemeinsame Ablagen. Ein <b>SAN</b> liefert Blöcke wie eine lokale Platte, der Rechner formatiert sie selbst; gut für Datenbanken und virtuelle Maschinen.</p>"},
      {titel: "RAID: Ausfall aushalten, nicht ersetzen", html:
        "<p>RAID verteilt die Daten auf mehrere Platten. Es rettet den Betrieb bei einem Plattenausfall, ersetzt aber <b>keine Sicherung</b>: Ein gelöschter oder verschlüsselter Ordner liegt auf allen Platten gleich.</p>" +
        "<table><tr><th>Stufe</th><th>Platten</th><th>Verfahren</th><th>übersteht</th></tr>" +
        "<tr><td>RAID 0</td><td>ab 2</td><td>verteilen (Striping), keine Redundanz</td><td>nichts – schnell, aber riskant</td></tr>" +
        "<tr><td>RAID 1</td><td>ab 2</td><td>Spiegel</td><td>eine Platte</td></tr>" +
        "<tr><td>RAID 5</td><td>ab 3</td><td>verteilen mit einer Parität</td><td>eine Platte</td></tr>" +
        "<tr><td>RAID 6</td><td>ab 4</td><td>verteilen mit zwei Paritäten</td><td>zwei Platten</td></tr>" +
        "<tr><td>RAID 10</td><td>ab 4</td><td>erst spiegeln, dann verteilen</td><td>je Spiegel eine Platte</td></tr></table>" +
        "<p>Nutzkapazität: RAID 1 und RAID 10 verschenken die Hälfte, RAID 5 eine Platte, RAID 6 zwei. Nach einem Ausfall läuft der Verbund weiter, aber ohne Schutz. Der <b>Rebuild</b> liest alle Platten und dauert Stunden – deshalb Ersatzplatten bereithalten und die Platten überwachen.</p>"},
      {titel: "Anbindung und Betrieb", html:
        "<table><tr><th>Thema</th><th>Worauf es ankommt</th></tr>" +
        "<tr><td>iSCSI (TCP 3260)</td><td>Initiator am Server, Target am Speichersystem, je Seite ein IQN-Name; eigenes VLAN, weil der Verkehr über das normale IP-Netz läuft</td></tr>" +
        "<tr><td>Fibre Channel</td><td>eigenes Netz mit WWN und Zoning: teurer, aber gleichmäßig schnell</td></tr>" +
        "<tr><td>Multipathing</td><td>zwei getrennte Wege zum Speicher; fällt ein Switch aus, bleibt der Zugriff erhalten</td></tr>" +
        "<tr><td>SMB und NFS</td><td>Dateifreigaben mit Berechtigungen: Freigabe- und Dateirechte wirken zusammen</td></tr>" +
        "<tr><td>Snapshots</td><td>zeigen einen alten Stand auf demselben System – praktisch gegen Löschen, aber keine Sicherung</td></tr></table>" +
        "<p>Gewählt wird nach Zugriffsmuster: Viele kleine Zugriffe einer Datenbank und virtuelle Maschinen passen auf Blockspeicher, gemeinsame Dateien auf eine Freigabe. Im Rechenzentrum bekommt der Speicherverkehr ein eigenes Netz, und die Sicherung liegt getrennt davon.</p>"},
      {titel: "Virtualisierung: Speicher für virtuelle Maschinen", html:
        "<p>Ein <b>Hypervisor</b> teilt die Hardware in virtuelle Maschinen (VM). Typ 1 läuft direkt auf dem Server, Typ 2 auf einem Betriebssystem. Jede VM hat eigene virtuelle Platten – als Datei oder als LUN im Speichernetz.</p>" +
        "<ul><li><b>Konsolidierung</b>: viele kleine Server als VMs auf wenigen großen, weniger Verbrauch, leichteres Sichern.</li><li><b>Snapshot vor dem Update</b>: ein Rückweg bei misslungenem Patch, aber kein Ersatz für die Sicherung.</li><li><b>Container</b> teilen sich einen Kernel und starten schneller, ersetzen eine VM aber nicht in jedem Fall.</li><li><b>Planen</b>: CPU, Arbeitsspeicher und die Zugriffe je Sekunde (IOPS) des Speichers begrenzen die Zahl der VMs.</li></ul>"},
    ],
    merksatz: "NAS = Dateien teilen, SAN = Platten übers Netz.",
    pruefungstipp: "Datenbank mit vielen kleinen Zugriffen: eher SAN; gemeinsame Dateiablage: NAS. RAID schützt vor Plattenausfall, nie vor Löschen.",
    quelle: "Storage-Konzeptatlas",
    belege: "IANA Port Number Registry (445, 2049, 3260) · Brücke – FISI und Alltag zu Storage und Cloud · SNIA Dictionary (Snapshot, RAID) · BSI IT-Grundschutz-Kompendium, CON.3 Datensicherungskonzept",
    siehe: ["lab.ports"],
  },


  /* ---------- S6a/S6b (Architektur § 17.1): IPv6, Betrieb/Überwachung, WLAN ----------
     Drei Seiten für die am 29.10.2026 ans ENDE von DATEN.skills angehängten Fertigkeiten.
     Ehrliche Grenze (verbindlich, § 17.1): IPv6, Betrieb und WLAN werden INHALTLICH geübt
     (Adressierung, Planung, Konfiguration, Bewertung), nicht paketweise simuliert. Jede Seite
     sagt das ausdrücklich; es gibt hier keine abtippbaren Konsolen-Rezepte, die das Labor nicht
     ausführen kann (Wächter: tests/wiki-2.0.test.js, Rezeptzeilen). */
  "lab.ipv6": {
    titel: "IPv6: Adressen, Präfixe, NDP",
    kurz: "IPv6-Adressen sind 128 Bit lang; statt einer Maske trägt die Adresse ihre Präfixlänge, und statt ARP klärt NDP die Nachbarschaft.",
    abschnitte: [
      {titel: "128 Bit in acht Blöcken: die Schreibweise", html:
        "<p>Eine IPv6-Adresse besteht aus 128 Bit, geschrieben als acht Blöcke zu je 16 Bit in Hexadezimal: <code>2001:0db8:aa00:0001:0000:0000:0000:0042</code>. Zwei Kürzungsregeln machen sie lesbar: <b>führende Nullen</b> eines Blocks fallen weg, und <b>ein einziges Mal</b> darf eine Folge von Nullblöcken durch <code>::</code> ersetzt werden. Aus dem Beispiel wird <code>2001:db8:aa00:1::42</code>.</p>" +
        "<table><tr><th>Bereich</th><th>Bedeutung</th></tr>" +
        "<tr><td>2000::/3</td><td>Global Unicast – im Internet routingfähig, öffentlich</td></tr>" +
        "<tr><td>fc00::/7</td><td>Unique Local – privat, nicht im Internet geroutet (Gegenstück zu RFC 1918)</td></tr>" +
        "<tr><td>fe80::/10</td><td>Link-Local – nur auf diesem Link, wird automatisch gebildet</td></tr>" +
        "<tr><td>ff00::/8</td><td>Multicast – erreicht Gruppen und ersetzt den Broadcast</td></tr>" +
        "<tr><td>::1</td><td>Loopback (Gegenstück zu 127.0.0.1)</td></tr>" +
        "<tr><td>::</td><td>noch keine Adresse</td></tr></table>" +
        "<p>Einen Broadcast gibt es bei IPv6 nicht; seine Rolle übernimmt Multicast. Für Dokumentation und Beispiele ist <code>2001:db8::/32</code> reserviert – solche Adressen gehören niemandem und gehören in kein echtes Netz.</p>"},
      {titel: "Präfix statt Maske: Netze planen", html:
        "<p>IPv6 kennt keine Subnetzmaske. Die <b>Präfixlänge</b> steht direkt an der Adresse: <code>2001:db8:aa00:1::1/64</code> heißt, die ersten 64 Bit bezeichnen das Netz, die restlichen 64 Bit den Rechner. Geplant wird von links nach rechts:</p>" +
        "<ul><li><b>/48</b> je Standort oder Kunde – das ist der übliche Block aus einem Provider-Präfix.</li><li><b>/56</b> je Standort, wenn nur 256 Netze gebraucht werden.</li><li><b>/64</b> je LAN – die Standardgröße: nur bei /64 funktioniert das automatische Adressieren (SLAAC) sauber.</li><li><b>/127</b> für Punkt-zu-Punkt-Strecken (RFC 6164) oder /64 nach Herstellergewohnheit.</li></ul>" +
        "<p>Ein /64 hat 2<sup>64</sup> Adressen, praktisch unbegrenzt viele. Die Hostbits werden deshalb nicht „verbraucht“ wie bei IPv4. Die Adresse mit lauter Nullen im Hostteil ist kein normaler Host: Sie ist als <b>Subnet-Router-Anycast</b> reserviert (RFC 4291); eine Broadcastadresse wie bei IPv4 gibt es bei IPv6 nicht. Wer aus einem /48 zehn /64 schneidet, zählt in Hexadezimal: die Subnetz-ID steht in den Blöcken 3 und 4.</p>"},
      {titel: "Link-Local und NDP: der Link ohne DHCP", html:
        "<p>Jede IPv6-Schnittstelle bildet sich selbst eine <b>Link-Local-Adresse</b> aus <code>fe80::/10</code>. Sie wird nie geroutet und dient der Kommunikation auf demselben Link – etwa um den Router zu finden. Ein Rechner hat dadurch fast immer mehrere Adressen gleichzeitig: eine Link-Local und mindestens eine globale.</p>" +
        "<p>Die Schnittstellen-Kennung (Interface-ID, die hinteren 64 Bit) entsteht auf zwei Wegen: klassisch aus der MAC-Adresse (EUI-64, mit eingeschobenem FFFE), oder – bei modernen Systemen der Normalfall – als zufällige, zeitlich wechselnde Kennung (<b>Privacy Extensions</b>, RFC 4941). Die zufällige Variante verhindert, dass man ein Gerät über seine Adresse dauerhaft verfolgen kann; für Server und Router ist eine feste, planbare Adresse üblich.</p>" +
        "<p><b>NDP</b> (Neighbor Discovery Protocol, RFC 4861) ersetzt ARP und ICMP-Router-Redirect:</p>" +
        "<table><tr><th>Nachricht</th><th>Typ</th><th>Aufgabe</th></tr>" +
        "<tr><td>Router Solicitation</td><td>133</td><td>Rechner fragt: Gibt es hier einen Router?</td></tr>" +
        "<tr><td>Router Advertisement</td><td>134</td><td>Router meldet Präfix, Standardroute und Flags</td></tr>" +
        "<tr><td>Neighbor Solicitation</td><td>135</td><td>Wer hat diese Adresse? (Gegenstück zur ARP-Anfrage)</td></tr>" +
        "<tr><td>Neighbor Advertisement</td><td>136</td><td>Antwort mit der MAC-Adresse</td></tr></table>" +
        "<p>Die <b>Duplicate Address Detection</b> läuft über Neighbor Solicitation: Bevor eine Adresse gilt, fragt der Rechner, ob sie schon jemand benutzt. Multicast-Adressen wie <code>ff02::1</code> (alle Knoten) und <code>ff02::2</code> (alle Router) ersetzen den Broadcast.</p>"},
      {titel: "Adressvergabe und statisches Routing", html:
        "<p>Adressen kommen auf drei Wegen: <b>statisch</b> eingetragen, per <b>SLAAC</b> aus dem Router Advertisement (der Rechner bildet die Adresse selbst aus Präfix und Interface-ID) oder per <b>DHCPv6</b> (Server UDP 547, Client UDP 546). Ein Router Advertisement setzt dafür Flags: <code>A</code> erlaubt SLAAC, <code>M</code> verlangt DHCPv6, <code>O</code> holt weitere Angaben per DHCPv6.</p>" +
        "<p>Geroutet wird mit Präfixen statt mit Klassen: eine Route ist ein Zielpräfix plus Next Hop. Die Standardroute ist <code>::/0</code>. In der Praxis zeigt sie auf die Link-Local-Adresse des Routers, dazu wird die Ausgangsschnittstelle genannt – der Router muss also nicht im selben globalen Präfix liegen.</p>" +
        "<table><tr><th>Weg</th><th>Beispiel</th><th>Bedeutung</th></tr>" +
        "<tr><td>Standardroute</td><td>::/0 → fe80::1</td><td>alles, was nicht lokal ist</td></tr>" +
        "<tr><td>Präfixroute</td><td>2001:db8:aa01::/48 → fe80::2</td><td>Standort oder Kunde</td></tr>" +
        "<tr><td>Direkt verbunden</td><td>2001:db8:aa00:1::/64</td><td>am eigenen Link, ohne Next Hop</td></tr></table>"},
      {titel: "Im Labor: Adressierung üben, nicht Pakete", html:
        "<p><b>Ehrliche Grenze:</b> Dieses Labor rechnet und simuliert mit IPv4. Es verschickt keine IPv6-Pakete, zeigt keine NDP-Nachrichten und vergibt keine IPv6-Adressen per Router Advertisement. IPv6 wird hier <b>inhaltlich</b> geübt: Adressen lesen und kürzen, Präfixe planen, Adresstypen unterscheiden, Fehlkonfigurationen beurteilen – nicht paketweise ausführen.</p>" +
        "<p>Für die Praxis heißt das: Rechne ein /48 in /64-Netze, prüfe die Kürzung einer Adresse und entscheide, welche Adresse auf einen Link gehört. Wer ein IPv6-Paket im Detail sehen will, braucht ein echtes Gerät oder einen Paketmitschnitt.</p>"},
    ],
    merksatz: "128 Bit, Präfix statt Maske, kein Broadcast – und Link-Local bleibt auf dem Link.",
    pruefungstipp: "Adressen kürzen und wieder ausschreiben üben; /48 → /64 rechnen; die Typen global, link-local, multicast und loopback auseinanderhalten. In Prüfungsaufgaben wird häufig nach der Anzahl der Subnetze aus einem /48 gefragt.",
    quelle: "04-AP1-Netzwerk",
    belege: "RFC 8200 (IPv6) · RFC 4291 (Adressarchitektur) · RFC 5952 (kanonische Schreibweise) · RFC 4861 (Neighbor Discovery) · RFC 4862 (SLAAC) · RFC 4941 (Privacy Extensions) · RFC 8415 (DHCPv6) · RFC 3849 (2001:db8::/32) · RFC 4193 (Unique Local) · RFC 6164 (/127) · 04-AP1-Netzwerk",
    siehe: ["lab.ip", "lab.subnetz", "lab.route", "lab.dhcp", "lab.ping"],
  },
  "lab.betrieb": {
    titel: "Betrieb und Überwachung (Syslog, Schwellwert, Backup, Uptime)",
    kurz: "Ein Netz läuft nicht, weil es gebaut ist, sondern weil es überwacht, gesichert und im Störungsfall nachvollziehbar repariert wird.",
    abschnitte: [
      {titel: "Syslog: Ereignisse sammeln und gewichten", html:
        "<p>Geräte schreiben Ereignisse als <b>Syslog</b>-Meldungen (RFC 5424): Zeitstempel, Hostname, Anwendung, <b>Severity</b> und Text. Die Severity reicht von 0 (emerg, System steht) bis 7 (debug); geübte Stufen sind 0–3 (emerg/alert/crit/err), 4 (warning), 5 (notice), 6 (info) und 7 (debug).</p>" +
        "<table><tr><th>Wert</th><th>Stufe</th><th>Beispiel</th></tr>" +
        "<tr><td>0</td><td>emerg</td><td>System nicht benutzbar</td></tr>" +
        "<tr><td>2</td><td>crit</td><td>kritischer Zustand, sofort handeln</td></tr>" +
        "<tr><td>3</td><td>err</td><td>Fehler, Funktion gestört</td></tr>" +
        "<tr><td>4</td><td>warning</td><td>Warnung, Schwelle erreicht</td></tr>" +
        "<tr><td>6</td><td>info</td><td>normaler Betriebszustand</td></tr></table>" +
        "<p>In kleinen Netzen sammelt ein zentraler Syslog-Server die Meldungen (klassisch UDP 514, sicher per TCP/TLS nach RFC 5425); sonst steht die Spur nur lokal im Puffer und ist nach einem Neustart weg. Wichtig ist die <b>einheitliche Uhrzeit</b> über NTP, sonst lassen sich Ereignisse auf mehreren Geräten nicht ordnen.</p>"},
      {titel: "Schwellwerte: wann aus einem Messwert ein Alarm wird", html:
        "<p>Ein Monitoring misst laufend Werte (Auslastung, freier Platz, Temperatur, Antwortzeit) und vergleicht sie mit Schwellen. Zwei Stufen sind üblich: <b>Warnung</b> bei 80 Prozent, <b>Alarm</b> bei 90 Prozent. Dazu gehören eine <b>Hysterese</b> (Warnung fällt erst bei 75 Prozent zurück, sonst flattert der Alarm) und ein <b>Zeitfenster</b> (erst drei Minuten über der Schwelle zählt).</p>" +
        "<ul><li>Zu viele Alarme werden ignoriert – lieber wenige, dafür handlungsfähige.</li><li>Der Schwellwert gehört zur Kennzahl: 80 Prozent Speicher ist bei Protokollen normal, bei Benutzerdaten kritisch.</li><li>Ein Alarm braucht eine benannte Reaktion: wer prüft, bis wann, mit welchem ersten Schritt.</li></ul>"},
      {titel: "Backup: Kopien, die man wieder zurückspielen kann", html:
        "<p>Die einfache Regel lautet <b>3-2-1</b>: drei Kopien, auf zwei verschiedenen Medien, eine davon außerhalb des Standorts. Das ist gängige Praxis und kein wörtlicher BSI-Text – BSI IT-Grundschutz CON.3 fordert ein durchdachtes Datensicherungskonzept, nennt die 3-2-1-Regel aber nicht wörtlich. Dazu kommen die Begriffe <b>RPO</b> (wie viel Datenverlust ist erlaubt – also wie oft sichern) und <b>RTO</b> (wie lange darf die Wiederherstellung dauern).</p>" +
        "<table><tr><th>Art</th><th>Sichert</th><th>Restore</th></tr>" +
        "<tr><td>Voll</td><td>alle Daten</td><td>einfach, aber langsam und groß</td></tr>" +
        "<tr><td>Inkrementell</td><td>Änderungen seit der letzten Sicherung</td><td>Vollsicherung plus alle Zwischenstände</td></tr>" +
        "<tr><td>Differenziell</td><td>Änderungen seit der letzten Vollsicherung</td><td>Vollsicherung plus letzter Stand</td></tr></table>" +
        "<p>Die wichtigste Prüfung ist die <b>Wiederherstellung</b>: Ein Backup, das nie zurückgespielt wurde, ist eine Annahme, kein Beleg. Im Labor heißt die verwandte Handlung <code>copy running-config startup-config</code>: Die laufende Konfiguration wird zur startenden – nach einem Neustart ohne diesen Schritt ist die Änderung weg.</p>"},
      {titel: "Uptime und Verfügbarkeit: Zahlen lesen", html:
        "<p><b>Verfügbarkeit</b> ist die Zeit im Betrieb geteilt durch die Gesamtzeit. Sie wird oft als Neun angeboten; dahinter steckt erlaubte Ausfallzeit:</p>" +
        "<table><tr><th>Verfügbarkeit</th><th>Ausfall pro Jahr</th><th>pro Monat</th></tr>" +
        "<tr><td>99 %</td><td>etwa 87,6 Stunden</td><td>etwa 7,2 Stunden</td></tr>" +
        "<tr><td>99,9 %</td><td>etwa 8,8 Stunden</td><td>etwa 43,8 Minuten</td></tr>" +
        "<tr><td>99,99 %</td><td>etwa 52,6 Minuten</td><td>etwa 4,4 Minuten</td></tr>" +
        "<tr><td>99,999 %</td><td>etwa 5,3 Minuten</td><td>etwa 26 Sekunden</td></tr></table>" +
        "<p>Hinter den Neunen stehen <b>MTBF</b> (mittlere Zeit zwischen Ausfällen) und <b>MTTR</b> (mittlere Reparaturzeit); die Verfügbarkeit steigt vor allem durch kürzere MTTR. Wartungsfenster, Redundanz (zwei Netzteile, zwei Wege) und eine klare Störungsannahme zählen mit – „Uptime“ eines einzelnen Geräts sagt noch nichts über die Verfügbarkeit des Dienstes.</p>"},
      {titel: "Störung erkennen und dokumentieren – die ehrliche Grenze", html:
        "<p><b>Betriebsbezug im Labor:</b> Das Labor simuliert Netzstörungen (Kabel weg, Gerät aus, Port abgeschaltet, fehlende Startkonfiguration nach einem Neustart). Genau das ist die Alltagsseite des Betriebs: Die Störung tritt auf, du misst, grenzt ein und dokumentierst nachvollziehbar – statt sofort zu raten.</p>" +
        "<ul><li><b>Symptom</b> in der Sprache des Nutzers notieren („kein Internet“, „Drucker antwortet nicht“).</li><li><b>Messung</b>: Link, Adresse, Gateway, Dienst – von unten nach oben.</li><li><b>Ursache</b> belegen, nicht vermuten: ein Befehl, ein Status, eine Zeile Syslog.</li><li><b>Maßnahme</b> und <b>Wirkung</b> festhalten; eine kurze Notiz im Wartungsbuch ist Teil der Arbeit.</li></ul>" +
        "<p><b>Ehrliche Grenze:</b> Geübt werden Störungserkennung, Messung und Dokumentation im simulierten Netz; Syslog-Server, Schwellwert-Alarme und das Rückspielen einer Sicherung gehören auf echte Systeme und werden hier bewertet, nicht ausgeführt.</p>"},
    ],
    merksatz: "Erst messen, dann reparieren, danach dokumentieren – und Sicherungen prüft man durch Zurückspielen.",
    pruefungstipp: "Verfügbarkeits-Neunen in Ausfallzeit umrechnen, Backup-Arten unterscheiden und Syslog-Severity zuordnen können. Der Unterschied zwischen running-config und startup-config ist Prüfungsstoff und im Labor direkt sichtbar.",
    quelle: "Network – Lernfassung",
    belege: "RFC 5424 (Syslog) · RFC 5425 (Syslog über TLS) · BSI IT-Grundschutz-Kompendium, CON.3 Datensicherungskonzept · BSI, DER.1 Detektion von sicherheitsrelevanten Ereignissen · ISO/IEC 25010 (Zuverlässigkeit, Verfügbarkeit) · Network – Lernfassung",
    siehe: ["lab.speichern", "lab.link", "lab.ping", "lab.storage", "lab.fw"],
  },
  "lab.wlan": {
    titel: "WLAN: SSID, VLAN, Sicherheit, Gastnetz",
    kurz: "Funk ist ein geteiltes Medium: Ein Access Point verbindet Funkzellen mit dem Kabel, jede SSID liegt in einem VLAN – und das Gastnetz bleibt getrennt.",
    abschnitte: [
      {titel: "Funkzelle: BSS, SSID und BSSID", html:
        "<p>Ein <b>Access Point</b> (AP) ist die Brücke zwischen Funk und Kabel: eine Antenne für die Funkzelle, ein Switchport für das Kabel. Die Funkzelle heißt <b>BSS</b> (Basic Service Set), ihr Name ist die <b>SSID</b> – der Name, den ein Gerät in der Liste sieht. Die MAC-Adresse des Funkmoduls ist die <b>BSSID</b>.</p>" +
        "<ul><li><b>CSMA/CA</b>: Gesendet wird, wenn die Luft frei ist; Kollisionen werden vermieden (Bestätigung je Rahmen), nicht erkannt. Deshalb sinkt der Durchsatz mit jedem aktiven Gerät.</li><li><b>Halbduplex</b>: Senden und Empfangen nacheinander – anders als am Kabel.</li><li><b>Assoziation</b>: Erst nach dem Anmelden am AP gibt es einen Link, vergleichbar mit dem gesteckten Kabel.</li><li>2,4 GHz (Kanäle 1–13, überlappungsfrei 1, 6, 11) reicht weiter, 5 und 6 GHz sind schneller und weniger belegt.</li></ul>" +
        "<p>Störer sind Nachbarzellen auf demselben Kanal, Mikrowellen und dicke Wände. Ein Ping durchs Funknetz schwankt stärker als über Kabel – das ist Physik, kein Fehler.</p>"},
      {titel: "SSID zu VLAN: der Trunk zum Access Point", html:
        "<p>In einem einfachen Aufbau gehört jede SSID zu genau <b>einem VLAN</b>. Der AP nimmt die Frames seiner Funknetze, versieht sie mit einem <b>802.1Q-Tag</b> und schickt sie über <b>einen Trunk</b> zum Switch. Dort landet jede SSID im passenden VLAN – genau wie ein Kabelport im Access-VLAN. Bei <b>dynamischer VLAN-Zuweisung</b> (802.1X/RADIUS) kann eine SSID mehrere VLANs bedienen: Der AP taggt dann je Benutzer nach der Anmeldung.</p>" +
        "<table><tr><th>Baustein</th><th>Aufgabe</th></tr>" +
        "<tr><td>SSID „Firma“ → VLAN 10</td><td>Mitarbeitergeräte im Verwaltungsnetz</td></tr>" +
        "<tr><td>SSID „Gast“ → VLAN 30</td><td>Gäste getrennt, eigener IP-Bereich</td></tr>" +
        "<tr><td>Management-VLAN</td><td>Verwaltung des AP selbst, von den Nutznetzen getrennt</td></tr>" +
        "<tr><td>Native VLAN am Trunk</td><td>muss auf beiden Seiten gleich sein, sonst landen ungetaggte Frames im falschen Netz</td></tr></table>" +
        "<p>Ohne Router oder Layer-3-Switch kommt kein Frame von einem VLAN ins andere – auch nicht von „Firma“ nach „Gast“. Größere Anlagen steuert ein WLAN-Controller, der SSIDs und Kanäle an alle APs verteilt.</p>"},
      {titel: "WPA2, WPA3 und was sie schützen", html:
        "<p>Ohne Verschlüsselung liest jedes Gerät im Funkbereich mit. <b>WEP</b> ist gebrochen und wird nicht mehr benutzt. <b>WPA2</b> verschlüsselt mit AES-CCMP; bei <b>WPA2-Personal</b> teilen sich alle Geräte ein Passwort, bei <b>WPA2-Enterprise</b> meldet sich jedes Gerät über 802.1X an einem RADIUS-Server an – zentral widerrufbar.</p>" +
        "<table><tr><th>Verfahren</th><th>Anmeldung</th><th>Eigenschaft</th></tr>" +
        "<tr><td>WPA2-Personal (PSK)</td><td>gemeinsames Passwort</td><td>einfach, ein Passwort für alle; bei Abgang Passwort wechseln</td></tr>" +
        "<tr><td>WPA2-Enterprise</td><td>802.1X + RADIUS</td><td>je Person ein Konto, zentral sperrbar</td></tr>" +
        "<tr><td>WPA3-Personal (SAE)</td><td>Passwort mit SAE</td><td>schützt besser gegen Wörterbuchangriffe auf Mitschnitte</td></tr>" +
        "<tr><td>WPA3-Enterprise</td><td>802.1X, strengere Vorgaben</td><td>höchste Anforderung; PMF verpflichtend</td></tr></table>" +
        "<p><b>PMF</b> (802.11w) schützt Verwaltungsframes – bei WPA3 ist PMF verpflichtend, bei WPA2 optional. <b>WPS</b> sollte aus bleiben (PIN ist angreifbar). Ein sichtbares WLAN ist kein Sicherheitsproblem – die Verschlüsselung entscheidet, nicht das Verstecken der SSID.</p>"},
      {titel: "Gastnetz und Isolation", html:
        "<p>Ein Gastnetz ist eine eigene SSID in einem eigenen VLAN mit eigenem IP-Bereich. Der Übergang ins Internet läuft über einen Router oder eine Firewall, die nur diesen einen Weg erlaubt; Zugriffe in die Firmennetze sind gesperrt.</p>" +
        "<ul><li><b>Client-Isolation</b>: Gäste erreichen sich auch untereinander nicht – nützlich gegen Angriffe im selben Funknetz.</li><li><b>Kein Zugriff auf intern</b>: per Firewall/ACL verbieten, nicht nur „nicht bekannt geben“.</li><li><b>Bandbreite begrenzen</b>: Gäste sollen das Firmennetz nicht ausbremsen.</li><li><b>Rechtlicher Hinweis</b>: Wer offenes WLAN anbietet, braucht einen Verantwortlichen für den Anschluss; ein vorgeschaltetes Portal ändert daran nichts.</li></ul>" +
        "<p>Wer das Gastnetz einrichtet, prüft danach genau drei Dinge: Internet geht, intern geht nicht, Gäste erreichen sich nicht. Das ist die Abnahme – nicht das Funk-Signal.</p>"},
      {titel: "Im Labor: planen und bewerten, nicht funken", html:
        "<p><b>Ehrliche Grenze:</b> Dieses Labor simuliert kein WLAN. Es gibt keine Funkzelle, keine Assoziation, keine 802.11-Rahmen und keine Verschlüsselungsaushandlung; Geräte sind hier über Kabel verbunden. WLAN wird <b>inhaltlich</b> geübt: SSID-VLAN-Zuordnung planen, Sicherheitsverfahren bewerten, Gastnetz-Isolation beurteilen und dokumentieren.</p>" +
        "<p>Für die Praxis: einen Trunk zum AP planen, eine Tabelle SSID–VLAN–IP-Bereich anlegen und die drei Prüfungen des Gastnetzes beschreiben. Wer Funk messen will, braucht echte Hardware und ein Analysewerkzeug.</p>"},
    ],
    merksatz: "Eine SSID, ein VLAN, ein Trunk zum AP – und das Gastnetz sieht nur das Internet.",
    pruefungstipp: "SSID und BSSID unterscheiden; 802.1Q-Trunk zum AP erklären; WPA2-Personal von WPA2-Enterprise trennen und die drei Prüfungen des Gastnetzes nennen können.",
    quelle: "VLAN – Lernfassung",
    belege: "IEEE 802.11 (WLAN, CSMA/CA) · IEEE 802.11i (WPA2) · IEEE 802.11w (PMF) · Wi-Fi Alliance: WPA3 Specification · IEEE 802.1Q (VLAN-Tagging) · BSI IT-Grundschutz-Kompendium, NET.2.1 WLAN-Betrieb · VLAN – Visuelle Lernnotiz",
    siehe: ["lab.link", "lab.vlan", "lab.trunk", "lab.acl", "lab.dmz"],
  },

  /* ---------- Zusatzseite OHNE eigene Fertigkeit: Klassenraum (Leitung, 09.10.2026) ----------
     `DATEN.wiki` ist eine Seite je Fertigkeit (30 seit S6a/S6b; die Indizes 0–26 sind gesperrt: Klassenraum-Codec,
     tools/klassenraum-probe/A-festlegung.md). Der Klassenraum ist keine Fertigkeit, braucht aber
     eine Nachschlage-Seite – er ist ein Modus des Spiels, keine Übung. Deshalb steht er hier in
     DERSELBEN Form: gleiche Pflichtfelder, gleiche Abschnittsstruktur, keine neue Fertigkeit.
     `suche` ist optional und trägt zusätzliche Suchwörter; die Wiki-Ansicht findet die Seite schon
     über `titel` und `kurz` (src/ui/karriere.js:295-296). Alle Zahlen sind am 09.10.2026 gegen
     src/spiel/klassenraum.js, src/spiel/klassenraum-codec.js und src/ui/klassenraum.js gemessen. */
  "klassenraum": {
    titel: "Klassenraum",
    kurz: "Ein Code von der Lehrkraft ergibt auf jedem Gerät denselben Auftrag – ohne Konto, ohne Netz und ohne Bewertung. Der Ergebnis-Code geht zurück an die Lehrkraft.",
    abschnitte: [
      {titel: "Was der Klassenraum ist", html:
        "<p>Die Lehrkraft sagt einen <b>Code</b> an, jeder tippt ihn ein – und auf jedem Gerät entsteht <b>derselbe Auftrag</b>. Ohne Konto, ohne Server, ohne Netz: Jedes Gerät rechnet den Fall aus dem Code selbst aus.</p>" +
        "<ul><li>Der Code ist die Ansage. Wer ihn kennt, kann mitspielen – er ist <b>kein Geheimnis</b>.</li><li>Der Auftrag ist im <b>Postfach unsichtbar</b>: kein Offen-Zähler, keine Heute-Kachel, kein Ereignis. Er läuft nur, solange du ihn offen hast.</li><li><b>Keine Bewertung</b>: kein Geld, kein Ruf, kein erledigter Auftrag, keine Note. Es zählt der Lernstand – wie beim Training.</li><li>Gleicher Code, gleicher Fall: Die Anzeige auf deinem Gerät zeigt denselben Auftrag wie beim Nachbarn.</li></ul>"},
      {titel: "Ansagen: die Lehrkraft", html:
        "<p>In der Ansicht <b>Klasse</b> (Titel „Klassenraum“) wählst du den Auftrag: einen festen Auftrag aus der Liste oder eine Übung aus der Gruppe „(erzeugt)“.</p>" +
        "<table><tr><th>Schritt</th><th>Was passiert</th></tr>" +
        "<tr><td>Auftrag wählen</td><td>fester Auftrag aus der Liste oder eine Übung, die aus einer Fertigkeit erzeugt wird</td></tr>" +
        "<tr><td><b>Code anzeigen</b></td><td>der große Auftragscode <code>NL-XXXX-XX</code> für den Beamer</td></tr>" +
        "<tr><td>Code kopieren</td><td>legt denselben Code in die Zwischenablage</td></tr>" +
        "<tr><td>Klassenraum-Abdruck</td><td>ein Kennwert des <b>geladenen Netzes</b> – nicht des Codes</td></tr></table>" +
        "<p>Der Abdruck ist zum Vergleichen gedacht: Zwei Geräte mit demselben Abdruck haben dasselbe Netz vor sich. Mehr sagt er nicht – siehe „Grenzen“.</p>"},
      {titel: "Öffnen: der Azubi", html:
        "<p>Zwei Wege führen zum selben Auftrag: die Zeile <b>Klassenraum-Code</b> auf der Startseite (Feld, Knopf „Öffnen“, Enter genügt) oder die Ansicht <b>Auftrag</b> (Titel „Mitarbeit“) mit den Feldern „Auftragscode“ und „Platz“ und dem Knopf „Auftrag öffnen“.</p>" +
        "<ul><li><b>Groß oder klein, mit oder ohne Trennstriche</b>: Der Code wird eingelesen, nicht Zeichen für Zeichen verglichen.</li><li>Im Code kommen <b>kein I, kein O, keine 0 und keine 1</b> vor. Wer eines davon sieht, hat sich vertippt.</li><li>Ein Tippfehler wird <b>markiert, nicht abgewiesen</b>: Der Hinweis nennt Länge, Zeichen oder Prüfziffer.</li><li>Der <b>Platz</b> (1 bis 31; leer heißt unverändert) geht in den Ergebnis-Code. Ist derselbe Auftrag schon offen, fragt das Programm: „Weiterarbeiten?“</li></ul>" +
        "<p>Zwei echte Beispiele: <code>NL-HC3L-CS</code> ist ein fester Auftrag, <code>NL-WTQJ-EF</code> eine erzeugte Übung. Beide ergeben auf jedem Gerät denselben Fall.</p>"},
      {titel: "Der Ergebnis-Code", html:
        "<p>Ist der Auftrag bestanden, zeigt ein Hinweis <b>„Für die Lehrkraft“</b> den Ergebnis-Code <code>E-XXXX-XXX</code> mit einem Kopierknopf. Vorher gibt es keinen: Der Code entsteht nur aus einer bestandenen Abnahme.</p>" +
        "<ul><li>Er trägt die <b>Sitzung</b>, den <b>Platz</b>, die erreichten <b>Sterne</b> (0 bis 5), die <b>Fehlversuche</b> (0 bis 3; „3+“ heißt drei oder mehr) und die <b>Dauer</b>.</li><li>Er trägt <b>kein Hilfe-Feld und keine Note</b> – so ist es entschieden.</li></ul>" +
        "<p>Beispiel: <code>E-KFWS-HZM</code> heißt Sitzung 9, Platz 5, 5 Sterne, 1 Fehlversuch, 70 Sekunden.</p>"},
      {titel: "Die Ampel der Lehrkraft", html:
        "<p>Die Ergebnis-Codes kommen blockweise zurück: alles in das Feld <b>Abgabe-Codes</b> einfügen – eine Zeile je Code oder alle auf einmal – und <b>Eintragen</b> drücken. Jede Zeile bekommt eine Rückmeldung: eingetragen, doppelt, fremde Sitzung oder unlesbar.</p>" +
        "<ul><li><b>Schlüssel ist der Platz</b>: Je Platz gilt der <b>erste</b> Eintrag. Ein zweiter Code für denselben Platz wird nicht übernommen.</li><li><b>fertig</b> = eingetragene Plätze, <b>offen</b> = Plätze − fertig. Die Platzzahl (1 bis 31) stellst du unter <b>Datei…</b> ein; „nicht eingestellt“ rechnet nichts aus.</li><li><b>Median</b> = <b>oberer Median</b> der gültigen Dauern (größer als 0), auf ganze Sekunden gerundet. Bei gerader Anzahl ist das die obere der beiden mittleren Zeiten.</li><li>Die Lampe ist <b>grün</b>, wenn alle Plätze eingetragen sind und kein Ergebnis ohne gültigen Platz dabei ist; sonst <b>gelb</b>. Rot ist im Normalbetrieb aus.</li></ul>" +
        "<table><tr><th>Platz</th><th>Sterne</th><th>Dauer</th><th>Fehlversuche</th></tr>" +
        "<tr><td>1 bis 31, sonst „ohne Platz“</td><td>halbe Sterne als ★</td><td>Zeit des Durchgangs</td><td>0, 1, 2 oder „3+“</td></tr></table>" +
        "<p>Unter <b>Datei…</b> liegen Export und Import: Die Sitzung liegt nur auf dem Rechner der Lehrkraft, die Datei ist die Sicherung und der Weg auf ein anderes Gerät. Nach einem Import lässt er sich mit „Rückgängig“ zurücknehmen.</p>"},
      {titel: "Grenzen und was nicht passiert", html:
        "<ul><li><b>Der Code ist kein Geheimnis.</b> Er schützt nichts – er sagt nur, welcher Auftrag gemeint ist.</li><li><b>Der Klassenraum-Abdruck beweist nicht, dass alle denselben Auftrag haben.</b> Er wird aus dem geladenen Netz gebildet (Geräte, Kabel) – verschiedene Aufträge können dasselbe Netz zeigen. Verglichen wird der Auftrag über seine Kennung <code>def.id</code>, nicht über den Abdruck.</li><li><b>Kein Server, kein QR-Code.</b> In dieser Fassung (3.0.0) ist der lokale Klassenraum-Server <b>nicht gebaut</b> – er ist für 3.1 vorgesehen. Deshalb gibt es auch keinen Schalter dafür: Ein Schalter ohne gebauten Server wäre eine Wirkung, die es nicht gibt. Die Klasse gibt die Ergebnis-Codes wie oben beschrieben zurück (abtippen oder einfügen); QR-Codes erzeugt die Fassung 3.0.0 nicht.</li><li><b>Grenzen des Codes:</b> Sitzung 1 bis 31, Platz 0 bis 31, dazu Auftrags- oder Fertigkeitsindex und Variante. Ein Code aus einer anderen Fassung wird abgewiesen, statt einen falschen Auftrag zu bauen.</li><li><b>Keine Bewertung:</b> kein Geld, kein Ruf, kein erledigter Auftrag, keine Note – auch nicht im Ergebnis-Code.</li></ul>"},
    ],
    merksatz: "Gleicher Code, gleicher Auftrag – auf jedem Gerät, ohne Konto und ohne Note.",
    pruefungstipp: "Der Klassenraum ist kein Prüfungsstoff, sondern der Weg, wie eine Klasse denselben Auftrag bekommt. Zeigt dein Gerät etwas anderes als das deines Nachbarn, vergleicht den Auftrag (seine Kennung), nicht den Netzkennwert.",
    quelle: "Klassenraum – B: Oberfläche und Ablauf",
    belege: "Architektur.md § 12 (Klassenraum) · Klassenraum – A: Codec und Determinismus · src/spiel/klassenraum.js · src/spiel/klassenraum-codec.js · src/ui/klassenraum.js",
    siehe: ["lab.cli", "lab.link"],
    suche: ["Klassenraum", "Klassenzimmer", "Unterricht", "Schule", "Auftragscode", "Ergebnis-Code", "Code", "Ampel", "Median", "Beamer", "Lehrkraft", "Azubi", "Platz", "Sitzung", "ohne Konto", "ohne Server"],
  },

  /* ---------- Zusatzseite OHNE eigene Fertigkeit: Übergabe (Leitung, 09.10.2026) ----------
     Ein Rechner, viele Azubis: die zweite große Neuerung der 2.0.0, ebenfalls kein Thema der
     27 Fertigkeiten. Gleiche Form wie alle Seiten; alle Zahlen sind am 09.10.2026 an
     src/spiel/uebergabe.js und src/ui/uebergabe.js gemessen (Ablauf selbst nachgestellt). */
  "uebergabe": {
    titel: "Übergabe",
    kurz: "Ein Rechner wandert zum nächsten Azubi: der Spielstand ist danach leer, die Einstellungen bleiben – und der Lernstand nur, wenn die Lehrkraft ihn behält.",
    abschnitte: [
      {titel: "Was die Übergabe ist", html:
        "<p>Ein Rechner, viele Azubis: Am Ende der Stunde wandert der Rechner zum nächsten Azubi. Ohne Übergabe steckt der zweite Azubi im <b>offenen Auftrag des ersten</b> – genau dafür gibt es dieses Werkzeug.</p>" +
        "<ul><li>Die Übergabe setzt den <b>Spielstand</b> dieses Rechners zurück: Der nächste Azubi bekommt einen leeren Rechner und kann sofort anfangen.</li><li>Sie ist eine <b>Geräte-Operation</b>: kein Konto, kein Server, keine Anmeldung. Alles passiert auf diesem Rechner.</li><li>Danach lädt die Seite neu – erst dadurch ist sicher, dass wirklich kein Auftrag mehr offen ist.</li></ul>"},
      {titel: "Wer sie benutzt", html:
        "<p>Die Lehrkraft (oder der Azubi selbst) <b>am Ende einer Stunde im Computerraum</b>. Zu finden in den Einstellungen: Abschnitt <b>„Rechner übergeben“</b> mit dem Knopf <b>„Rechner übergeben …“</b>.</p>" +
        "<p>Der Dialog <b>„Rechner übergeben?“</b> zeigt zuerst den Stand dieses Rechners (Stufe, Euro, Ruf, erledigte Tickets) und dann die Frage, die alles entscheidet: Was soll mit dem <b>Lernstand</b> passieren?</p>"},
      {titel: "Was bleibt, was geht", html:
        "<table><tr><th>Was</th><th>Nach der Übergabe</th></tr>" +
        "<tr><td><b>Lernstand</b> (die Kästen des Lernmotors)</td><td>bleibt mit „Behalten“; mit „Löschen“ ist er weg</td></tr>" +
        "<tr><td>Einstellungen (Bildungsstand, Klang, Leiste)</td><td>bleiben</td></tr>" +
        "<tr><td>Die rollierende Sicherung des vorherigen Standes im Speicher</td><td>bleibt – sie liegt außerhalb des Spielstands und wird vom Programm selbst geführt</td></tr>" +
        "<tr><td>Geld, Ruf, erledigte Tickets, Fehlerdex, Buch, offener Auftrag</td><td>weg – der Spielstand wird ersetzt</td></tr>" +
        "<tr><td>Postfach</td><td>neu gefüllt; der nächste Azubi kann sofort anfangen</td></tr></table>" +
        "<p>Selbst nachgestellt an einem benutzten Rechner: Geld 33 → 0 Euro, Ruf 4 → 0, erledigte Tickets 2 → 0, offener Auftrag → keiner. Der Lernstand war danach unverändert („Behalten“) beziehungsweise leer („Löschen“); die Einstellungen blieben in beiden Fällen gleich.</p>"},
      {titel: "Der Dialog", html:
        "<ul><li><b>„Behalten“</b> – für diesen Rechner weiterlernen; der Lernstand bleibt.</li><li><b>„Löschen“</b> – der nächste Azubi fängt frisch an; der Lernstand wird gelöscht.</li><li><b>„Erst sichern (Datei)“</b> – lädt den kompletten Speicher als Datei herunter, <b>bevor</b> der Rechner geräumt wird.</li><li><b>„Abbrechen“</b> – nichts passiert; <b>Escape</b> schließt den Dialog ebenfalls.</li></ul>" +
        "<p>Im Dialog steht der Merksatz des Hauses: „Der Lernstand hängt am Rechner, nicht an der Person. Im Computerraum ist „Löschen“ meistens richtig – zu Hause „Behalten“.“ Beim nächsten Öffnen zeigt er unten, wann zuletzt übergeben wurde und ob der Lernstand behalten oder gelöscht wurde.</p>"},
      {titel: "Behalten oder löschen?", html:
        "<p>Der Lernstand gehört dem <b>Lernmotor</b>, nicht dem Spielstand – deshalb bleibt er standardmäßig erhalten. Die Entscheidung trifft die Lehrkraft, denn der Lernstand hängt am <b>Rechner</b>, nicht an der Person:</p>" +
        "<ul><li><b>Computerraum</b> (jede Stunde ein anderer Azubi): „Löschen“, sonst lernt der Nächste mit den Lücken des Vorgängers weiter.</li><li><b>Eigener Rechner</b>: „Behalten“ – die Kästen gehören zu dieser Person.</li></ul>" +
        "<p>Eine Reihenfolge zählt dabei: Bei „Löschen“ wird der Lernstand <b>geleert, bevor</b> der neue Spielstand geladen wird. Andersherum wäre das frische Postfach aus den <b>fälligen Fertigkeiten des Vorgängers</b> gefüllt.</p>"},
      {titel: "Grenzen", html:
        "<ul><li><b>Kein Konto, kein Server.</b> Es gibt keine Anmeldung und keine Nutzerliste; die Übergabe ist eine Datei- und Geräte-Operation.</li><li><b>Keinen Personen-Fortschritt:</b> Wer seinen Stand mitnehmen will, sichert ihn vorher über „Erst sichern (Datei)“ – oder in den Einstellungen im Abschnitt <b>„Spielstand“</b> – und liest die Datei am anderen Rechner wieder ein.</li><li><b>Ohne Lernmotor</b> wird „Löschen“ ehrlich abgelehnt: Es passiert nichts, statt den alten Lernstand still weiterzuführen.</li><li>Für die Übergabe gibt es <b>kein „Rückgängig“</b> – der Weg zurück ist die Sicherungsdatei.</li></ul>"},
    ],
    merksatz: "Der Spielstand gehört dem Azubi, der Lernstand hängt am Rechner.",
    pruefungstipp: "Kein Prüfungsstoff, aber der Unterschied zählt: „Behalten“ lässt den Lernstand auf diesem Rechner stehen, „Löschen“ gibt ihn frei – Geld und offene Aufträge sind in beiden Fällen weg.",
    quelle: "Fahrplan – 1.3 und 2.0 (Schritt 0: Übergabe)",
    belege: "src/spiel/uebergabe.js · src/ui/uebergabe.js · tests/spiel-uebergabe.test.js · tests/ui-uebergabe.test.js",
    siehe: ["lab.speichern"],
    suche: ["Übergabe", "übergeben", "Rechner übergeben", "Computerraum", "nächster Azubi", "Lernstand", "behalten", "löschen", "Spielstand", "Sicherung", "Datei", "zurücksetzen", "ohne Konto", "ohne Server"],
  },

  /* ---------- S7-Vertiefung (Architektur § 17.5): fünf Nachschlage-Seiten OHNE eigene Fertigkeit ----------
     Themen, die im Lernweg vorkommen, aber (noch) keine eigene Fertigkeit haben. Gleiche Form wie alle
     Seiten; Inhalt inhaltlich geprüft, Quellen aus der Whitelist (RFC/IEEE/BSI/Hersteller). Sie stehen
     alle in DATEN.wikiZusatz, damit die Wiki-Ansicht sie ohne Stufenkopf listet. */
  "vpn-ipsec": {
    titel: "VPN und IPsec",
    kurz: "Ein VPN verbindet zwei Netze über ein unsicheres Netz so, als wären sie direkt verkabelt: IPsec verschlüsselt und authentisiert die Pakete auf dem Weg durch das Internet.",
    abschnitte: [
      {titel: "Warum ein Tunnel?", html:
        "<p>Zwei Standorte sollen ihr internes Netz teilen, ohne dass der Verkehr durchs Internet lesbar ist. Eine Standleitung ist teuer, ein <b>Tunnel</b> über das vorhandene Internet ist die übliche Lösung: Die Router verschlüsseln jedes Paket, bevor es das Internet sieht, und entschlüsseln es am anderen Ende. Für die Geräte dahinter sieht es aus wie ein direktes Kabel.</p>" +
        "<ul><li><b>Vertraulichkeit</b>: Mitlesen auf dem Weg ist nutzlos.</li><li><b>Integrität</b>: Veränderte Pakete werden erkannt und verworfen.</li><li><b>Authentizität</b>: Beide Enden wissen, mit wem sie sprechen.</li></ul>"},
      {titel: "IPsec: AH und ESP", html:
        "<p>IPsec besteht aus zwei Protokollen: <b>AH</b> (Authentication Header) sichert Integrität und Echtheit, verschlüsselt aber nicht; <b>ESP</b> (Encapsulating Security Payload) verschlüsselt zusätzlich und wird in der Praxis fast immer allein verwendet. Im <b>Tunnelmodus</b> wird das ganze Paket eingepackt und mit neuen IP-Adressen (den öffentlichen der Router) versehen; im Transportmodus bleibt das ursprüngliche IP-Header sichtbar.</p>" +
        "<p>Daraus folgt: Ein Tunnel verbindet <b>Netze</b>, nicht einzelne Programme. Welche Pakete in den Tunnel dürfen, entscheidet eine eigene Regel („interessanter Verkehr“) – typischerweise genau die Netze beider Standorte.</p>"},
      {titel: "IKE: Schlüssel aushandeln", html:
        "<p>Bevor Daten fließen, handeln beide Seiten mit <b>IKE</b> (IKEv2) die Verschlüsselung aus: Welche Verfahren, welche Schlüssel, wie lange gültig. Dafür braucht jede Seite eine Identität – ein gemeinsames Geheimnis (PSK) oder besser ein Zertifikat. Danach gelten zwei Sicherheitsverbindungen (je Richtung eine), die nach Ablauf automatisch erneuert werden.</p>" +
        "<p>Ein schwacher PSK macht den ganzen Tunnel angreifbar: Wer ihn kennt, kann sich als Standort ausgeben. Zertifikate mit eigener CA sind der sauberere Weg, weil sie sich zentral widerrufen lassen.</p>"},
      {titel: "Was ein VPN nicht löst", html:
        "<ul><li><b>Kein Ersatz für Autorisierung</b>: Wer im Tunnel ist, darf nicht automatisch alles. Rechte und Firewall-Regeln gelten weiter.</li><li><b>Kein Schutz vor Malware</b>: Ein verschlüsselter Tunnel transportiert Schadsoftware genauso zuverlässig wie gute Daten.</li><li><b>Kein Ersatz für ein sicheres Endgerät</b>: Ein gekaperter Laptop im Homeoffice ist ein offenes Tor – auch mit VPN.</li><li><b>Kein WLAN</b>: Ein Funknetz ist etwas anderes; WLAN-Sicherheit (WPA2/WPA3) schützt nur die Funkstrecke, nicht den Weg durchs Internet.</li></ul>"},
      {titel: "Im Labor: planen, nicht tunneln", html:
        "<p><b>Ehrliche Grenze:</b> IPsec-Tunnel, IKE-Aushandlung und verschlüsselte Pakete kommen im Labor nicht vor. Es gibt keine IKE-Aushandlung, keine Security Associations und keine verschlüsselten Pakete. Geübt wird die <b>Planung und Bewertung</b>: Welche Netze müssen verbunden sein, welcher Verkehr darf in den Tunnel, wie authentisieren sich die Enden, und was passiert, wenn der Tunnel ausfällt?</p>" +
        "<p>Ein sauberes Konzept nennt beide Endpunkte, die zu verbindenden Netze, das Verfahren (ESP, IKEv2), die Identität (PSK oder Zertifikat) und einen Rückfallweg, wenn der Tunnel nicht steht.</p>"},
    ],
    merksatz: "Ein VPN macht aus dem Internet eine private Leitung – nicht aus jedem Gerät ein sicheres.",
    pruefungstipp: "ESP verschlüsselt, AH nicht; Tunnelmodus verbindet Netze, Transportmodus einzelne Hosts; IKEv2 handelt die Schlüssel aus. Ein VPN ersetzt weder Firewall noch Berechtigungen.",
    quelle: "05-AP2-Infrastruktur-Sicherheit",
    belege: "RFC 4301 (IPsec-Architektur) · RFC 4303 (ESP) · RFC 7296 (IKEv2) · BSI IT-Grundschutz-Kompendium, NET.3.3 VPN · Infrastruktur & Sicherheit – Visuelle Lernnotiz",
    siehe: ["lab.fw", "lab.dmz", "lab.route"],
    suche: ["VPN", "IPsec", "Tunnel", "Site-to-Site", "ESP", "AH", "IKE", "IKEv2", "PSK", "Zertifikat", "Standort", "Fernzugriff"],
  },
  "tls": {
    titel: "TLS und Zertifikate",
    kurz: "TLS schützt eine Verbindung zwischen zwei Programmen: verschlüsselt, unverändert und mit geprüfter Identität. HTTPS ist HTTP über TLS.",
    abschnitte: [
      {titel: "Was TLS leistet", html:
        "<p><b>TLS</b> (Transport Layer Security) sitzt zwischen Anwendung und TCP. Es sorgt für <b>Vertraulichkeit</b> (Verschlüsselung), <b>Integrität</b> (Veränderungen fallen auf) und <b>Authentizität</b> (der Server weist sich mit einem Zertifikat aus). <b>HTTPS</b> ist nichts anderes als HTTP, das über TLS läuft – standardmäßig Port 443.</p>" +
        "<p>TLS schützt nur die Strecke zwischen den beiden Programmen. Was am Server mit den Daten passiert, sagt es nicht – und ein gefälschter Shop mit gültigem Zertifikat bleibt ein gefälschter Shop.</p>"},
      {titel: "Der Handshake in Kurzform", html:
        "<p>Am Anfang steht der <b>Handshake</b>: Beide Seiten einigen sich auf Version und Verfahren (Cipher Suite). Der Server schickt sein Zertifikat; der Client prüft, ob es von einer vertrauten CA stammt, zum Namen passt und gültig ist. Danach wird ein gemeinsamer Sitzungsschlüssel vereinbart – und der gesamte weitere Verkehr läuft mit <b>symmetrischer</b> Verschlüsselung, weil die viel schneller ist als asymmetrische.</p>" +
        "<table><tr><th>Schritt</th><th>Aufgabe</th></tr><tr><td>ClientHello / ServerHello</td><td>Version, Verfahren, Zufallszahlen</td></tr><tr><td>Zertifikat</td><td>Identität des Servers beweisen</td></tr><tr><td>Schlüsselaustausch</td><td>gemeinsamen Sitzungsschlüssel bilden</td></tr><tr><td>Finished</td><td>Handshake gegen Veränderung absichern</td></tr></table>"},
      {titel: "Zertifikate und Vertrauenskette", html:
        "<p>Ein Zertifikat verbindet einen Namen mit einem öffentlichen Schlüssel und ist von einer <b>CA</b> signiert. Der Client vertraut einigen Wurzel-CAs (im Betriebssystem hinterlegt); die Kette führt vom Serverzertifikat über Zwischen-CAs zur Wurzel. Geprüft werden Name (heute über <b>SAN</b>-Einträge, nicht mehr nur Common Name), Gültigkeitszeitraum und der Status (Widerruf über CRL oder OCSP).</p>" +
        "<p>Ein Zertifikat ist ein Ausweis, kein Passwort: Der private Schlüssel bleibt auf dem Server und verlässt ihn nie. Wer ihn kopiert, kann sich als der Server ausgeben – deshalb ist Diebstahl des Schlüssels der schlimmste Fall, nicht das Ablaufdatum.</p>"},
      {titel: "Typische Fehler", html:
        "<ul><li><b>Abgelaufen</b>: Browser warnt, Verbindungen werden abgelehnt.</li><li><b>Falscher Name</b>: Das Zertifikat gilt für einen anderen Host (SAN prüfen).</li><li><b>Unbekannte CA</b>: Selbstsigniert oder eigene CA, die der Client nicht kennt.</li><li><b>Alte TLS-Version</b>: TLS 1.0/1.1 gelten als unsicher; 1.2 ist Minimum, 1.3 Standard.</li><li><b>Gemischte Inhalte</b>: Eine HTTPS-Seite lädt Bilder über HTTP – der Browser blockt sie.</li></ul>"},
      {titel: "Im Labor: Grenze und Worauf es ankommt", html:
        "<p><b>Ehrliche Grenze:</b> TLS-Handshake und Zertifikatsprüfung kommen im Labor nicht vor. Der HTTP-Dienst antwortet immer mit Erfolg, Port 443 ist ein normaler Port. Geübt wird das <b>Verstehen und Bewerten</b>: Welche Ports sind offen, welche Verbindung ist verschlüsselt, was sagt ein Zertifikatsfehler aus?</p>" +
        "<p>Für die Praxis zählt: richtige Version (TLS 1.2/1.3), gültiges Zertifikat mit passendem Namen, privater Schlüssel geschützt, Widerruf möglich. Ein Zertifikat ohne passenden Namen ist so gut wie keins.</p>"},
    ],
    merksatz: "TLS prüft den Ausweis des Servers und verschlüsselt die Strecke – nicht den Server dahinter.",
    pruefungstipp: "Handshake-Schritte nennen, SAN statt CN, Vertrauenskette CA → Zwischen-CA → Server, TLS 1.2/1.3, HTTPS = HTTP über TLS auf 443.",
    quelle: "05-AP2-Infrastruktur-Sicherheit",
    belege: "RFC 8446 (TLS 1.3) · RFC 5280 (X.509-Zertifikate) · IANA Port Number Registry (443) · BSI IT-Grundschutz-Kompendium, APP.3.1 Webanwendungen",
    siehe: ["lab.ports", "lab.tcp", "lab.dmz"],
    suche: ["TLS", "SSL", "HTTPS", "Zertifikat", "CA", "SAN", "Handshake", "Verschlüsselung", "443", "Widerruf", "OCSP"],
  },
  "8021x": {
    titel: "802.1X und Port-Authentifizierung",
    kurz: "802.1X lässt ein Gerät erst ans Netz, wenn es sich an einem Prüfserver ausgewiesen hat – je Port und je Nutzer statt „Kabel rein, Netz auf“.",
    abschnitte: [
      {titel: "Drei Rollen", html:
        "<p><b>802.1X</b> (Port-Based Network Access Control) regelt den Zugang am Switch- oder WLAN-Port. Drei Rollen wirken zusammen: Der <b>Supplicant</b> ist das Gerät des Nutzers, der <b>Authenticator</b> ist der Switch (oder Access Point), und der <b>Authentisierungsserver</b> ist meist ein <b>RADIUS</b>-Server. Der Switch fragt nur; entschieden wird zentral.</p>" +
        "<table><tr><th>Rolle</th><th>Gerät</th><th>Aufgabe</th></tr><tr><td>Supplicant</td><td>PC, Laptop</td><td>meldet sich mit Zertifikat oder Zugangsdaten an</td></tr><tr><td>Authenticator</td><td>Switch/AP</td><td>sperrt den Port und reicht die Anmeldung weiter</td></tr><tr><td>Server</td><td>RADIUS</td><td>prüft die Anmeldung, erteilt oder verweigert</td></tr></table>"},
      {titel: "Der Ablauf", html:
        "<p>Der Port startet <b>gesperrt</b>: Nur EAPOL-Rahmen (die Anmeldung) kommen durch, aller normale Verkehr nicht. Der Client beginnt die EAP-Aushandlung, der Switch verpackt sie in RADIUS-Anfragen und schickt sie an den Server. Ist die Prüfung erfolgreich, öffnet der Switch den Port – oder weist sogar ein VLAN zu (dynamische VLAN-Zuweisung). Bei WLAN heißt das WPA2-/WPA3-Enterprise.</p>" +
        "<p>Wichtig: 802.1X authentisiert <b>wer</b> am Port hängt, nicht <b>was</b> er danach tut. Berechtigungen im Netz bleiben eine eigene Aufgabe.</p>"},
      {titel: "Warum das besser ist als „Port auf Dauer“", html:
        "<ul><li><b>Zentral sperrbar</b>: Ein Mitarbeiter geht – sein Konto wird gesperrt, nicht der Port.</li><li><b>Kein Generalschlüssel</b>: Jeder meldet sich einzeln an; ein geklautes Kabel bringt nichts.</li><li><b>Nachvollziehbar</b>: Der RADIUS-Server protokolliert, wer wann an welchem Port war.</li><li><b>Gastnetz sauber</b>: Unbekannte Geräte landen in einem isolierten VLAN oder gar nicht im Netz.</li></ul>"},
      {titel: "Grenzen und Fehler", html:
        "<p>Ohne erreichbaren RADIUS-Server bleibt der Port zu – ein Ausfall des Servers sperrt also alle Ports, die ihn brauchen. Deshalb plant man Notfall-Zugänge und überwacht den Server. Geräte ohne 802.1X-Client (Kameras, Drucker) brauchen eine technische Ausnahme (MAC-Authentifizierung oder eigenes Geräte-VLAN) – ein schwacher Ersatz, aber besser als „alle Ports offen“.</p>" +
        "<p>Häufige Fehler: falsche RADIUS-Adresse, fehlendes Zertifikat, Zeitversatz (Zertifikate sind zeitgebunden), vertauschter Shared Secret.</p>"},
      {titel: "Im Labor: Port-Security als Nachbar", html:
        "<p><b>Ehrliche Grenze:</b> 802.1X, RADIUS-Server und EAP-Aushandlung kommen im Labor nicht vor. Was es gibt, ist <b>Port-Security</b>: Sie erlaubt nur bestimmte MAC-Adressen an einem Port und schaltet bei einem fremden Gerät den Port ab (err-disabled). Das ist eine benachbarte Idee – Ausweis der Hardware statt Ausweis des Nutzers – und wird hier geübt.</p>" +
        "<p>Für die Praxis zählt: Rollen kennen, EAP und RADIUS unterscheiden, wissen, was bei Serverausfall passiert, und Ausnahmen für gerätelose Ports begründen.</p>"},
    ],
    merksatz: "802.1X fragt zuerst den Ausweis, dann schaltet der Port durch – entschieden wird zentral im RADIUS.",
    pruefungstipp: "Drei Rollen (Supplicant, Authenticator, Server), EAP im Switch zum RADIUS, Port startet gesperrt, dynamisches VLAN, Ausfall des Servers sperrt Ports.",
    quelle: "05-AP2-Infrastruktur-Sicherheit",
    belege: "IEEE 802.1X (Port-Based Network Access Control) · RFC 3748 (EAP) · RFC 2865 (RADIUS) · BSI IT-Grundschutz-Kompendium, NET.2.1 WLAN-Betrieb · Infrastruktur & Sicherheit – Visuelle Lernnotiz",
    siehe: ["lab.portsec", "lab.switch", "lab.vlan"],
    suche: ["802.1X", "Port-Authentifizierung", "RADIUS", "EAP", "Supplicant", "Authenticator", "dot1x", "Enterprise", "Port-Security"],
  },
  "backup": {
    titel: "Backup und Wiederherstellung",
    kurz: "Eine Sicherung ist erst eine Sicherung, wenn die Wiederherstellung geprüft ist. RAID und Snapshots sind keine Sicherung.",
    abschnitte: [
      {titel: "Schutzziele: RPO und RTO", html:
        "<p>Zwei Zahlen entscheiden jedes Sicherungskonzept: <b>RPO</b> (Recovery Point Objective) sagt, wie viel Datenverlust hinnehmbar ist – daraus folgt der Sicherungsrhythmus. <b>RTO</b> (Recovery Time Objective) sagt, wie schnell der Betrieb wieder laufen muss – daraus folgen Art und Ort der Sicherung. Wer beides nicht kennt, sichert entweder zu wenig oder zu teuer.</p>" +
        "<p>Beispiel: Ein Kassensystem kann 15 Minuten Verlust verkraften und muss in einer Stunde wieder laufen – also häufige Sicherungen und ein getesteter Wiederanlaufplan. Eine Architekturablage mit RPO 24 Stunden braucht das nicht.</p>"},
      {titel: "Arten und Rhythmus", html:
        "<table><tr><th>Art</th><th>Was gesichert wird</th><th>Eigenschaft</th></tr><tr><td>Voll</td><td>alles</td><td>einfach zurückzuspielen, braucht viel Platz und Zeit</td></tr><tr><td>Inkrementell</td><td>Änderungen seit der letzten Sicherung</td><td>klein und schnell, Restore braucht die Kette</td></tr><tr><td>Differenziell</td><td>Änderungen seit der letzten Vollsicherung</td><td>Mittelweg: weniger Stände als inkrementell</td></tr></table>" +
        "<p>Dazu kommen Aufbewahrung (wie lange, wie viele Stände) und der Ort. Ein Plan ohne Aufbewahrungsregel wächst entweder unbegrenzt oder löscht zu früh.</p>"},
      {titel: "3-2-1 und die Offline-Kopie", html:
        "<p><b>3-2-1</b> heißt: drei Kopien der Daten, auf zwei unterschiedlichen Medien, davon eine räumlich getrennt. Gegen Ransomware und versehentliches Löschen hilft zusätzlich eine <b>Offline- oder unveränderbare Kopie</b> (Band, externes Medium, unveränderbarer Speicher): Ein Angreifer im Netz kann sie nicht verschlüsseln, wenn er sie nicht erreicht.</p>" +
        "<ul><li><b>RAID ist keine Sicherung</b>: Ein gelöschter oder verschlüsselter Ordner liegt auf allen Platten gleich.</li><li><b>Snapshot ist keine Sicherung</b>: Er liegt auf demselben System und fällt mit ihm aus.</li><li><b>Ein Medium ist keine Sicherung</b>: Brand, Diebstahl oder Blitzschlag trifft beide Kopien, wenn sie am selben Ort lagern.</li></ul>"},
      {titel: "Wiederherstellung üben", html:
        "<p>Eine ungetestete Sicherung ist eine Hoffnung. Zum Konzept gehört die regelmäßige <b>Restore-Probe</b>: Daten auf einem getrennten System zurückspielen, Zeit messen, Ergebnis dokumentieren. Nur so weiß man, dass RTO und RPO wirklich halten – und dass der Schlüssel für verschlüsselte Sicherungen vorhanden ist.</p>" +
        "<p>Dokumentiert gehören: Quelle, Ziel, Rhythmus, Aufbewahrung, Verantwortliche, Restore-Schritte, letzter Test. Der Notfallplan regelt, in welcher Reihenfolge Systeme wieder anlaufen.</p>"},
      {titel: "Im Labor: bewerten, nicht sichern", html:
        "<p><b>Ehrliche Grenze:</b> Sicherungssoftware und Restore kommen im Labor nicht vor. Es gibt NAS-Freigaben und Dienste, aber keine Backup-Jobs. Geübt wird die <b>Bewertung</b>: RPO/RTO aus dem Betrieb ableiten, Sicherungsart und Ort begründen, 3-2-1 prüfen und die Wiederherstellung beschreiben.</p>"},
    ],
    merksatz: "Erst die geprüfte Wiederherstellung macht aus einer Kopie eine Sicherung.",
    pruefungstipp: "RPO (Datenverlust) und RTO (Ausfallzeit) unterscheiden, voll/inkrementell/differenziell erklären, 3-2-1 nennen, RAID/Snapshot abgrenzen, Restore-Test fordern.",
    quelle: "Storage-Konzeptatlas",
    belege: "BSI IT-Grundschutz-Kompendium, CON.3 Datensicherungskonzept · BSI-Standard 200-4 (Business Continuity Management) · SNIA Dictionary (Snapshot, Backup)",
    siehe: ["lab.storage", "lab.betrieb"],
    suche: ["Backup", "Sicherung", "Restore", "Wiederherstellung", "3-2-1", "RPO", "RTO", "Snapshot", "RAID", "Notfallplan"],
  },
  "virtualisierung": {
    titel: "Virtualisierung und Container",
    kurz: "Ein Hypervisor teilt einen Server in mehrere virtuelle Maschinen; Container teilen sich einen Kernel. Beides spart Hardware – und schafft neue Abhängigkeiten.",
    abschnitte: [
      {titel: "Hypervisor: Typ 1 und Typ 2", html:
        "<p>Ein <b>Hypervisor</b> teilt die Hardware eines Servers in mehrere <b>virtuelle Maschinen</b> (VM). Jede VM hat eigene virtuelle Platten, eigenen Arbeitsspeicher und eine eigene Netzwerkkarte – sie verhält sich wie ein eigener Rechner mit eigenem Betriebssystem. <b>Typ 1</b> läuft direkt auf der Hardware (vom Betriebssystem unabhängig), <b>Typ 2</b> als Programm auf einem normalen Betriebssystem.</p>" +
        "<table><tr><th>Bauart</th><th>Beispiel</th><th>Eigenschaft</th></tr><tr><td>Typ 1</td><td>Rechenzentrum</td><td>nah an der Hardware, wenig Overhead</td></tr><tr><td>Typ 2</td><td>Arbeitsplatz</td><td>einfach ausprobieren, mehr Overhead</td></tr><tr><td>Container</td><td>Serverdienste</td><td>teilen einen Kernel, starten schnell</td></tr></table>"},
      {titel: "Was alles virtualisiert wird", html:
        "<p>Virtualisiert werden nicht nur CPU und RAM: Der <b>virtuelle Switch</b> verbindet die VMs untereinander und nach außen, virtuelle Platten liegen als Datei oder als LUN im Speichernetz, und virtuelle Netzwerkkarten bekommen eigene MAC-Adressen. Für das Netzwerk ist eine VM ein normaler Host – mit Adresse, Gateway und Ports.</p>" +
        "<p>Wichtig für den Betrieb: Ein physischer Serverausfall trifft jetzt alle VMs auf ihm; ein überlasteter Speicher bremst alle gleichzeitig. Virtualisierung bündelt Risiken, sie verteilt sie nicht.</p>"},
      {titel: "Container statt VM", html:
        "<p><b>Container</b> teilen sich den Kernel des Hosts: Sie starten schneller und brauchen weniger Speicher, sind aber weniger stark voneinander getrennt als VMs. Für viele kleine Dienste sind sie praktisch, für fremde oder stark unterschiedliche Betriebssysteme bleibt die VM die saubere Grenze. Beides ist kein Ersatz für Sicherheit: Ein Fehler im Container oder in der VM kann nach außen wirken, wenn die Konfiguration es zulässt.</p>"},
      {titel: "Betrieb: Planung, Backup, Ausfall", html:
        "<ul><li><b>Ressourcen planen</b>: CPU, RAM und die Zugriffe je Sekunde (IOPS) des Speichers begrenzen die Zahl der VMs.</li><li><b>Backup</b>: VM-Snapshots sind kein Ersatz für eine Sicherung – sie liegen auf derselben Infrastruktur.</li><li><b>Ausfall</b>: Ein Host-Ausfall nimmt alle seine VMs mit; Redundanz kostet Geld und muss begründet sein.</li><li><b>Netz</b>: Jede VM braucht ihren Platz im Adressplan und in der Doku.</li></ul>"},
      {titel: "Im Labor: Modell, keine VMs", html:
        "<p><b>Ehrliche Grenze:</b> Eine Hypervisor-Umgebung kommt im Labor nicht vor. Es gibt keine VMs, keine Snapshots und keinen Speicher-LUN, der sich anlegen ließe. Geübt wird das <b>Verständnis</b>: Typ 1/2 unterscheiden, VM und Container vergleichen, Ressourcen- und Ausfallrisiken benennen und in ein Speicherkonzept einordnen.</p>"},
    ],
    merksatz: "Virtualisierung spart Hardware, nicht Verantwortung: Backup und Netzplanung gelten je VM.",
    pruefungstipp: "Hypervisor Typ 1/2, VM vs. Container (eigener Kernel oder geteilt), vSwitch und virtuelle Platten, Ausfall- und Backup-Risiken, Snapshots sind keine Sicherung.",
    quelle: "Brücke – FISI und Alltag zu Storage und Cloud",
    belege: "SNIA Dictionary (Virtualisierung, Snapshot) · BSI IT-Grundschutz-Kompendium, CON.3 Datensicherungskonzept · Brücke – FISI und Alltag zu Storage und Cloud",
    siehe: ["lab.storage", "lab.betrieb"],
    suche: ["Virtualisierung", "Hypervisor", "VM", "Container", "vSwitch", "virtuelle Maschine", "Snapshot", "Cloud", "Ressourcen"],
  },
});

/* ---------- Die Zusatzseiten: Seiten OHNE eigene Fertigkeit ----------
   `DATEN.wiki` ist eine Seite je Fertigkeit (30 seit S6a/S6b; die Indizes 0–26 sind gesperrt:
   Klassenraum-Codec, tools/klassenraum-probe/A-festlegung.md). Klassenraum und Übergabe sind keine Fertigkeiten,
   brauchen aber ein Nachschlagewerk. Diese Liste ist die EINE Quelle der Wahrheit: Die Wiki-Ansicht
   (src/ui/karriere.js `WIKI_ZUSATZ`) liest sie, ebenso die Tests – so muss beim nächsten Zusatz
   nichts an drei Stellen nachgezogen werden. */
DATEN.wikiZusatz = ["klassenraum", "uebergabe", "vpn-ipsec", "tls", "8021x", "backup", "virtualisierung"];
