"use strict";
/* ---------- Erweiterte Labor-Aktionen (4.0) ----------
   R12-Entscheid: Die Aktionen stehen in der rechten Leiste NUR ALS TEXT (Name + Tastenkürzel,
   keine buttons/links/inputs im .ansicht-Kasten); ausgeführt werden sie über das bestehende,
   bereits gezählte ⋯-Menü der Auftragszeile (Kopf „Aktionen“, body-level, zählt nicht).
   Diese Datei ist die EINE Quelle für beide Darstellungen. */;
UI.laborAktionen = (() => {
  function labor(){ try { return (typeof UI !== "null" && UI.labor) || null; } catch (e) { return null; } }
  /* Aktionen nutzen ausschließlich vorhandene Wege; fehlt ein Baustein, erklärt das eine Meldung. */
  const AKTIONEN = [
    {id: "konsole", name: "Konsole", taste: "C", hinweis: "Gerät wählen, dann Konsole öffnen",
      ausfuehren: () => { const l = labor(); const id = l && l.auswahl && l.auswahl.geraet; if (!id) { UI.toast("Wähle zuerst ein Gerät aus.", "info"); return; } l.konsole(id); }},
    {id: "messen", name: "Messen (Ping)", taste: "P", hinweis: "Erreichbarkeit von A nach B prüfen",
      ausfuehren: () => { const l = labor(); if (l && typeof l.werkzeug === "function") l.werkzeug("ping"); }},
    {id: "konfigurieren", name: "Konfigurieren", taste: "I", hinweis: "Inspektor am gewählten Gerät",
      ausfuehren: () => { const l = labor(); if (!l) return; if (typeof l.dock === "function") l.dock("inspektor"); if (typeof l.inspektor === "function") l.inspektor(true); }},
    {id: "akte", name: "Akte", taste: null, hinweis: "Dokumentieren und Verdacht festhalten (kein eigenes Tastenkürzel)",
      ausfuehren: () => { try { UI.akte && typeof UI.akte.freigeben === "function" ? UI.akte.freigeben(true) : UI.toast("Die Akte gehört zu einem laufenden Auftrag.", "info"); } catch (e) { console.error("Aktionen: Akte", e); } }},
    {id: "abnahme", name: "Abnahme", taste: null, hinweis: "Der Kunde prüft die Arbeit (Knopf in der Auftragszeile)",
      ausfuehren: () => { try { UI.spiel && typeof UI.spiel.abnahmeAnfordern === "function" ? UI.spiel.abnahmeAnfordern() : UI.toast("Die Abnahme gibt es nur bei laufendem Auftrag.", "info"); } catch (e) { console.error("Aktionen: Abnahme", e); } }},
    {id: "diagnose", name: "Diagnose", taste: "D", hinweis: "Netzwerkdiagnose starten",
      ausfuehren: () => { const l = labor(); if (l && typeof l.werkzeug === "function") l.werkzeug("diagnose"); }},
    {id: "trace", name: "Trace", taste: "T", hinweis: "Pfadverfolgung starten",
      ausfuehren: () => { const l = labor(); if (l && typeof l.werkzeug === "function") l.werkzeug("trace"); }},
    {id: "protokoll", name: "Protokoll", taste: "L", hinweis: "Systemprotokoll anzeigen",
      ausfuehren: () => { const l = labor(); if (l && typeof l.werkzeug === "function") l.werkzeug("protokoll"); }},
    {id: "benchmark", name: "Benchmark", taste: "B", hinweis: "Leistungsdaten sammeln",
      ausfuehren: () => { const l = labor(); if (l && typeof l.werkzeug === "function") l.werkzeug("benchmark"); }},
  ];
  /* Kontextabhängige Aktionen basierend auf dem aktuellen Zustand */
  function kontextAktionen() {
    const l = labor();
    if (!l) return [];
    const kontext = {
      geraet: l.auswahl && l.auswahl.geraet,
      auftrag: l.auftrag,
      status: l.status
    };
    const erweiterteAktionen = [];
    // Aktionen basierend auf dem Geräte-Typ
    if (kontext.geraet) {
      const geraet = l.geraete && l.geraete[geraet];
      if (geraet && geraet.typ === "router") {
        erweiterteAktionen.push({
          id: "router-konfig",
          name: "Router-Konfig",
          taste: "R",
          hinweis: "Router-Konfiguration anzeigen",
          ausfuehren: () => { l.konsole(geraet.id); }
        });
      }
    }
    
    // Aktionen basierend auf dem Auftragsstatus
    if (kontext.auftrag && kontext.status === "aktiv") {
      erweiterteAktionen.push({
        id: "neue-aktion",
        name: "Neue Aktion",
        taste: "N",
        hinweis: "Neue Aktion hinzufügen",
        ausfuehren: () => { l.neueAktion(); }
      });
    }
    
    return erweiterteAktionen;
  }
  
  /* Kombinationsaktionen */
  function kombinationsAktionen() {
    const l = labor();
    if (!l) return [];
    return [
      {
        id: "kombi-messen",
        name: "Messen + Diagnose",
        taste: "M",
        hinweis: "Messen und Diagnose gleichzeitig starten",
        ausfuehren: () => {
          const l = labor();
          if (l && typeof l.werkzeug === "function") {
            l.werkzeug("ping");
            l.werkzeug("diagnose");
          }
        }
      },
      {
        id: "kombi-protokoll",
        name: "Protokoll + Benchmark",
        taste: "K",
        hinweis: "Protokoll und Benchmark gleichzeitig starten",
        ausfuehren: () => {
          const l = labor();
          if (l && typeof l.werkzeug === "function") {
            l.werkzeug("protokoll");
            l.werkzeug("benchmark");
          }
        }
      }
    ];
  }
  
  function liste(){
    const grundAktionen = AKTIONEN.map(a => ({id: a.id, name: a.name, taste: a.taste, hinweis: a.hinweis}));
    const kontextAktionenListe = kontextAktionen().map(a => ({id: a.id, name: a.name, taste: a.taste, hinweis: a.hinweis}));
    const kombiAktionen = kombinationsAktionen().map(a => ({id: a.id, name: a.name, taste: a.taste, hinweis: a.hinweis}));
    return [...grundAktionen, ...kontextAktionenListe, ...kombiAktionen];
  }
  
  function ausfuehren(id){
    // Versuche erst die erweiterten Aktionen
    const erweiterte = [...AKTIONEN, ...kontextAktionen(), ...kombinationsAktionen()];
    const a = erweiterte.find(x => x.id === id);
    if (!a) return false;
    try { a.ausfuehren(); } catch (e) { console.error("Aktion " + id, e); return false; }
    return true;
  }
  
  /* Einträge für UI.menue (body-level Menü; kein neues Bedienelement in der Ansicht). */
  function menueEintraege(){
    const erweiterte = [...AKTIONEN, ...kontextAktionen(), ...kombinationsAktionen()];
    return erweiterte.map(a => ({text: a.name + "...", sym: null, taste: a.taste || null, titel: a.hinweis, fn: () => ausfuehren(a.id)}));
  }
  
  /* Schnellaktionen - für häufig verwendete Aktionen */
  function schnellauswahltasten() {
    const schnelle = [];
    const alle = [...AKTIONEN, ...kontextAktionen(), ...kombinationsAktionen()];
    for (const a of alle) {
      if (a.taste && a.taste.length === 1) {
        schnelle.push({taste: a.taste, name: a.name, fn: () => ausfuehren(a.id)});
      }
    }
    return schnelle;
  }
  
  /* Benutzerdefinierte Aktionen */
  function benutzerdefinierteAktionen() {
    // Platzhalter für benutzerdefinierte Aktionen
    return [];
}
  
  return {
    liste, 
    ausfuehren, 
    menueEintraege,
    schnellauswahltasten,
    kontextAktionen,
    kombinationsAktionen,
    benutzerdefinierteAktionen
  };
})();