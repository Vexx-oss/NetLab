"use strict";
/* ---------- Spiel-Oberfläche: Ticketfluss (Konzept §§ 3.2, 3.5, 4) ----------
   Postfach (Ansicht „postfach“) · Auftragszeile mit Live-✓ und Auftragsmappe (#labor-auftrag) · Hilfeleiter mit Lösungsvorführung ·
   Abnahme und Ergebnisbildschirm · Onboarding (salon-01 in 60 Sekunden) · Vorhersage beim Ping · Senior-Angebot.
   Die Logik liegt in spiel/*.js; hier nur Anzeige und Bedienung. Start über Bus „ui-bereit“ (ui/start.js). */
UI.spiel = (() => {
  const S = {inst: null, live: null, liveTimer: null, hilfeOffen: false, hilfeAnsicht: null, demo: null, seniorTimer: null, coach: null, vorhersageGefragt: new Set(),
    mappe: {offen: false, reiter: "brief", mehr: false, erstes: false, rein: false, ausloeser: null, fokusReiter: false},
    weg: {iid: null, liste: []}, probe: false};
  const kunde = id => (Spiel.kundenDaten ? Spiel.kundenDaten(id) : (DATEN.kunden || {})[id]) || {name: id || "Kunde", symbol: "✉", farbe: "--accent", ansprechpartner: {name: ""}};
  const NIV = {E: "Einstieg", AP1: "AP1", AP2: "AP2"};
  const sterneText = s => "★".repeat(Math.floor(s)) + (s % 1 ? "½" : "") + "☆".repeat(Math.max(0, 5 - Math.ceil(s)));
  const istTicketNetz = () => S.inst && UI.labor.netz === S.inst.netz;
  const fmtEuro = x => `${eur(x)} €`;
  const absaetze = t => String(t || "").split(/\n{2,}/).map(p => h("p", {}, ...p.split("\n").flatMap((z, i) => i ? [h("br"), z] : [z])));

  /* ---------- Kopfzeile, Tray, Andock-Zähler ---------- */
  function status(){
    if (!Spiel._st) return;
    const st = Spiel.st, offen = Spiel.offen();
    const eph = typeof Spiel.euroProStunde === "function" ? Spiel.euroProStunde() : 0;
    UI.app.status({euro: st.euro, ruf: st.ruf, stufe: st.stufe, offen, fortschritt: stufeFortschritt()});
    try { Plattform.abzeichen(offen, `${offen} ${offen === 1 ? "Ticket" : "Tickets"}${eph ? ` · ${eur(eph)} €/h` : ""}`); } catch (e) { /* Plattform ohne Abzeichen */ }
    UI.app.aktualisieren?.();
  }

  /* Kopfzeile: wie weit bis zur nächsten Stufe? Beide Bedingungen zählen, der knappere Anteil bestimmt den Balken. */
  function stufeFortschritt(){
    try {
      const i = Spiel.stufeInfo();
      if (i.max) return {anteil: 1, text: `Stufe ${i.stufe} · ${i.name} – höchste Stufe erreicht`};
      const r = i.ruf.soll ? Math.min(1, i.ruf.ist / i.ruf.soll) : 1;
      const k = i.koennen.sollSumme ? Math.min(1, i.koennen.summe / i.koennen.sollSumme) : 1;
      const text = `Stufe ${i.stufe} · ${i.name} → ${i.naechste.name}: Ruf ${zahlDe(Math.round(i.ruf.ist))}/${i.ruf.soll} · Können ${i.koennen.summe}/${i.koennen.sollSumme}` + (i.bereit ? " – bereit zum Aufstieg!" : " (Klick: Lernstand)");
      return {anteil: Math.min(r, k), text, bereit: i.bereit};
    } catch (e) { return null; }
  }

  /* ---------- Ticket öffnen ---------- */
  function oeffnen(iid, {ansicht = true} = {}){
    const vorher = Spiel.instanz(iid), erstesMal = !!vorher && !vorher.geoeffnet, briefGelesen = !!vorher?.gelesen;
    const r = Spiel.oeffnen(iid);
    S.inst = r.inst; S.live = null; S.hilfeOffen = false; S.hilfeAnsicht = null; S.demo = null; S.coach = null;
    S.mappe = {offen: false, reiter: "brief", mehr: false, erstes: false, rein: false};
    const niveau = Spiel.niveauVon(r.inst);
    /* Sanftes Onboarding (Bau P7), Station 1: Die Entscheidung steht VOR `UI.labor.laden`, weil
       das Laden die Auftragszeile sofort zeichnet – sonst käme die Begrüßungskarte erst beim
       nächsten Neuzeichnen (gemessen: sie fehlte im ersten Bild). */
    S.einstiegStart = Spiel.einstieg.begruessungNoetig();
    S.einstiegSchluss = false;
    UI.labor.laden(r.netz, {titel: r.def.titel, verlauf: r.verlauf, auftrag: el => auftrag(el),
      ebene: UI.ebenen.fuerSkills(r.def.skills), ansichtMenue: niveau !== "E", fernwartung: r.def.fernwartung || null,
      fernInfo: r.def.fernwartung ? fernInfo(r.def, r.inst) : null,
      blatt: r.def.blatt ? el => UI.blatt.zeichnen(el, r.inst) : null,
      warnungen: () => Spiel.regeln(r.inst).warnungen});          /* Stufenregeln: „!“ je Niveau und Hilfestufe */
    if (ansicht) UI.app.ansicht("labor");
    liveJetzt();
    seniorPlanen();
    /* Die Einführung FÜHRT die erste Handlung: Das Kabel-Werkzeug ist schon gewählt, wenn die
       Begrüßung steht – der Rauchtest zieht das erste Kabel mit echten Mausereignissen, ohne die
       Karte anzuklicken; ohne vorgewähltes Werkzeug würde er ein Gerät verschieben statt zu ziehen. */
    if (S.einstiegStart) { try { UI.labor.werkzeug("kabel"); } catch (e) { /* egal */ } }
    const coach = !S.einstiegStart && !Spiel.st.einstieg.fertig && r.def.id === Spiel.EINSTIEG_TICKET && coachStart();
    /* Beim ersten Öffnen klappt die Mappe einmal auf (Brief, oder Ziele, wenn der Brief im Postfach schon gelesen wurde).
       Im ersten Auftrag übernehmen Willkommen und Coach diese Rolle. Prüfung: keine Mappe.
       `S.einstiegStart` zählt dabei wie der Coach: Die Begrüßungskarte erklärt den Auftrag – eine
       zusätzlich aufklappende Mappe läge über der Zeichenfläche und verdeckte die Geräte
       (gemessen: `tools/rauch.py` meldete „sw1 unter div.am-brief“). */
    if (erstesMal && !coach && !S.einstiegStart && r.inst.quelle !== "pruefung") mappeAuf(r.def.hotline ? "anruf" : briefGelesen ? "ziele" : "brief", true, false);
    status();
  }
  /* Fernwartung (F2): Was zeigt der Bildschirm des Kunden? Das Ziel, das gerade nicht geht – als Symbol mit Namen. */
  function fernInfo(def, inst){
    const k = kunde(inst.kunde || def.kunde), ziele = def.ziele || [];
    const z = ziele.find(x => x.erwartet) || ziele.find(x => x.typ === "erreichbar") || null;
    const zg = z && inst.netz.geraete[z.nach];
    const ziel = zg ? {typ: zg.typ, skin: zg.skin, text: zg.name}                     /* Gerät: dasselbe Bild wie auf der Fläche */
      : {sym: !z ? "⚠" : UI.symbol(z.proto === "dns" ? "suche" : "welt", 20), text: z ? z.name || z.nach || "" : ""};
    return {person: k.ansprechpartner?.name || k.name, symbol: k.symbol, farbe: k.farbe, symptom: def.symptom, ziel};
  }
  function aktiveLaden(){
    const inst = Spiel.aktiveInstanz && Spiel.aktiveInstanz();
    if (inst) oeffnen(inst.iid, {ansicht: false});
  }
  function ticketVerlassen(){
    S.inst = null; S.demo = null; S.coach = null;
    S.mappe.offen = false; S.mappe.erstes = false; S.mappe.ausloeser = null; mappeUmgebung();
    clearInterval(S.seniorTimer); S.seniorTimer = null;
    UI.sandbox?.laden?.();
  }

  /* ---------- Auftragszeile (eine Zeile) + Auftragsmappe (Ausbau 1.2, A2) ----------
     Zeile: Kunde · Titel · Ziele x/y · [Auftrag lesen] · [Abnahme] · ⋯ (Hilfe, Nachschlagen, Zurücksetzen, Postfach).
     Genau ein Hauptknopf: die Abnahme – außer ein offenes Feld (Mappe, Hilfeleiter) hat einen eigenen. */
  function auftrag(el){
    const inst = S.inst;
    mappeUmgebung();
    if (!inst || !Spiel.instanz(inst.iid)) {
      /* gerade abgenommen (Funktionsprobe läuft): Titel bleibt stehen, mit Haken */
      const f = S.fertig;
      el.append(f ? h("div", {class: "am-zeile am-fertig"}, marke(f.name || f.titel, f.farbe),
          h("div", {class: "am-titel"}, h("strong", {}, "✓ " + f.titel), h("span", {class: "am-kunde"}, "abgenommen – Funktionsprobe")))
        : h("div", {class: "lb-auftrag-standard"}, h("strong", {}, "Kein offenes Ticket")));
      return;
    }
    const def = Spiel.defVon(inst), k = kunde(inst.kunde || def.kunde), niveau = Spiel.niveauVon(inst);
    if (inst.quelle === "pruefung") return pruefungsLeiste(el, inst, def);
    const regel = Spiel.regeln(inst), live = regel.liveHaken;
    const stand = S.live || {status: (def.ziele || []).map(z => ({ziel: z, ok: null}))};
    const n = stand.status.length, erfuellt = stand.status.filter(s => s.ok).length, alle = live && n > 0 && erfuellt === n;
    const naechste = Spiel.naechsteHilfe(inst);
    const abnahme = h("button", {type: "button", class: "knopf primaer sp-abnahme" + (alle ? " bereit" : ""), title: "Abnahme anfordern: Der Kunde prüft selbst nach.", onclick: abnahmeAnfordern}, "✓ Abnahme");
    const zeile = h("div", {class: "am-zeile"},
      marke(k.name, k.farbe),
      h("div", {class: "am-titel"}, h("strong", {}, def.titel), h("span", {class: "am-kunde"}, inst.raetsel ? [UI.symbol("raetsel", 14), ` Tagesrätsel #${inst.raetsel.nr} · ${Spiel.NIVEAU_NAME[inst.raetsel.niveau] || inst.raetsel.niveau}`] : k.name)),
      h("span", {class: "am-ziele" + (alle ? " fertig" : ""), title: live ? "Erfüllte Ziele – Liste in der Mappe" : "AP2: Ziele prüfst du selbst"},
        live ? `Ziele ${erfuellt}/${n}` : `${n} ${n === 1 ? "Ziel" : "Ziele"}`),
      h("div", {class: "am-knoepfe"},
        h("button", {type: "button", class: "knopf am-lesen" + (S.mappe.offen ? " an" : ""), "aria-expanded": String(S.mappe.offen), title: "Auftragsmappe: Brief und Ziele",
          onclick: () => S.mappe.offen ? mappeZu() : mappeAuf("brief")}, UI.symbol("mappe", 17), "Auftrag lesen"),
        abnahme,
        h("button", {type: "button", class: "knopf geist am-mehr", title: "Mehr: Hilfeleiter, Wiki, Zurücksetzen", "aria-label": "Mehr", onclick: e => menue(e, inst, def)}, "⋯"),
        /* 3.1.0 (B3/3): Bei 960/720 ist die Werkzeugleiste ausgeblendet — dieser Knopf in der (dort
           sichtbaren) Auftragszeile öffnet die Kernaktionen als body-level Menü „Aktionen“.
           K_net +1 nur auf diesen Breiten (Lead-Freigabe); 1440/1366 unverändert. */
        (typeof innerWidth === "number" && innerWidth < 1100 && typeof UI !== "undefined" && UI.laborAktionen && typeof UI.menue === "function")
          ? h("button", {type: "button", class: "knopf geist am-aktionen", "data-aktionen": "1", "aria-haspopup": "menu",
              title: "Aktionen: Konsole, Messen, Konfigurieren, Akte, Abnahme", onclick: e => {
                const r = e.currentTarget.getBoundingClientRect();
                UI.menue(r.left, r.bottom + 4, UI.laborAktionen.menueEintraege(), {titel: "Aktionen"});
              }}, "Aktionen")
          : null));
    const ungespeichert = Spiel.speichernErwartet(def, niveau) ? Spiel.ungespeicherteGeraete(inst) : [];
    el.append(h("div", {class: "sp-auftrag", style: {"--k": `var(${k.farbe || "--accent"})`}}, zeile,
      S.einstiegStart ? einstiegKarte() : null,
      ungespeichert.length ? h("p", {class: "sp-ungespeichert"}, UI.symbol("sicherung", 15), " Nicht gespeichert: ", ungespeichert.map(g => g.name).join(", "),
        niveau === "AP2" ? " – die Abnahme startet die Geräte neu!" : " – nach einem Neustart wäre die Änderung weg.") : null,
      S.coach ? coachLeiste() : null,
      S.hilfeOffen ? hilfePanel(inst, def, naechste) : null));
    if (S.mappe.offen) { const mm = mappe(def, k, stand, live, regel.liveGrund); el.append(mm); mappeLinksSetzen(mm, el); }
    if (el.querySelectorAll(".primaer").length > 1) abnahme.classList.remove("primaer");
    S.mappe.rein = false;
    /* Reiterwechsel zeichnet die Mappe neu – der Fokus bleibt auf dem gewählten Reiter (Runde 5). */
    if (S.mappe.fokusReiter) { S.mappe.fokusReiter = false; fokusSetzen(document.querySelector(".am-tab.an")); }
  }
  /* Fokus erst im nächsten Frame setzen: die Mappe wird gerade neu gezeichnet, das alte Element
     ist weg. Ohne requestAnimationFrame (schmale Testumgebung) sofort – und nie mit Fehler. */
  function fokusSetzen(el){
    if (!el || typeof el.focus !== "function") return;
    const tun = () => { try { el.focus({preventScroll: true}); } catch (e) { try { el.focus(); } catch (e2) { /* ohne DOM */ } } };
    if (typeof requestAnimationFrame === "function") requestAnimationFrame(tun); else tun();
  }
  /* Die Mappe ist ein eigenes Blatt über der Karte (Runde 5, § 2 A): solange sie offen ist, ruht die
     Werkzeugleiste der Fläche. Die Klasse .mappe-an steht am .labor; die Regeln (Leisten und
     Flächentitel ausblenden) liegen in editor.css neben den Werkzeugleisten. Sie wird bei JEDEM
     Neuzeichnen gesetzt – damit fällt sie auch beim Schließen, beim Ticketende und beim
     Ansichtswechsel wieder weg und die Karte bekommt ihre Werkzeuge zurück. */
  function mappeUmgebung(){
    try {
      const labor = document.querySelector(".labor");
      if (labor) labor.classList.toggle("mappe-an", !!S.mappe.offen && !!S.inst && UI.app.aktuell === "labor");
    } catch (e) { /* ohne DOM (Tests) */ }
  }
  /* Die Mappe beginnt an derselben Innenkante wie die Auftragszeile: der Rahmen .lb-auftrag ist je
     Theme und Media unterschiedlich gepolstert (16–24 px) – gemessen statt geschätzt, als CSS-Variable.
     Ohne getComputedStyle (schmale Testumgebung) bleibt der Rückfall aus spiel.css (16 px). */
  function mappeLinksSetzen(mm, el){
    try {
      const pl = parseFloat(getComputedStyle(el).paddingLeft) || 0;
      if (pl) mm.style.setProperty("--am-links", pl + "px");
    } catch (e) { /* ohne DOM */ }
    mappeHoeheKlemmen(mm);
  }
  /* Die Mappe hängt unter dem Auftragsband. Auf niedrigen Fenstern reichen 70 vh nicht bis zum Fuß:
     dann deckelt die Höhe der freie Platz bis zum Fensterrand (8 px Luft), damit Fußaktion und X immer
     erreichbar bleiben. Gemessen statt geschätzt; CSS-Rückfall bleibt min(70vh, 560px). */
  function mappeHoeheKlemmen(mm){
    try {
      const r = mm.getBoundingClientRect();
      const platz = Math.floor((window.innerHeight || 0) - r.top - 8);
      const max = Math.min(Math.round((window.innerHeight || 0) * 0.7), 560, platz);
      if (max > 160) mm.style.setProperty("--am-max", max + "px");
    } catch (e) { /* ohne DOM */ }
  }
  function mappeAuf(reiter = "brief", erstes = false, mitFokus = true){
    const z = mitFokus && typeof document !== "undefined" ? document.activeElement : null;
    S.mappe.ausloeser = z && z !== document.body ? z : null;
    Object.assign(S.mappe, {offen: true, reiter, erstes, rein: true});
    UI.labor.auftragNeu();
    if (mitFokus) fokusSetzen(document.querySelector(".am-mappe"));
  }
  function mappeZu(){
    if (!S.mappe.offen) return;
    const zurueck = S.mappe.ausloeser;
    S.mappe.offen = false; S.mappe.erstes = false; S.mappe.ausloeser = null;
    UI.labor.auftragNeu();
    mappeUmgebung();
    /* Fokus zurück zum Auslöser (Runde 5, § 2 A); ohne brauchbaren Auslöser zum Knopf „Auftrag lesen“. */
    const ziel = zurueck && zurueck.isConnected && !zurueck.hidden ? zurueck : document.querySelector(".am-lesen");
    fokusSetzen(ziel);
  }
  /* Reiterwechsel: Mappe neu zeichnen, Fokus danach auf den gewählten Reiter. */
  function reiterWechsel(id){ S.mappe.reiter = id; S.mappe.fokusReiter = true; UI.labor.auftragNeu(); }
  function mappe(def, k, stand, live, mitGrund){
    const m = S.mappe, inst = S.inst, n = stand.status.length, erfuellt = stand.status.filter(s => s.ok).length;
    const niveau = inst ? Spiel.niveauVon(inst) : null;
    const titelId = "am-mappe-titel";            /* eine Kennung, zwei Stellen (h2 + aria-labelledby) */
    const zielText = live ? `Ziele ${erfuellt}/${n}` : `${n} ${n === 1 ? "Ziel" : "Ziele"}`;
    const reiter = h("div", {class: "am-reiter", role: "tablist", "aria-label": "Auftragsmappe"},
      [def.hotline ? ["anruf", "Anruf"] : ["brief", "Brief"], ["ziele", "Ziele"], def.fernwartung || def.blatt ? null : ["plan", "Plan"]].filter(Boolean).map(([id, titel]) =>
        h("button", {type: "button", role: "tab", class: "am-tab" + (m.reiter === id ? " an" : ""), "aria-selected": String(m.reiter === id),
          onclick: () => reiterWechsel(id)}, titel)));
    /* Kopf des Blattes (Runde 5, § 2 A): Kicker AUFTRAG · Kunde, Titel = Auftrag, Meta = Ziele/Niveau.
       Kein zweiter Kopf: Werkzeugleiste und Flächentitel ruhen, solange die Mappe offen ist. */
    const kopf = h("header", {class: "am-kopf"},
      h("div", {class: "am-kopf-text"},
        h("p", {class: "am-kicker"}, "AUFTRAG", h("span", {class: "am-trenner", "aria-hidden": "true"}, "·"), k.name),
        h("h2", {class: "am-kopf-titel", id: titelId}, def.titel),
        h("p", {class: "am-meta", title: live ? null : "AP2: Ob die Ziele erreicht sind, prüfst du selbst."},
          h("span", {}, zielText), h("span", {class: "am-trenner", "aria-hidden": "true"}, "·"), h("span", {}, NIV[niveau] || niveau || "Auftrag"))),
      h("button", {type: "button", class: "am-zu", title: "Schließen (Esc)", "aria-label": "Mappe schließen", onclick: () => mappeZu()}, UI.symbol("schliessen", 17)));
    let inhalt;
    if (def.hotline && m.reiter === "brief") m.reiter = "anruf";
    if (m.reiter === "anruf" && def.hotline) inhalt = anrufAnsicht(def, k);
    else if (m.reiter === "plan") {
      /* Netzplan (Phase B): aus dem Soll-Netz; „Neben das Labor heften“ legt ihn als Reiter ins Dock */
      inhalt = h("div", {class: "am-plan"});
      UI.netzplan.zeichnen(inhalt, S.inst, {mappe: true});
    } else if (m.reiter === "ziele") {
      inhalt = h("div", {class: "am-ziele-liste"},
        geruestTipp(def),
        h("ul", {class: "sp-ziele"}, stand.status.map((s, i) => h("li", {class: live ? (s.ok ? "ok" : s.ok === false ? "offen" : "") : "neutral", "data-i": i},
          h("span", {class: "sp-haken", "aria-hidden": "true"}, live ? (s.ok ? "✓" : "○") : "•"),
          h("span", {class: "am-ziel-text"}, s.ziel.typ === "antwort" ? s.ziel.frage : s.ziel.text || s.ziel.typ,
            mitGrund && s.ok === false && s.grund ? h("span", {class: "am-grund"}, Spiel.grundTitel(s.grund)) : null,
            s.ziel.typ === "antwort" ? antwortFeld(s.ziel) : null, s.ziel.typ === "notiz" ? notizFeld(s.ziel) : null),
          s.ziel.typ === "blockiert" ? h("span", {class: "sp-blockiert"}, " darf nicht gehen") : null,
          s.ziel.typ === "befehl" && !s.ok ? h("button", {type: "button", class: "knopf geist klein am-terminal", title: "Terminal dieses Geräts öffnen (Doppelklick auf das Gerät geht auch)",
            onclick: () => { mappeZu(); UI.terminal.oeffnen(s.ziel.geraet); }}, "Terminal ▸") : null))),
        live ? null : h("p", {class: "am-hinweis"}, "AP2: Ob die Ziele erreicht sind, prüfst du selbst – die Abnahme sagt, ob es reicht."));
    } else {
      /* höchstens ~60 Wörter sichtbar, der Rest auf „mehr“ */
      const text = String(def.briefing || ""), woerter = text.split(/\s+/).filter(Boolean);
      const kurz = !m.mehr && woerter.length > 70;
      let sichtbar = text;
      if (kurz) { let z = 0, i = 0; for (const t of text.split(/(\s+)/)) { if (t.trim()) z++; if (z > 60) break; i += t.length; } sichtbar = text.slice(0, i).trimEnd() + " …"; }
      const ap = k.ansprechpartner || {};
      inhalt = h("div", {class: "am-brief"},
        h("div", {class: "am-absender"}, marke(k.name, k.farbe),
          h("span", {}, h("b", {}, ap.name || k.name), ap.rolle ? `, ${ap.rolle}` : "", ` · ${k.name}`)),
        klassenraumZeile(),
        h("div", {class: "am-text"}, absaetze(sichtbar)),
        kurz ? h("button", {type: "button", class: "knopf geist klein", onclick: () => { m.mehr = true; UI.labor.auftragNeu(); }}, "mehr lesen") : null,
        def.symptom ? h("p", {class: "am-symptom"}, h("b", {}, "Symptom: "), def.symptom) : null,
        geruestTipp(def),
        variantenWahl(def));
    }
    /* Fuß: genau EINE Hauptaktion; beim ersten Öffnen zusätzlich die ruhige Sekundäraktion
       „Ziele ansehen“ (Runde 5, § 2 A). */
    const fuss = h("div", {class: "am-fuss"},
      m.erstes && m.reiter !== "ziele"
        ? h("button", {type: "button", class: "knopf geist", onclick: () => reiterWechsel("ziele")}, "Ziele ansehen")
        : null,
      h("button", {type: "button", class: "knopf primaer", onclick: () => mappeZu()}, m.erstes ? "Los geht’s" : "Zurück ins Labor"));
    return h("section", {class: "am-mappe" + (m.rein ? " rein" : ""), role: "dialog", "aria-labelledby": titelId, tabindex: "-1",
      style: {"--k": `var(${k.farbe || "--accent"})`}}, kopf, reiter, h("div", {class: "am-inhalt"}, inhalt), fuss);
  }
  /* Flow-Regler (§ 20 F6): Gerüst – die Frage des Seniors steht gleich da (frei), in Brief und Zielen */
  /* Klassenraum am geöffneten Auftrag (B § 3.3: „B und C messen denselben Abdruck"): Der Azubi muss
     SEHEN, welcher Platz er ist – er tippt ihn später in die Ampel der Lehrkraft ein – und welchen
     Netz-Abdruck sein Auftrag trägt. Reiner TEXT: kein Bedienelement, keine neue Klasse; bei einem
     normalen Auftrag bleibt die Zeile weg (Gegenprobe im Test). */
  function klassenraumZeile(){
    const inst = S.inst;
    if (!inst || !(inst.quelle === "klassenraum" || inst.klassenraum)) return null;
    const platz = Number(inst.klassenraum && inst.klassenraum.platz) || 0;
    let abdruck = null;
    try { abdruck = typeof Spiel.klassenraum?.netzkennwert === "function" && inst.netz ? Spiel.klassenraum.netzkennwert(inst.netz) : null; } catch (e) { abdruck = null; }
    const teile = [h("b", {}, UI.symbol("welt", 15), " Klassenraum-Auftrag"), " · ", platz >= 1 ? `Platz ${platz}` : "ohne Platz"];
    if (abdruck) teile.push(" · Netz-Abdruck ", h("b", {}, abdruck));
    /* „Ich hänge" (3.0, Säule 5, Weg A): HIER hängt der Azubi — der Knopf holt den Hilfecode,
       zeigt ihn im Knopf und kopiert ihn beim Klick. Die Kette samt ehrlicher Absage liegt in
       `UI.klassenraum.hilfeKnopf()` (öffentliche Fläche, dort auch geprüft); diese Datei hängt ihn
       nur ein. Fehlt der Baustein in einer schmalen Fassung, bleibt die Zeile reiner Text. */
    const knopf = typeof UI.klassenraum?.hilfeKnopf === "function" ? UI.klassenraum.hilfeKnopf() : null;
    return h("p", {class: "am-hinweis"}, teile, knopf ? " " : null, knopf);
  }
  function geruestTipp(def){
    const frage = S.inst && S.inst.flow === "geruest" ? (def.hilfen?.frage || [])[0] : null;
    return frage ? h("p", {class: "am-geruest"}, h("span", {"aria-hidden": "true"}, UI.symbol("trace", 15)), " ", h("b", {}, "Der Senior: "), `„${frage}“`,
      h("span", {class: "am-geruest-hinweis"}, "Diesmal mit Gerüst: Haken und Warnungen sind an, ein zweiter Versuch kostet nichts.")) : null;
  }
  /* E2 Kundenakte im Ergebnis: Atlas erschlossen, Vertrauen gestiegen, neues Kapitel – eine Zeile im Block „Dein Weg“ */
  function akteZeile(erg){
    const a = erg.kundenakte || {neuHell: [], vertrauen: {vorher: 0, nachher: 0}};
    const teile = [];
    if (a.neuHell.length) teile.push(`🗺 ${a.neuHell.length} ${a.neuHell.length === 1 ? "Gerät" : "Geräte"} im Netz-Atlas (${a.hell}/${a.gesamt}${a.komplett ? ", komplett betreut" : ""})`);
    if (a.vertrauen.nachher > a.vertrauen.vorher) teile.push(`♥ Vertrauen ${a.vertrauen.nachher}/5`);
    if (a.kapitel) teile.push(`Neue Geschichte: „${a.kapitel.titel}“ (Kunden → Akte)`);
    if (a.empfehlung) teile.push(`${a.empfehlung.neu ? `Empfehlung: ${Spiel.kundenDaten(a.empfehlung.kunde).name} kommt eine Stufe früher` : "Empfehlung an einen anderen Kunden"}`);
    const f = erg.flow;
    if (f && f.stand !== f.vorher && f.stand !== "normal" && Spiel.flow.an()) teile.push(f.stand === "geruest" ? `Nächstes Mal „${Spiel.skill(f.skill).name}“ mit Gerüst` : `„${Spiel.skill(f.skill).name}“ sitzt – der nächste wird kniffliger`);
    if (a.rabatt) teile.push(`🏷 Wartungsvertrag −${Math.round(Spiel.VERTRAUEN_LOHN.rabattAnteil * 100)} %`);
    return teile.length ? h("p", {class: "sp-akte-zeile"}, teile.join(" · ")) : null;
  }
  /* E1 „Provisorium oder sauber?“: zwei Karten im Brief; nach der Wahl eine Zeile (bis zur ersten Abnahme änderbar) */
  function variantenWahl(def){
    const inst = S.inst, v = Spiel.varianten.fuer(def);
    if (!v || !inst) return null;
    const gewaehlt = inst.variante && Spiel.VARIANTE[inst.variante], aenderbar = !(inst.abnahmen > 0);
    const waehlen = id => { Spiel.varianten.waehlen(inst, id); liveJetzt(); };
    if (gewaehlt && !S.mappe.wahlOffen) return h("div", {class: "am-variante gewaehlt"}, h("span", {}, `${gewaehlt.sym} ${gewaehlt.titel}: `, h("span", {class: "am-variante-text"}, gewaehlt.text)),
      aenderbar ? h("button", {type: "button", class: "knopf geist klein", onclick: () => { S.mappe.wahlOffen = true; UI.labor.auftragNeu(); }}, "ändern") : null);
    return h("div", {class: "am-variante"}, h("p", {class: "am-variante-frage"}, h("b", {}, "Wie gehst du vor?")),
      h("div", {class: "am-variante-karten"}, v.map(x => h("button", {type: "button", class: "am-variante-karte" + (inst.variante === x.id ? " an" : ""),
        onclick: () => { S.mappe.wahlOffen = false; waehlen(x.id); }}, h("b", {}, `${x.sym} ${x.titel}`), h("span", {class: "am-variante-text"}, x.text)))));
  }
  /* Änderungsnotiz (Zielart „notiz“, Variante „sauber“) */
  function notizFeld(ziel){
    const inst = S.inst;
    return h("textarea", {class: "am-notiz", rows: "2", placeholder: "Was hast du an welchem Gerät geändert – und warum?", "aria-label": ziel.text,
      onkeydown: e => e.stopPropagation(), onchange: e => { Spiel.notizSetzen(inst, e.target.value); liveJetzt(); }}, (inst && inst.notiz) || "");
  }
  /* Hotline (E1): Anruf als Gesprächsverlauf, drei Rückfragen zur Wahl, nach dem Auflegen die Bewertung mit Begründung */
  function anrufAnsicht(def, k){
    const inst = S.inst, st = Spiel.hotline.stand(inst), wer = (k.ansprechpartner || {}).name || k.name;
    const blase = (von, text, kl) => h("div", {class: "ht-blase " + kl}, h("b", {}, von), h("span", {}, text));
    const verlauf = [blase(wer, def.briefing, "kunde")];
    for (const id of st.gefragt) { const f = st.def.fragen.find(x => x.id === id); if (f) verlauf.push(blase("Du", f.text, "du"), blase(wer, f.antwort, "kunde")); }
    const neu = () => { UI.labor.auftragNeu(); requestAnimationFrame(() => { const v = document.querySelector(".ht-verlauf"); if (v) v.scrollTop = v.scrollHeight; }); };
    const fragen = st.fertig ? null : h("div", {class: "ht-fragen"},
      h("p", {class: "ht-rest"}, `Noch ${st.rest} ${st.rest === 1 ? "Frage" : "Fragen"} – frag gezielt:`),
      ...st.def.fragen.filter(f => !st.gefragt.includes(f.id)).map(f => h("button", {type: "button", class: "ht-frage", onclick: () => { Spiel.hotline.fragen(inst, f.id); neu(); }}, f.text)),
      h("button", {type: "button", class: "knopf geist klein", onclick: () => { Spiel.hotline.auflegen(inst); neu(); }}, "Auflegen – ich schau selbst nach"));
    const b = st.fertig ? Spiel.hotline.bewertung(inst) : null;
    return h("div", {class: "ht-anruf"}, h("div", {class: "ht-verlauf"}, ...verlauf), fragen,
      b ? h("div", {class: "ht-bewertung"}, h("p", {}, h("b", {}, "☎ " + b.text)), ...b.hinweise.map(t => h("p", {class: "am-hinweis"}, t))) : null);
  }
  /* Zielart „antwort“ (C4): Wert aus der Terminal-Ausgabe eintragen; geprüft wird gegen das Netz (Haken nur, wo das Niveau ihn zeigt) */
  function antwortFeld(ziel){
    const inst = S.inst, wert = ((inst && inst.antworten) || {})[Spiel.antwortSchluessel(ziel)] || "";
    const eintragen = () => { if (!S.inst) return; Spiel.antwortSetzen(S.inst, ziel, feld.value); liveJetzt(); };
    const feld = h("input", {type: "text", class: "am-antwort", value: wert, placeholder: "Wert aus der Ausgabe", spellcheck: "false", autocomplete: "off", "aria-label": ziel.frage,
      onkeydown: e => { e.stopPropagation(); if (e.key === "Enter") { e.preventDefault(); eintragen(); } }});
    return h("span", {class: "am-antwort-zeile"}, feld, h("button", {type: "button", class: "knopf klein", onclick: eintragen}, wert ? "Ändern" : "Eintragen"));
  }
  /* Prüfungstag: keine Hilfe, keine Live-Ziele, Restzeit sichtbar */
  function pruefungsLeiste(el, inst, def){
    const p = Spiel.pruefung && Spiel.pruefung.aktiv();
    const rest = p ? Spiel.pruefung.restMs(p) : 0, mm = Math.floor(rest / 60000), ss = String(Math.floor(rest / 1000) % 60).padStart(2, "0");
    const nr = p ? p.aufgaben.indexOf(inst.iid) + 1 : 0;
    el.append(h("div", {class: "sp-auftrag pruefung"},
      h("div", {class: "sp-auftrag-kopf"}, h("span", {class: "sp-kunde-sym"}, UI.symbol("urkunde", 24)),
        h("div", {class: "sp-auftrag-titel"}, h("strong", {}, def.titel), h("span", {}, `Prüfung ${p ? p.art : ""} · Aufgabe ${nr}/${p ? p.aufgaben.length : "?"} · Restzeit ${mm}:${ss}`)),
        h("div", {class: "sp-auftrag-knoepfe"}, h("button", {type: "button", class: "knopf primaer", onclick: () => UI.karriere?.pruefungUebersicht?.()}, "Zur Prüfungsübersicht"))),
      h("div", {class: "sp-auftrag-mitte"}, h("p", {class: "sp-symptom"}, h("b", {}, "Aufgabe: "), def.symptom || ""),
        h("ul", {class: "sp-ziele"}, (def.ziele || []).map(z => h("li", {class: "neutral"}, h("span", {class: "sp-haken"}, "•"), h("span", {}, z.text || z.typ)))))));
    clearTimeout(S.pruefTimer);
    if (p) S.pruefTimer = setTimeout(() => { if (Spiel.pruefung.aktiv() && S.inst === inst) UI.labor.auftragNeu(); else if (!Spiel.pruefung.aktiv()) UI.toast("Die Prüfungszeit ist abgelaufen – die Prüfung wurde abgegeben.", "info"); }, 1000);
  }
  function menue(e, inst, def){
    const r = e.currentTarget.getBoundingClientRect(), stufe = inst.hilfeStufe || 0;
    /* 3.1.0 (B3/3): Kernaktionen oben im BESTEHENDEN ⋯-Menü (Kopf „Aktionen“); body-level, zählt nicht. */
    const kern = (typeof UI !== "undefined" && UI.laborAktionen && typeof UI.laborAktionen.menueEintraege === "function")
      ? UI.laborAktionen.menueEintraege() : [];
    const eintraege = [
      /* „Hilfe 3/6" statt „Stufe 3/6": das Wort „Stufe" bedeutet im Programm schon vier andere Dinge
         (Karriere, Bildungsstand, Erklärtiefe, Prüfungsstrenge) — hier ist die Sprosse der Hilfeleiter
         gemeint. Der Knopf daneben heißt ohnehin „Hilfe" (Review Auffindbarkeit, Befund 4). */
      {text: S.hilfeOffen ? "Hilfeleiter schließen" : "Hilfeleiter", sym: "hilfe", info: stufe ? `Hilfe ${stufe}/6` : "vom Hinweis bis zur Lösung",
        fn: () => { S.hilfeOffen = !S.hilfeOffen; if (S.hilfeOffen) S.mappe.offen = false; UI.labor.auftragNeu(); }},
    ];
    if (!def.fernwartung && !def.blatt) eintraege.push({text: "Netzplan neben dem Labor", sym: "plan", fn: () => UI.netzplan.anheften(inst)});
    if (inst.providerStoerung) eintraege.push({text: "Provider anrufen", sym: "warnung", info: "Störung melden", fn: () => { if (Spiel.ereignisse.providerAnrufen(inst)) UI.toast("Störung gemeldet – das Internet ist wieder da. +1 Ruf fürs Erkennen.", "ok", {dauer: 3800}); UI.labor.auftragNeu(); }});
    if (Spiel.verdacht.noetig(inst)) eintraege.push({text: "Akte und Verdacht", sym: "akte", info: inst.verdacht ? "festgehalten" : null, fn: () => UI.akte.freigeben(true)});
    if (Spiel.werkzeug.hat("netzpruefer") && Spiel.niveauVon(inst) !== "E")
      eintraege.push({text: inst.netzpruefer ? "Netzprüfer ausschalten" : "Netzprüfer einschalten", sym: "warnung", info: "Werkzeug",
        fn: () => { Spiel.werkzeug.netzpruefer(inst); UI.labor.auffrischen?.(); UI.labor.auftragNeu(); }});
    if (Spiel.niveauVon(inst) !== "AP2" && typeof UI.wiki?.oeffnen === "function" && (def.skills || [])[0])
      eintraege.push({text: "Wiki: " + Spiel.skill(def.skills[0]).name, sym: "wiki", fn: () => UI.wiki.oeffnen(def.skills[0])});
    eintraege.push("-",
      {text: "Ticket zurücksetzen", sym: "neustart", fn: () => { Spiel.zuruecksetzen(inst); S.live = null; liveJetzt(); UI.labor.einpassen(); UI.toast("Das Ticket steht wieder auf Anfang (Strg+Z holt deinen Stand zurück).", "info"); }},
      {text: "Zum Postfach", sym: "postfach", fn: () => UI.app.ansicht("postfach")});
    return UI.menue(r.right - 250, r.bottom + 4, [...kern, ...(kern.length ? ["-"] : []), ...eintraege], {titel: "Aktionen"});
  }

  /* ---------- Live-Prüfung (Einstieg und AP1) ---------- */
  function liveJetzt(){
    if (!S.inst) return;
    const r = Spiel.zieleLive(S.inst);
    const vorher = S.live;
    S.live = r;
    UI.labor.auftragNeu();
    if (!Spiel.regeln(S.inst).liveHaken) return;            /* AP2: Haken erst bei der Abnahme */
    if (vorher && r.neuOk.length) {
      for (const i of r.neuOk) { const li = document.querySelector(`.sp-ziele li[data-i="${i}"]`); li?.classList.add("frisch"); }
      UI.juice?.(document.querySelector(".am-ziele"), "haken", 700);
      UI.klang?.spielen("haken");
      if (r.alle) {
        if (!S.coach) UI.toast("Alle Ziele erfüllt – jetzt die Abnahme anfordern.", "ok", {id: "ziele", titel: "Geschafft"});   /* mit Coach sagt die Coach-Zeile das schon */
        if (S.coach && S.coach.schritt < 1) coachWeiter(1);
      } else UI.toast(`Ziel erfüllt: ${r.status[r.neuOk[0]].ziel.text}`, "ok", {id: "ziele", dauer: 2600});
    }
  }
  function livePlanen(){
    if (!S.inst) return;
    clearTimeout(S.liveTimer);
    S.liveTimer = setTimeout(liveJetzt, 400);
  }

  /* ---------- Hilfeleiter (Bento 2.5, Vertrag § 3.1: Diagnose-Assistent statt Werbeplakat) ----------
     Kopf: Mikrolabel + kompakte Stufenleiste (Zustände frei/gesperrt/an wie bisher). Inhalt als ruhige
     Bento-Inseln: „Nächste Diagnose" als eine hervorgehobene Zeile, Werkzeuge als Chips, Simulations-
     hinweis als leise Meta-Zeile, Stufe 3 als Zitatkarte. Bewusst KEINE `.sp-leise`-Klasse:
     editor.css:357 setzt `.lb-auftrag .sp-leise` auf 28 px/800 (belegter Befund „44-px-Grünslogan",
     gemessen am 30.10.2026) – der Hilfeleiter nutzt eigene, leise Klassen.
     Fuß: Label und Funktion der nächsten Sprosse bleiben; „Senior fragen · frei" ist der Hauptknopf. */
  function hilfePanel(inst, def, naechste){
    const stufe = inst.hilfeStufe || 0;
    const zeigen = S.hilfeAnsicht ?? stufe;
    const leiter = h("ol", {class: "sp-leiter", "aria-label": "Hilfestufen"}, Spiel.HILFE.slice(1).map(x => h("li", {class: (x.stufe <= stufe ? "frei" : "") + (x.stufe === zeigen ? " an" : "")},
      h("button", {type: "button", disabled: x.stufe > stufe, title: x.name + (x.kosten ? ` (−${x.kosten === 0.5 ? "½" : x.kosten} ★)` : " (frei)"),
        "aria-label": `Stufe ${x.stufe}: ${x.name}`, onclick: () => { S.hilfeAnsicht = x.stufe; UI.labor.auftragNeu(); }}, x.stufe),
      h("span", {}, x.name))));
    const inhalt = h("div", {class: "sp-hilfe-inhalt"});
    if (zeigen === 0) inhalt.append(h("div", {class: "sp-hilfe-block"},
      h("p", {class: "sp-hilfe-lead"}, "Die Hilfe beginnt kostenlos: Checkliste, Werkzeugtipp, eine Frage vom Senior. Erst danach kostet sie Sterne – und selbst die vorgeführte Lösung ist kein Scheitern.")));
    else inhalt.append(hilfeInhalt(inst, Spiel.hilfeInhalt(inst, zeigen)));
    const knopf = naechste ? h("button", {type: "button", class: "knopf" + (naechste.kosten ? "" : " primaer"), onclick: () => {
        const r = Spiel.hilfe(inst); S.hilfeAnsicht = r.stufe;
        UI.labor.auffrischen?.();                              /* AP1: ab Hilfestufe 2 erscheinen die „!“-Warnungen */
        if (r.stufe === 4 && r.bereich?.length) UI.labor.hervorheben(r.bereich, 6000);
        if (r.stufe === 6) S.demo = {i: 0, schritte: r.schritte};
        UI.labor.auftragNeu();
      }}, naechste.knopf, h("span", {class: "sp-hilfe-preis"}, naechste.kosten ? ` · −${naechste.kosten === 0.5 ? "½" : naechste.kosten} ★` : " · frei")) : null;
    return h("section", {class: "sp-hilfe"},
      h("div", {class: "sp-hilfe-kopf"},
        h("div", {class: "sp-hilfe-titel"},
          h("span", {class: "bn-kicker"}, "Hilfeleiter"),
          h("strong", {class: "sp-hilfe-name"}, zeigen === 0 ? "Diagnose-Assistent" : Spiel.HILFE[zeigen].name)),
        leiter),
      inhalt,
      h("div", {class: "sp-hilfe-fuss"}, knopf,
        h("button", {type: "button", class: "knopf geist", onclick: () => { S.hilfeOffen = false; UI.labor.auftragNeu(); }}, "Schließen")));
  }
  function hilfeInhalt(inst, r){
    switch (r.stufe) {
      case 1: return h("div", {class: "sp-hilfe-block"},
        h("p", {class: "sp-hilfe-meta"}, "Von unten nach oben – hak ab, was du geprüft hast:"),
        h("ul", {class: "sp-check"}, r.leiter.map(s => h("li", {}, h("label", {},
          h("input", {type: "checkbox", checked: s.erledigt, onchange: e => Spiel.leiterHaken(inst, s.id, e.target.checked)}),
          h("span", {}, h("b", {}, s.titel + ": "), s.frage, h("span", {class: "sp-check-werkzeug"}, "Werkzeug: " + s.werkzeug)))))));
      case 2: return h("div", {class: "sp-hilfe-block"},
        h("div", {class: "sp-naechste"},
          h("span", {class: "sp-naechste-label"}, "Nächste Diagnose"),
          h("p", {}, r.naechste || "Für diesen Auftrag gibt es keine Rechner-Diagnose – die Fehlersuche-Leiter (Stufe 1) führt weiter.")),
        h("ul", {class: "sp-hilfe-werkzeuge"}, r.werkzeuge.map(w => h("li", {}, UI.symbol("werkzeug", 14), h("span", {}, w)))),
        h("p", {class: "sp-hilfe-meta"}, UI.symbol("sim", 14), h("span", {}, r.simulation)));
      case 3: return h("div", {class: "sp-senior"},
        h("span", {class: "sp-hilfe-marke", "aria-hidden": "true"}, UI.symbol("senior", 20)),
        h("div", {class: "sp-senior-text"}, ...r.fragen.map(f => h("p", {}, "„" + f + "“")), h("span", {class: "sp-senior-quelle"}, "— der Senior")));
      case 4: return h("div", {class: "sp-hilfe-block"},
        h("p", {}, "Schau dir diese Stelle genauer an: ", h("b", {}, r.namen.join(", ") || "—")),
        h("button", {type: "button", class: "knopf klein", onclick: () => UI.labor.hervorheben(r.bereich, 5000)}, "Noch einmal zeigen"));
      case 5: return h("ul", {class: "sp-hilfe-hinweise"}, r.konkret.map(k => h("li", {}, UI.symbol("idee", 14), h("span", {}, k))));
      case 6: return demoAnsicht(inst, r);
    }
    return h("p", {class: "sp-hilfe-lead"}, r.name);
  }
  /* Lösung vorführen: Schritt für Schritt sichtbar, jeder Schritt über den Verlauf (rückgängig machbar) */
  function demoAnsicht(inst, r){
    const d = S.demo ||= {i: 0, schritte: r.schritte};
    const alle = d.schritte;
    const liste = h("ol", {class: "sp-demo"}, alle.map((s, i) => h("li", {class: i < d.i ? "fertig" : i === d.i ? "jetzt" : ""},
      h("div", {class: "sp-demo-kopf"}, h("b", {}, s.geraetName ? s.geraetName + ": " : ""), s.text),
      i === d.i && (s.art === "cli" || s.art === "terminal") ? h("pre", {class: "sp-demo-cli"}, s.zeilen.join("\n")) : null,
      i === d.i && s.art === "setzen" ? h("ul", {class: "sp-demo-felder"}, s.felder.map(f => h("li", {}, h("code", {}, f.pfad), " = ", h("b", {}, JSON.stringify(f.wert)),
        f.entspricht ? h("pre", {class: "sp-demo-cli"}, f.entspricht) : null))) : null)));
    const weiter = d.i < alle.length
      ? h("button", {type: "button", class: "knopf primaer", onclick: () => demoSchritt(inst)}, `Schritt ${d.i + 1} ausführen ▸`)
      : h("p", {class: "sp-ok"}, "✓ Alle Schritte ausgeführt. Jetzt „Abnahme anfordern“. Dieses Thema kommt als Wiederholung wieder – dann löst du es selbst.");
    return h("div", {class: "sp-hilfe-block"},
      h("p", {class: "sp-hilfe-meta"}, "Sieh zu, was passiert – jeder Schritt ist ein echter Konfigurationsschritt (Strg+Z macht ihn rückgängig)."),
      liste, weiter);
  }
  function demoSchritt(inst){
    const d = S.demo; if (!d) return;
    const s = d.schritte[d.i];
    if (s.geraet) { UI.labor.auswaehlen(s.geraet); UI.labor.hervorheben([{geraet: s.geraet}], 2400); }
    if (s.schritt && s.schritt.a) UI.labor.hervorheben([{geraet: s.schritt.a.geraet}, {geraet: s.schritt.b?.geraet}].filter(x => x.geraet), 2400);
    if (s.art === "terminal") UI.terminal.oeffnen(s.geraet, {eingabe: s.zeilen.join("\n"), notiz: "Aus der Vorführung übernommen."});
    else try { Spiel.vorfuehrenSchritt(inst, d.i); } catch (e) { UI.toast("Dieser Schritt ging nicht: " + e.message, "fehler"); return; }
    d.i++;
    UI.labor.auftragNeu();
  }

  /* ---------- Senior bietet Hilfe an (einmal je Ticket, nach 4 min ohne Fortschritt) ---------- */
  function seniorPlanen(){
    clearInterval(S.seniorTimer);
    S.seniorTimer = setInterval(() => {
      const inst = S.inst;
      if (!inst || !istTicketNetz() || UI.app.aktuell !== "labor" || !Spiel.seniorFaellig(inst)) return;
      Spiel.seniorAngeboten(inst);
      const satz = (DATEN.senior?.fehlerTrost || [])[inst.seed % Math.max(1, (DATEN.senior?.fehlerTrost || []).length)] || "Kleiner Tipp gefällig?";
      UI.toast(`„${satz}“ Magst du eine Frage von mir als Denkanstoß?`, "info", {titel: "Der Senior", dauer: 12000, id: "senior",
        aktion: {text: "Ja, gern", fn: () => { S.hilfeOffen = true; while ((inst.hilfeStufe || 0) < 3) Spiel.hilfe(inst); S.hilfeAnsicht = 3; UI.labor.auftragNeu(); UI.labor.auffrischen?.(); }}});
    }, 30000);
  }

  /* ---------- Abnahme und Ergebnis ---------- */
  async function abnahmeAnfordern(){
    const inst = S.inst; if (!inst || S.probe) return;
    const ab = Spiel.abnahme(inst);
    /* vor dem Abschluss lesen: danach ist die Laufzeit (Startnetz, Verlauf) der Instanz weg */
    const geaendert = ab.bestanden ? Spiel.geaenderteGeraete(inst) : [];
    const weg = ab.bestanden ? wegChips(inst) : null;
    if (!ab.bestanden) wegMerken(inst, {art: "abnahme", ok: false});
    const erg = Spiel.abschliessen(inst, ab);
    status();
    if (!erg.bestanden) { UI.klang?.spielen("nochnicht"); ergebnisZeigen(erg); return; }
    S.coach = null; ticketFertig();
    const form = Spiel.szeneForm(erg.inst);                 /* § 20 F4: eigene Probe je Form */
    const aufdecken = () => { if (UI.labor.fern) UI.labor.fernwartung(null); };   /* Fernwartung: jetzt zeigt sich das Netz, das man blind repariert hat */
    if (!form || form.art !== "fernwartung") aufdecken();
    UI.toast.zu?.("ziele");                                /* „Alle Ziele erfüllt – jetzt die Abnahme“ ist erledigt */
    const kd = kunde(erg.inst.kunde || erg.def.kunde);
    S.fertig = {titel: erg.def.titel, name: kd.name, symbol: kd.symbol, farbe: kd.farbe};
    UI.labor.werkzeug("auswahl");
    UI.labor.auftragNeu();
    erg.weg = weg;
    erg.wahl = Spiel.st.erledigt.length === 1;        /* nach dem ersten Auftrag: Postfach mit zwei Angeboten zur Wahl */
    if (S.mess) S.mess.erfolg ??= Math.round(performance.now());
    const k = kunde(erg.inst.kunde || erg.def.kunde);
    S.probe = true;
    try {
      await UI.szene.abspielen(Spiel.szene(erg.inst, ab), {geaendert, satz: erg.dank, kurz: ab.niveau !== "E", form, aufdecken,
        kunde: {name: k.ansprechpartner?.name || k.name, symbol: k.symbol, farbe: k.farbe}});
    } catch (e) { console.error("Funktionsprobe", e); }
    finally { S.probe = false; S.fertig = null; aufdecken(); }
    ergebnisZeigen(erg);
    for (const k of erg.karten || []) UI.ereignisse?.vormerken(k);   /* erste Stunde (Anruf, Weiterempfehlung) und Empfehlung: Karten, wenn das Ergebnis zu ist */
  }
  /* „Dein Weg“: was der Spieler getan hat – Diagnose (Ping), Eingriffe (Verlauf), Probe */
  function wegMerken(inst, eintrag){
    if (S.weg.iid !== inst.iid) S.weg = {iid: inst.iid, liste: []};
    S.weg.liste.push(eintrag);
    if (S.weg.liste.length > 40) S.weg.liste.shift();
  }
  function wegChips(inst){
    const eig = S.weg.iid === inst.iid ? S.weg.liste : [];
    const chips = [];
    const diag = eig.find(e => e.art === "ping" || e.art === "befehl");   /* erste Diagnose: Ping-Werkzeug oder Terminalbefehl */
    if (diag) chips.push({text: diag.text, ok: diag.ok});
    const fehl = eig.filter(e => e.art === "abnahme" && !e.ok).length;
    const eingriffe = (Spiel.verlaufVon(inst).liste || []).filter(t => !/verschoben|zurückgesetzt|Aufgeräumt/.test(t));
    for (const t of eingriffe.slice(-2)) chips.push({text: t.length > 46 ? t.slice(0, 45) + "…" : t, ok: null});
    if (eingriffe.length > 2) chips.splice(chips.length - 2, 0, {text: `+${eingriffe.length - 2} Schritte`, ok: null});
    chips.push({text: fehl ? `Probe ✓ im ${fehl + 1}. Versuch` : "Probe ✓", ok: true});
    return chips.slice(-4);
  }
  function ticketFertig(){
    clearInterval(S.seniorTimer); S.seniorTimer = null;
    S.inst = null; S.demo = null; S.live = null;
    S.mappe.offen = false; S.mappe.erstes = false; S.mappe.ausloeser = null; mappeUmgebung();
  }
  function overlay(inhalt, klasse = "", {aussenZu = false} = {}){
    const o = h("div", {class: "sp-overlay " + klasse, role: "dialog", "aria-modal": "true"}, h("div", {class: "sp-karte"}, inhalt));
    document.body.append(o);
    requestAnimationFrame(() => o.classList.add("da"));
    const zu = () => { o.classList.remove("da"); setTimeout(() => o.remove(), UI.zeit("dauer")); document.removeEventListener("keydown", esc); };
    const esc = e => { if (e.key === "Escape") zu(); };
    document.addEventListener("keydown", esc);
    if (aussenZu) o.addEventListener("click", e => { if (e.target === o) zu(); });
    return zu;
  }
  /* ---------- Ergebnis kopieren (Fahrplan 1.3/2.0, Schritt 0) ----------
     Den Klartext aus `src/spiel/ergebnis.js` in die Zwischenablage – Muster samt Toast: src/ui/hub.js:122-126.
     Der Text entsteht erst beim Klick: ein Fehler in `Spiel.ergebnisText` darf das Fenster nicht schon beim
     Aufbau umwerfen. Hier steht bewusst KEIN `zu()`: der Knopf soll das Fenster zum Lesen offen lassen.
     Der Knopfblock wird vor `const zu = overlay(...)` (:507) gebaut – ein `zu()` beim AUFBAU wäre ein Fehler;
     beim Klick ist `zu` längst gesetzt, genau das tut der Nachbar „Übersicht“ (gemessen in
     tests/ui-spiel-ergebnis.test.js). */
  async function ergebnisKopieren(inst, erg){
    const ok = await UI.kopieren(Spiel.ergebnisText(inst, erg));
    UI.toast(ok ? "Ergebnis kopiert – einfach einfügen." : "Kopieren ging nicht – markier den Text und kopier ihn selbst.", ok ? "ok" : "warn", {id: "kopieren", dauer: 3000});
  }
  function ergebnisZeigen(erg){
    const def = erg.def, k = kunde(erg.inst.kunde || def.kunde), niveau = erg.abnahme.niveau;
    if (!erg.bestanden) {
      const ab = erg.abnahme;
      const zu = overlay(h("div", {class: "sp-ergebnis nicht"},
        h("h2", {}, "Noch nicht ganz"),
        h("p", {class: "sp-leise"}, versuchText(erg.inst, niveau)),
        h("ul", {class: "sp-pruefliste"},
          ab.ergebnisse.map(e => h("li", {class: e.ok ? "ok" : "offen"}, h("span", {}, e.ok ? "✓" : "✗"), h("div", {},
            h("b", {}, e.ziel.text || e.ziel.typ),
            !e.ok && e.grund ? h("p", {}, Spiel.grundTitel(e.grund)) : !e.ok ? h("p", {}, e.text) : null,
            !e.ok && e.grund && niveau !== "AP2" ? UI.erklaeren(e.grund, niveau) : null))),
          ab.kollateral.map(r => h("li", {class: "offen"}, h("span", {}, "⚠"), h("div", {}, h("b", {}, `Kollateralschaden: ${r.vonName} erreicht ${r.nachName} nicht mehr`),
            h("p", {}, "Das ging vorher. Change-Management heißt: Nichts, was lief, darf kaputtgehen. " + Spiel.grundTitel(r.grund))))),
          ab.neustart.verlust && niveau === "AP2" ? h("li", {class: "offen"}, h("span", {}, UI.symbol("sicherung", 16)), h("div", {}, h("b", {}, "Nach dem Neustart war deine Änderung weg"),
            h("p", {}, "Die Abnahme hat " + ab.neustart.geraete.map(g => g.name).join(", ") + " neu gestartet. Ungespeichertes steht nur im RAM – „copy running-config startup-config“ schreibt es ins NVRAM."))) : null),
        h("div", {class: "sp-knoepfe"},
          h("button", {type: "button", class: "knopf primaer", onclick: () => zu()}, "Zurück ins Labor"),
          h("button", {type: "button", class: "knopf", onclick: () => { zu(); S.hilfeOffen = true; UI.labor.auftragNeu(); }}, UI.symbol("hilfe", 16), " Hilfe")),
        lehrtextKnoepfe(def, niveau).length ? h("p", {class: "sp-leise sp-lehrtexte"}, "Zum Nachlesen: ", lehrtextKnoepfe(def, niveau)) : null));
      return;
    }
    /* Nachbesprechung in höchstens drei Blöcken (Design – Spielspaß 2.0, Hebel 1):
       ① Sterne + Lohn (Abzüge, Abzeichen, Tagesziel, Fertigkeit nur als kurze Zeile, wenn es sie gibt) · ② Dein Weg · ③ Merke */
    /* Station 3 (Bau P7): einmaliges Abschluss-Feedback nach dem ersten bestandenen Auftrag.
       `abschlussZeigen()` setzt das Kennzeichen in `st.einstieg` und liefert genau beim ersten Mal
       true – ein alter Spielstand hat keine Begrüßung gesehen und bekommt hier nie etwas zu sehen. */
    const einstiegSchluss = Spiel.einstieg.abschlussZeigen();
    const sterne = erg.sterne;
    const tagStand = erg.inst.quelle !== "pruefung" ? Spiel.tag.heute() : null;
    const feierabend = !!(tagStand && tagStand.fertig && !tagStand.abschlussGezeigt);
    if (feierabend) Spiel.tag.abschlussGesehen();
    const sternEl = h("div", {class: "sp-sterne" + (UI.bewegung() === "voll" ? " jc-sterne" : ""), "aria-label": `${sterne} von 5 Sternen`}, [1, 2, 3, 4, 5].map(i => h("span", {class: i <= sterne ? "voll" : i - 0.5 <= sterne ? "halb" : "leer", style: {"--i": i}}, "★")));
    const euroEl = h("b", {class: "sp-geld"}, "+0,00 €");
    Spiel.abzeichen.pruefen();
    const abz = Spiel.abzeichen.abholen();
    const besser = (erg.lernen || []).find(l => l.nachher > l.vorher);
    /* task-119: Die Abzugs-Zeile zieht in den Hero (Sterne-Bereich); alles andere bleibt Inhalt. */
    const abzuege = erg.abnahme.abzuege || [];
    const abzugZeile = abzuege.length ? h("p", {class: "sp-zeile leise"}, abzuege.map(a => `−${a.sterne === 0.5 ? "½" : a.sterne} ★ ${a.text}`).join(" · ")) : null;
    const zeilen = [
      abz.length ? h("p", {class: "sp-zeile"}, UI.symbol("medaille", 16), " ", h("b", {}, abz.length === 1 ? "Neues Abzeichen: " : "Neue Abzeichen: "), abz.map(a => `${a.sym} ${a.titel}`).join(" · ")) : null,
      besser ? h("p", {class: "sp-zeile"}, UI.symbol("tendenz", 16), " ", h("b", {}, besser.name + ": "), `Stufe ${besser.vorher} → ${besser.nachher}`) : null,
      feierabend ? feierabendZeile() : null,
      erg.woche ? h("p", {class: "sp-zeile"}, UI.symbol("ziel", 16), " ", h("b", {}, "Wochenziel geschafft: "), `${erg.woche.text} · +${erg.woche.ruf} Ruf`) : null,
      ...dexZeilen(erg.dex),
      erg.raetsel ? h("p", {class: "sp-zeile sp-raetsel"}, UI.symbol("raetsel", 16), " ", h("b", {}, `Tagesrätsel #${erg.raetsel.nr}: `), h("span", {class: "sp-raetsel-zeile"}, erg.raetsel.zeile), " ",
        h("button", {type: "button", class: "knopf klein", onclick: () => UI.hub.kopieren(Spiel.raetsel.teilen(), "Ergebnis kopiert – einfach einfügen.")}, "Ergebnis kopieren")) : null,
    ].filter(Boolean);
    const merke = merkeText(def, erg.abnahme.niveau);
    const skill = (def.skills || [])[0];
    /* Die Einzeiler-Zusammenfassung als sichtbare Zeile. Grund (Befund der Gegenprüfung task-14):
       `Spiel.ergebnisKurz` hatte KEINEN Aufrufer im Programm — nur Tests, also „Wirkung vor Grün“
       verletzt. Gelesen wird beim Aufbau; liefert sie nichts, bleibt die Zeile weg und das Fenster
       steht trotzdem. Der Text verrät nichts, was hier nicht ohnehin steht: Titel, Kunde, Sterne,
       Dauer und Hilfestufe sind die Zahlen dieses Auftrags, keine Lösung. */
    const kurz = typeof Spiel.ergebnisKurz === "function" ? String(Spiel.ergebnisKurz(erg.inst, erg) || "").trim() : "";
    const weiterKnopf = erg.wahl
      ? h("button", {type: "button", class: "knopf primaer", onclick: () => { zu(); UI.sandbox?.laden?.(); UI.app.ansicht("postfach"); }}, "Nächsten Auftrag wählen ▸")
      : erg.naechstes ? h("button", {type: "button", class: "knopf primaer", onclick: () => { zu(); oeffnen(erg.naechstes); }}, "Nächstes Ticket ▸") : null;
    /* Bento-Raster (task-119): gleiche Texte, Anker und Knöpfe — nur als Karten wie im Dashboard. */
    const lohnZusatz = erg.lohn.tempo || erg.lohn.verdacht || erg.lohn.variante
      ? "inkl. " + [erg.lohn.tempo ? `${fmtEuro(erg.lohn.tempo)} Tempo-Bonus` : "",
        erg.lohn.verdacht ? `${fmtEuro(erg.lohn.verdacht)} für den Verdacht` : "",
        erg.lohn.variante ? `${erg.lohn.variante.id === "sauber" ? "Aufschlag für saubere Arbeit" : "Abschlag fürs Provisorium"} (× ${String(erg.lohn.variante.faktor).replace(".", ",")})` : ""].filter(Boolean).join(" und ")
      : null;
    const hilfen = Array.isArray(erg.inst.hilfen) ? erg.inst.hilfen : [];
    const hilfeStufe = Math.max(0, +erg.inst.hilfeStufe || 0, ...hilfen.map(x => +x?.stufe || 0));
    const dauerKpi = typeof Spiel.ergebnis?.dauer === "function" && Number(erg.inst.zeitMs) > 0 ? Spiel.ergebnis.dauer(erg.inst.zeitMs) : "–";
    const niveauName = (Spiel.NIVEAU_NAME && Spiel.NIVEAU_NAME[niveau]) || niveau;
    const kpi = (wert, label) => h("div", {class: "erg-kpi"}, h("b", {}, wert), h("span", {class: "bn-kicker"}, label));
    const ergTitel = sterne >= 4.5 ? "Hervorragend gelöst!" : sterne >= 3 ? "Gelöst!" : "Gelöst – mit Hilfe";
    /* P2-Dedup (ERG-BENTO Runde 2): Der Hero nennt nur den Kunden; Dauer/Hilfe/Abnahme stehen
       ausschließlich in der Kennzahlen-Karte (die kurz-Zeile bleibt als eigene Zeile darunter). */
    const metaHero = k.name;
    const lehrtexte = lehrtextKnoepfe(def, niveau);
    const merkeKarte = (merke || lehrtexte.length) ? h("section", {class: "bn-k sp-merke erg-merke"},
      merke ? h("h3", {}, "Merke") : null,
      merke ? h("p", {}, merke) : null,
      merke ? h("div", {class: "sp-merke-fuss"},
        def.quelle ? h("small", {class: "sp-leise"}, "Quelle: " + def.quelle) : null,
        typeof UI.wiki?.oeffnen === "function" && skill ? h("button", {type: "button", class: "knopf geist klein", onclick: () => { zu(); UI.wiki.oeffnen(skill); }}, UI.symbol("dex", 16), " Nachlesen") : null) : null,
      lehrtexte.length ? h("div", {class: "sp-lehrtexte"}, h("h3", {}, "Zum Nachlesen"), h("div", {class: "sp-merke-fuss"}, lehrtexte)) : null) : null;
    const zu = overlay(h("div", {class: "sp-ergebnis erg-bento"},
      h("div", {class: "bn-raster erg-raster"},
        h("section", {class: "bn-k akzent erg-hero"},
          h("div", {class: "sp-erg-kopf erg-hero-text"},
            marke(k.name, k.farbe, {gross: true}),
            h("div", {},
              h("span", {class: "bn-kicker"}, "ABNAHME · KUNDE"),
              h("h2", {}, ergTitel),
              h("p", {class: "bn-lead"}, def.titel),
              h("p", {class: "bn-meta"}, metaHero),
              kurz ? h("p", {class: "bn-meta"}, kurz) : null)),
          h("div", {class: "erg-hero-seite"}, sternEl, abzugZeile)),
        h("section", {class: "bn-k geld erg-lohn"},
          h("div", {class: "sp-lohn"},
            h("div", {class: "bn-wert"}, euroEl),
            lohnZusatz ? h("p", {class: "bn-meta"}, lohnZusatz) : null)),
        h("section", {class: "bn-k iris erg-ruf"},
          h("div", {class: "bn-wert"}, h("b", {class: "sp-ruf"}, `+${erg.ruf} Ruf`)),
          h("p", {class: "bn-meta"}, "Ansehen")),
        h("section", {class: "bn-k flach erg-kenn"},
          h("div", {class: "erg-kpis"},
            kpi(dauerKpi, "Dauer"), kpi(hilfeStufe ? "Stufe " + hilfeStufe : "keine", "Hilfe"), kpi(niveauName, "Abnahme"))),
        h("section", {class: "bn-k sp-weg erg-weg"},
          h("h3", {}, "Dein Weg"),
          erg.weg && erg.weg.length ? h("ol", {class: "sp-weg-chips"}, erg.weg.map((c, i) => [i ? h("li", {class: "sp-pfeil", "aria-hidden": "true"}, "→") : null,
            h("li", {class: c.ok === true ? "ok" : c.ok === false ? "nicht" : ""}, c.text)])) : null,
          h("div", {class: "erg-weg-notizen"},
            erg.verdacht && erg.verdacht.gesetzt ? h("p", {class: "sp-verdacht " + (erg.verdacht.treffer || "daneben")},
              UI.symbol({voll: "ziel", ursache: "suche", schicht: "suche"}[erg.verdacht.treffer] || "idee", 15), " ", erg.verdacht.text) : null,
            erg.hotline ? h("p", {class: "sp-hotline"}, UI.symbol("telefon", 15), " " + erg.hotline.text) : null,
            akteZeile(erg),
            erg.schuld ? h("p", {class: "sp-schuld"}, UI.symbol("provisorium", 15), ` Provisorium: In etwa drei Aufträgen meldet sich ${kunde(erg.inst.kunde || def.kunde).ansprechpartner?.name || "der Kunde"} wieder – die Änderung ist nicht gesichert.`) : null)),
        merkeKarte,
        zeilen.length ? h("section", {class: "bn-k flach erg-mehr"}, h("div", {}, zeilen)) : null,
        einstiegSchluss ? h("section", {class: "bn-k flach sp-einstieg sp-einstieg-schluss erg-einstieg"},
          h("h3", {}, "Willkommen angekommen"),
          h("p", {}, Spiel.EINSTIEG_TEXTE.SCHLUSS_LERNEN),
          h("p", {}, Spiel.EINSTIEG_TEXTE.SCHLUSS_WEG)) : null),
      h("div", {class: "sp-knoepfe erg-fuss"},
        weiterKnopf,
        h("button", {type: "button", class: "knopf geist", onclick: () => ergebnisKopieren(erg.inst, erg)}, "Ergebnis kopieren"),
        h("button", {type: "button", class: "knopf" + (weiterKnopf ? "" : " primaer"), onclick: () => { zu(); UI.sandbox?.laden?.(); UI.app.ansicht("heute"); }}, "Übersicht"),
        feierabend ? h("button", {type: "button", class: "knopf", title: "Das Programm wird zur kleinen Leiste am Bildschirmrand", onclick: () => { zu(); UI.modus("leiste"); }}, UI.symbol("feierabend", 16), " Feierabend: zur Leiste") : null)),
      "erfolg erg-bento");
    zaehlen(euroEl, erg.euro);
    UI.klang?.spielen("sterne");
  }
  /* Fehlerdex: neu gesehen/verstanden und Ehrentitel – je eine kurze Zeile (Abschluss, also kein Verraten) */
  function dexZeilen(dex){
    if (!dex) return [];
    const neu = dex.neu || [], z = [];
    if (neu.length) z.push(h("p", {class: "sp-zeile"}, UI.symbol("dex", 16), " ", h("b", {}, "Fehlerdex: "),
      neu.map(d => `${d.titel} – ${d.zustand === "verstanden" ? "verstanden" : "gesehen"}`).join(" · ")));
    if ((dex.titel || []).length) z.push(h("p", {class: "sp-zeile"}, UI.symbol("trophae", 16), " ", h("b", {}, "Ehrentitel: "), dex.titel.join(" · ")));
    return z;
  }
  /* Tagesziel: eine Zeile mit offenem Faden für morgen (Folgeauftrag, Notfall, Kapitel … – Spiel.hub.ausblick; die Bilanz steht im Hub) */
  function feierabendZeile(){
    const b = Spiel.tag.bilanz();
    return h("p", {class: "sp-zeile"}, UI.symbol("feier", 16), " ", h("b", {}, "Tagesziel geschafft"), ` – ${b.tickets} Aufträge heute · ${Spiel.hub.ausblick()}`);
  }
  /* Lehrtext-Consumer (Architektur § 17.4): DATEN.lehrtexte traegt neben den 34 Sim-Code-Texten auch
     12 Skill-Texte unter der Fertigkeits-id (z. B. "lab.switch"). Diese Texte werden sonst nirgends
     gelesen — hier im Ergebnis erscheinen sie als "Zum Nachlesen" (Wirkung vor Gruen, Lead-Integration). */
  function lehrtextKnoepfe(def, niveau){
    if (niveau === "AP2") return [];                 /* Pruefungsstrenge: keine Erklaerung im AP2-Ergebnis */
    const skills = [...new Set(def.skills || [])];
    return skills.map(id => {
      const name = (DATEN.skills || []).find(s => s.id === id)?.name || id;
      return UI.erklaeren(id, niveau, "Lehrtext: " + name);
    }).filter(Boolean);
  }
  /* Merke: Einstieg erklärt (bis drei Sätze), AP1/AP2 bekommen nur die Regel – den letzten Satz der Erklärung */
  function merkeText(def, niveau){
    const saetze = String(def.erklaerung || "").split(/(?<=[.!?])\s+(?=[A-ZÄÖÜ„])/).map(s => s.trim()).filter(Boolean);
    if (!saetze.length) return "";
    return niveau === "E" ? saetze.slice(0, 3).join(" ") : saetze[saetze.length - 1];
  }
  /* Stufenregeln: Einstieg probiert frei; AP1/AP2 zählen den ersten Versuch wie in der Prüfung */
  function versuchText(inst, niveau){
    const abzug = Spiel.regeln(inst).versuchAbzug;
    if (!abzug) return "Die Abnahme hat nachgemessen. Kein Abzug – du kannst weiterarbeiten.";
    return `Die Abnahme hat nachgemessen. Jetzt kein Abzug – die bestandene Abnahme kostet dann ${abzug === 0.5 ? "½ Stern" : "1 Stern"} (${niveau}: Der erste Versuch zählt wie in der Prüfung). Prüf vorher selbst nach.`;
  }
  function zaehlen(el, ziel){
    if (UI.bewegung() !== "voll") { el.textContent = `+${fmtEuro(ziel)}`; return; }
    const t0 = performance.now(), dauer = UI.zeit("zaehler");
    const f = t => { const p = Math.min(1, (t - t0) / dauer); el.textContent = `+${fmtEuro(ziel * (1 - Math.pow(1 - p, 3)))}`; if (p < 1) requestAnimationFrame(f); };
    requestAnimationFrame(f);
  }

  /* ---------- Postfach (Bento 2.5, Vertrag § 3.1: Posteingang eines IT-Dienstleisters) ----------
     Kopf: Mikrolabel, Titel, Kontextsatz, rechts eine Zeile echter Kennzahlen (offene Aufträge,
     ungelesen, Bereitschaft fällig, Stufe – alle aus Spiel.*). Hauptbento zweispaltig: Liste
     (400–440 px) und Leser; unter 900 px öffnet die Zeile den vorhandenen Blatt-Leser von unten.
     Kunden-Emoji aus DATEN wird durch das Monogramm ersetzt (UI.bento.monogramm; fehlt der Baustein,
     entsteht dieselbe Marke aus den Initialen – so bleibt der UI-Prüfstand ohne bento.js lauffähig). */
  function initialenVon(name){
    const stumm = /^(der|die|das|und|&)$/i;
    const worte = String(name || "").replace(/[^\p{L}\p{N} .&/-]/gu, " ").split(/[\s/&.-]+/).filter(Boolean);
    const gut = worte.filter(w => !stumm.test(w));
    const quelle = gut.length ? gut : worte;
    return (quelle.slice(0, 2).map(w => w[0]).join("") || "?").toUpperCase();
  }
  function marke(name, farbe, {gross = false, klein = false} = {}){
    if (UI.bento && typeof UI.bento.monogramm === "function") return UI.bento.monogramm(name, {farbe: farbe || "--accent", gross, klein});
    const el = h("span", {class: "bn-marke" + (gross ? " gross" : klein ? " klein" : ""), style: {"--bn-f": `var(${farbe || "--accent"})`}, "aria-hidden": "true"});
    el.textContent = initialenVon(name);
    return el;
  }
  function seniorMarke(gross){
    return h("span", {class: "bn-marke" + (gross ? " gross" : ""), style: {"--bn-f": "var(--accent)"}, "aria-hidden": "true"}, UI.symbol("senior", gross ? 24 : 18));
  }
  /* Auftragsform als kleine Marke (Symbol + Wort), E1 */
  function formChip(def){
    const form = Spiel.formVon(def), F = Spiel.FORMEN[form] || Spiel.FORMEN.stoerung;
    return h("span", {class: "sp-chip form form-" + form, title: F.text}, F.titel);
  }
  /* Zustand einer Auftragszeile – nur echte Werte der Instanz (neu/angerissen/eilig/klingelt) */
  function mailZustand(inst, frist, klingelt, an){
    if (klingelt) return h("span", {class: "sp-chip klingelt", title: "Der Kunde ist am Telefon"}, UI.symbol("telefon", 13), " klingelt");
    if (frist != null && frist < 15) return h("span", {class: "sp-chip eilig", title: frist <= 0 ? "Die Frist ist abgelaufen" : `Noch ${frist} min Zeit`}, frist <= 0 ? "überfällig" : "eilig");
    if (!an && !inst.gelesen) return h("span", {class: "sp-chip neu"}, "neu");
    if (inst.geoeffnet) return h("span", {class: "sp-chip angerissen"}, "angerissen");
    return null;
  }
  function postfachAnsicht(c){
    const st = Spiel.st;
    const liste = Spiel.postfach(), post = Spiel.post.liste();
    const gibt = id => liste.some(i => i.iid === id) || post.some(n => n.id === id);
    const aktiv = S.postfachWahl && gibt(S.postfachWahl) ? S.postfachWahl : (liste[0] ? liste[0].iid : post[0] ? post[0].id : null);
    S.postfachWahl = aktiv;
    /* Punkt 5 (Theme-Prüfung): KPI „ungelesen" erst zählen, nachdem der automatisch gewählte
       Eintrag als gelesen verbucht ist – sonst zeigt der Kopf eine veraltete Zahl, bis die
       Ansicht neu aufgebaut wird. `leserZeigen`/`postLesen` erkennen den Stand danach und
       verbuchen nicht doppelt. */
    if (aktiv && !String(aktiv).startsWith("post-")) {
      const a = Spiel.instanz(aktiv);
      if (a && !a.gelesen) { Spiel.alsGelesen(a.iid); status(); }
    } else if (aktiv) {
      const a = Spiel.post.von(aktiv);
      if (a && !a.gelesen) { Spiel.post.gelesen(a.id); status(); }
    }
    const leser = h("div", {class: "sp-leser"});
    const waehlen = id => { S.postfachWahl = id; postfachAnsicht(c); if (schmal()) blattZeigen(c, id); };
    const karten = liste.map(inst => mailKarte(inst, inst.iid === aktiv, () => waehlen(inst.iid)));
    if (post.length) karten.push(h("div", {class: "sp-pf-trenner", role: "presentation"}, "Nachrichten"),
      ...post.map(n => postKarte(n, n.id === aktiv, () => waehlen(n.id))));
    let bereitschaft = 0;
    try { bereitschaft = Spiel.tag && Spiel.tag.heute ? Spiel.tag.heute().faellig.length : 0; } catch (e) { bereitschaft = 0; }
    const ungelesen = Spiel.ungelesen();
    const kontext = liste.length === Spiel.POSTFACH_WAHL && st.erledigt.length === 1
      ? "Zwei Angebote zur Wahl – Lohn, Zeit und Thema unterscheiden sich."
      : liste.length ? "Angebote, Aufträge und Nachrichten deiner Kunden. Was zuerst dran ist, steht oben."
      : "Dein Posteingang ist leer.";
    const kopf = h("header", {class: "sp-pf-kopf"},
      h("div", {class: "sp-pf-titel"},
        h("span", {class: "bn-kicker"}, "Postfach · Auftragseingang"),
        h("h2", {}, "Postfach"),
        h("p", {class: "sp-pf-kontext"}, kontext)),
      h("div", {class: "sp-pf-kennzahlen"},
        h("span", {class: "sp-kennzahl", title: "Offene Aufträge im Postfach"}, h("b", {}, String(liste.length)), h("span", {}, liste.length === 1 ? "offener Auftrag" : "offene Aufträge")),
        h("span", {class: "sp-kennzahl" + (ungelesen ? " neu" : ""), title: "Ungelesene Aufträge und Nachrichten"}, h("b", {}, String(ungelesen)), h("span", {}, "ungelesen")),
        h("span", {class: "sp-kennzahl" + (bereitschaft ? " neu" : ""), title: "Fällige Wiederholungen für den Bereitschaftsdienst"}, h("b", {}, String(bereitschaft)), h("span", {}, "Bereitschaft fällig")),
        h("span", {class: "sp-kennzahl", title: "Karriere-Stufe"}, h("b", {}, String(st.stufe)), h("span", {}, "Stufe"))),
      h("div", {class: "sp-pf-aktionen"},
        UI.tag?.karte ? UI.tag.karte() : null,
        h("button", {type: "button", class: "knopf", onclick: () => { UI.sandbox.laden(); UI.app.ansicht("labor"); }, title: "Ohne Auftrag frei ausprobieren"}, UI.symbol("test", 16), " Freies Labor")));
    const links = h("div", {class: "sp-pf-liste", role: "list"}, karten.length ? karten : h("div", {class: "sp-leer"},
      h("p", {}, "Keine offenen Aufträge. Gönn dir eine Pause – oder hol dir neue Arbeit."),
      h("button", {type: "button", class: "knopf primaer", onclick: () => { Spiel.nachschub(); status(); postfachAnsicht(c); }}, "Neuen Auftrag holen")));
    c.replaceChildren(h("div", {class: "sp-postfach"}, kopf, h("div", {class: "sp-pf-teile"}, links, leser)));
    if (aktiv && String(aktiv).startsWith("post-")) postLesen(leser, Spiel.post.von(aktiv), c);
    else if (aktiv) leserZeigen(leser, Spiel.instanz(aktiv));
    else leser.append(h("div", {class: "sp-leser-leer"}, h("p", {}, "Wähle links einen Auftrag oder eine Nachricht.")));
  }
  /* Postfach schmal (< 900 px, Design § 20 F1): Der Leser hat neben der Liste keinen Platz – die Karte öffnet ihn
     als Blatt von unten, mit „Annehmen“. Esc, Klick daneben oder der Griff schließen es. */
  const schmal = () => typeof matchMedia !== "undefined" && matchMedia("(max-width: 900px)").matches;
  function blattZeigen(c, id){
    const el = h("div", {class: "sp-leser sp-blatt-leser"});
    let zu = null;
    const schliessen = () => zu && zu();
    if (String(id).startsWith("post-")) postLesen(el, Spiel.post.von(id), c, schliessen);
    else leserZeigen(el, Spiel.instanz(id), schliessen);
    zu = overlay(h("div", {class: "sp-blatt"},
      h("button", {type: "button", class: "sp-blatt-griff", title: "Zurück zur Liste", "aria-label": "Zurück zur Liste", onclick: schliessen}), el), "blatt", {aussenZu: true});
  }
  /* Kundenpost: Nachricht ohne Auftrag (Lob vom Kunden oder Notiz vom Senior) – dieselbe ruhige
     Zeilenform wie ein Auftrag, ohne Betreff: Absender, eine Vorschauzeile, eine Marke. */
  function postAbsender(n){
    if (n.art === "senior") return {name: "Der Senior", person: "Notiz", farbe: "--accent", senior: true};
    const k = kunde(n.kunde);
    return {name: k.name, person: [k.ansprechpartner?.name, k.ansprechpartner?.rolle].filter(Boolean).join(", "), farbe: k.farbe || "--accent", senior: false};
  }
  function postKarte(n, an, wahl){
    const a = postAbsender(n), text = String(n.text).replace(/\s+/g, " ").trim();
    const roh = !an && !n.gelesen;
    return h("button", {type: "button", role: "listitem", class: "sp-mail sp-post" + (an ? " an" : "") + (roh ? " neu" : ""), style: {"--k": `var(${a.farbe})`}, onclick: wahl},
      a.senior ? seniorMarke(false) : marke(a.name, a.farbe),
      h("span", {class: "sp-mail-text"},
        h("span", {class: "sp-mail-kopf"},
          h("span", {class: "sp-mail-name"}, a.name),
          h("span", {class: "sp-mail-person"}, a.person)),
        h("span", {class: "sp-mail-vorschau"}, text),
        h("span", {class: "sp-chips"}, h("span", {class: "sp-chip"}, n.art === "senior" ? "Notiz" : "Nachricht"))));
  }
  function postLesen(el, n, c, schliessen){
    if (!n) return;
    if (!n.gelesen) { Spiel.post.gelesen(n.id); status(); }
    const a = postAbsender(n);
    el.replaceChildren(h("article", {class: "sp-brief", style: {"--k": `var(${a.farbe})`}},
      h("header", {class: "sp-brief-kopf"},
        a.senior ? seniorMarke(true) : marke(a.name, a.farbe, {gross: true}),
        h("div", {class: "sp-brief-absender"},
          h("span", {class: "sp-brief-firma"}, a.name),
          h("span", {class: "sp-brief-person"}, a.person))),
      h("h2", {class: "sp-brief-titel"}, a.senior ? "Notiz vom Senior" : "Nachricht vom Kunden"),
      h("div", {class: "sp-brief-text"}, absaetze(n.text)),
      h("div", {class: "sp-knoepfe"},
        n.art === "senior" ? h("button", {type: "button", class: "knopf", onclick: () => { schliessen?.(); UI.app.ansicht("kunden"); }}, "Zu den Kunden") : null,
        h("button", {type: "button", class: "knopf geist", onclick: () => { schliessen?.(); Spiel.post.ablegen(n.id); S.postfachWahl = null; postfachAnsicht(c); }}, "Ablegen"),
        schliessen ? h("button", {type: "button", class: "knopf geist", onclick: () => schliessen()}, "Später") : null)));
  }
  function mailKarte(inst, an, wahl){
    const def = Spiel.defVon(inst), k = kunde(inst.kunde || def.kunde), ap = k.ansprechpartner || {};
    const frist = inst.frist ? Math.round((inst.frist - jetzt()) / 60000) : null;
    const klingelt = !!inst.klingelt && !inst.geoeffnet;
    const roh = !an && !inst.gelesen;
    return h("button", {type: "button", role: "listitem", class: "sp-mail" + (an ? " an" : "") + (roh ? " neu" : "") + (frist != null && frist < 15 ? " eilig" : "") + (klingelt ? " klingelt" : ""),
      style: {"--k": `var(${k.farbe || "--accent"})`}, onclick: wahl},
      marke(k.name, k.farbe),
      h("span", {class: "sp-mail-text"},
        h("span", {class: "sp-mail-kopf"},
          h("span", {class: "sp-mail-name"}, k.name),
          h("span", {class: "sp-mail-person"}, [ap.name, ap.rolle].filter(Boolean).join(", "))),
        h("b", {class: "sp-mail-betreff"}, def.titel),
        h("span", {class: "sp-mail-vorschau"}, String(def.briefing || "").replace(/\s+/g, " ")),
        h("span", {class: "sp-chips"}, formChip(def),
          h("span", {class: "sp-chip"}, `~${Spiel.minuten(def)} min`),
          h("span", {class: "sp-chip geld"}, fmtEuro((def.lohn || {}).euro || 0)),
          mailZustand(inst, frist, klingelt, an))));
  }
  /* Kundenkontext im Brief (Bento 2.5 § 3.1): füllt die Fläche unter den Datenkacheln mit echten
     Werten aus Spiel.* und DATEN – Branche, Vertragsstand, letzter Auftrag, „Kunde seit“. Nichts
     davon ist erfunden; fehlt ein Wert, fällt die Zeile weg. */
  function kundenkontext(k){
    const roh = (DATEN.kunden || {})[k.id] || {};
    const zeilen = [];
    if (roh.branche) zeilen.push(["Branche", roh.branche]);
    const hat = !!(Spiel.karriere && typeof Spiel.karriere.hatVertrag === "function" && Spiel.karriere.hatVertrag(k.id));
    const eph = +((roh.vertrag || {}).euroProStunde || 0);
    zeilen.push(["Vertrag", hat ? `Wartungsvertrag${eph ? " · " + fmtEuro(eph) + "/h" : ""}` : "kein Wartungsvertrag"]);
    const stk = (Spiel.st.kunden || {})[k.id] || {};
    if (stk.seit) zeilen.push(["Kunde seit", datumDe(stk.seit)]);
    let letzte = null;
    for (const e of (Spiel.st.erledigt || [])) if (e && e.kunde === k.id) letzte = e;
    if (letzte) {
      let titel = "Auftrag";
      try { const d = Spiel.ticketDef ? Spiel.ticketDef(letzte.id) : null; if (d && d.titel) titel = d.titel; } catch (e) { /* Titel bleibt allgemein */ }
      zeilen.push(["Zuletzt", `${titel} · ${sterneText(+letzte.sterne || 0)}${letzte.tag ? " · " + datumDe(letzte.tag) : ""}`]);
    } else zeilen.push(["Zuletzt", "noch kein Auftrag bei diesem Kunden"]);
    return h("div", {class: "sp-brief-kundenkontext"},
      h("strong", {}, "Kundenkontext"),
      ...zeilen.map(([label, wert]) => h("p", {class: "sp-brief-kontextzeile"}, h("small", {}, label), h("span", {}, wert))));
  }
  function leserZeigen(el, inst, schliessen){
    if (!inst) return;
    const def = Spiel.defVon(inst), k = kunde(inst.kunde || def.kunde), ap = k.ansprechpartner || {};
    if (!inst.gelesen) { Spiel.alsGelesen(inst.iid); status(); }
    const angefangen = !!inst.geoeffnet;
    const form = Spiel.FORMEN[Spiel.formVon(def)] || Spiel.FORMEN.stoerung;
    el.replaceChildren(h("article", {class: "sp-brief", style: {"--k": `var(${k.farbe || "--accent"})`}},
      h("header", {class: "sp-brief-kopf"},
        marke(k.name, k.farbe, {gross: true}),
        h("div", {class: "sp-brief-absender"},
          h("span", {class: "sp-brief-firma"}, k.name),
          h("span", {class: "sp-brief-person"}, [ap.name, ap.rolle].filter(Boolean).join(", ")))),
      h("h2", {class: "sp-brief-titel"}, def.titel),
      h("div", {class: "sp-brief-text"}, absaetze(def.briefing)),
      h("div", {class: "sp-brief-info"},
        h("div", {}, h("small", {}, "Kunde"), h("p", {}, k.name)),
        h("div", {}, h("small", {}, "Form"), h("p", {}, form.titel)),
        h("div", {}, h("small", {}, "Dauer"), h("p", {}, `~${Spiel.minuten(def)} min`)),
        h("div", {}, h("small", {}, "Lohn"), h("p", {}, `${fmtEuro((def.lohn || {}).euro || 0)} · ${(def.lohn || {}).ruf || 0} Ruf`))),
      kundenkontext(k),
      h("div", {class: "sp-brief-ziele"},
        h("strong", {}, "Ziele"),
        h("ul", {}, (def.ziele || []).map(z => h("li", {}, h("span", {class: "sp-haken", "aria-hidden": "true"}, "○"), h("span", {}, z.text || z.typ))))),
      h("div", {class: "sp-knoepfe"},
        h("button", {type: "button", class: "knopf primaer", onclick: () => { schliessen?.(); oeffnen(inst.iid); }}, angefangen ? "Weiterarbeiten ▸" : "Auftrag annehmen ▸"),
        schliessen ? h("button", {type: "button", class: "knopf geist", onclick: () => schliessen()}, "Später") : null)));
  }

  /* ---------- Sanftes Onboarding (Bau P7), Station 1: die Begrüßungskarte ----------
     Sie sitzt IN der Auftragszeile (`.sp-auftrag`), nicht als Overlay über der Fläche. Grund:
     `tools/rauch.py` zieht das erste Kabel mit echten Mausereignissen über Bildschirmkoordinaten
     und prüft, dass in der Mitte JEDES Geräts das Gerät selbst liegt – ein Overlay über der
     Zeichenfläche würde diese erste Handlung abfangen. Die Karte führt sie stattdessen: das
     Kabel-Werkzeug ist schon gewählt (s. oeffnen), und der Weg steht als Text daneben. */
  function einstiegKarte(){
    const T = Spiel.EINSTIEG_TEXTE;
    const wahl = weg => {
      Spiel.einstieg.waehlen(weg);
      S.einstiegStart = false;
      if (weg === "umsehen") { UI.app.ansicht("heute"); return; }        /* im Hub umsehen; der Auftrag bleibt offen */
      if (!S.coach && S.inst && Spiel.defVon(S.inst).id === Spiel.EINSTIEG_TICKET) coachStart();   /* Station 2 */
      UI.labor.auftragNeu();
    };
    return h("div", {class: "sp-einstieg sp-einstieg-start"},
      h("p", {class: "sp-einstieg-text"}, T.BEGRUESSUNG),
      h("div", {class: "sp-einstieg-knoepfe"},
        h("button", {type: "button", class: "knopf primaer", onclick: () => wahl("auftrag")}, T.WEG_AUFTRAG),
        h("button", {type: "button", class: "knopf geist", onclick: () => wahl("umsehen")}, T.WEG_UMSEHEN)));
  }
  /* ---------- Onboarding: erstes Ticket mit Coach-Hinweisen ---------- */
  /* Textdiät (A4): je Schritt genau ein Satz und ein Knopf; das passende Werkzeug ist schon gewählt.
     Einstieg in 90 s (Hebel 7): statt Willkommensfenster spricht der Senior in zwei kurzen Blasen (zusammen ≤ 25 Wörter);
     die zweite Blase kommt nach 2,6 s oder auf Klick. */
  const COACH = [
    /* Station 2 (Bau P7): EINE Anweisung statt der Sprechblase des Seniors. Sie nennt den WEG
       (Kabel-Werkzeug), nicht die LÖSUNG: Das Ziel des Auftrags ist „Die Kasse druckt auf dem
       Drucker“; welches Gerät seinen Link verloren hat und wo der Switch hängt, sieht der Spieler
       selbst. Deshalb auch keine Geräte-Hervorhebung mehr – die zeigte genau das Paar. */
    {text: Spiel.EINSTIEG_TEXTE.HINWEIS, werkzeug: "kabel", zeigen: []},
    {text: "Prüf es wie ein Profi: Zieh mit dem Ping-Werkzeug von der Kasse auf den Drucker.", werkzeug: "ping", zeigen: ["kasse", "drucker"]},
    {text: "Paket angekommen – jetzt fehlt nur noch die Abnahme.", werkzeug: "auswahl", zeigen: []},
  ];
  function coachStart(){
    if (Spiel.einst.coach === false) return false;
    S.coach = {schritt: 0, blase: 0, neu: true};
    coachZeigen();
    UI.labor.auftragNeu();          /* Zeile sofort zeigen – vor dem Einpassen im nächsten Frame */
    if (COACH[0].blasen) S.coach.timer = setTimeout(() => coachBlase(1), 2600);
    return true;
  }
  function coachBlase(n){
    const c = S.coach && COACH[S.coach.schritt];
    if (!c || !c.blasen || (S.coach.blase || 0) >= n) return;
    clearTimeout(S.coach.timer);
    S.coach.blase = n; S.coach.neu = true;
    coachZeigen(); UI.labor.auftragNeu(); UI.klang?.spielen("blase");
  }
  function coachWeiter(n){ if (!S.coach) return; clearTimeout(S.coach.timer); S.coach.schritt = Math.max(S.coach.schritt, n); S.coach.blase = 0; S.coach.neu = true; coachZeigen(); UI.labor.auftragNeu(); }
  function coachZeigen(){
    const c = S.coach && COACH[S.coach.schritt]; if (!c) return;
    /* Einsteiger ziehen sonst Geräte herum statt zu verkabeln: passendes Werkzeug vorwählen */
    if (c.werkzeug && UI.labor.werkzeugName !== c.werkzeug) UI.labor.werkzeug(c.werkzeug);
    const letzte = !c.blasen || (S.coach.blase || 0) >= c.blasen.length - 1;    /* Geräte erst zeigen, wenn die Aufgabe dasteht */
    if (letzte && c.zeigen.length) setTimeout(() => UI.labor.hervorheben(c.zeigen.map(g => ({geraet: g})), 4500), 250);
  }
  function coachLeiste(){
    const c = COACH[S.coach.schritt];
    const def = S.inst ? Spiel.defVon(S.inst) : null, k = kunde(S.inst?.kunde || def?.kunde);
    const text = c.blasen ? c.blasen[S.coach.blase || 0](k) : c.text;
    const mehr = !!c.blasen && (S.coach.blase || 0) < c.blasen.length - 1;
    const el = h("div", {class: "sp-coach" + (!c.blasen ? " hinweis" : "") + (S.coach.neu ? " neu" : "") + (mehr ? " weiter" : ""), "data-hinweisquelle": "coach",
      title: mehr ? "Klick: weiter" : null, onclick: mehr ? () => coachBlase((S.coach.blase || 0) + 1) : null},
      h("span", {class: "sp-coach-sym", "aria-hidden": "true"}, UI.symbol("senior", 22)), h("p", {class: "sp-blase"}, text),
      h("button", {type: "button", class: "knopf geist klein", onclick: e => { e.stopPropagation(); clearTimeout(S.coach?.timer); S.coach = null; Spiel.einstSetzen("coach", false); UI.labor.auftragNeu(); }}, "Hinweise aus"));
    S.coach.neu = false;
    return el;
  }
  /* Einstieg in 90 s (Hebel 7): kein Fenster vorab – das Spiel öffnet sofort den ersten Auftrag, der Senior spricht
     dort in zwei kurzen Blasen. Messpunkte (für die Abnahme): S.mess = {t0, ersteHandlung, erfolg} in ms seit Seitenstart. */
  function einstiegStarten(){
    let inst = Spiel.st.postfach.find(i => i.ticketId === Spiel.EINSTIEG_TICKET);
    if (!inst) inst = Spiel.instanzErstellen({ticketId: Spiel.EINSTIEG_TICKET, quelle: "postfach"});
    S.mess = {t0: Math.round(performance.now()), ersteHandlung: null, erfolg: null};
    oeffnen(inst.iid);
  }

  /* ---------- Vorhersage: erst raten, dann sehen (Einstieg und AP1) ---------- */
  function vorhersageEinrichten(){
    const F = UI.labor._f; if (!F || !F.ping || F.ping.__vorhersage) return;
    const original = F.ping;
    const huelle = function(von, nach){
      const inst = S.inst;
      if (!inst || !istTicketNetz() || !Spiel.einst.vorhersage) return original(von, nach);
      const def = Spiel.defVon(inst), niveau = Spiel.niveauVon(inst);
      const schluessel = inst.iid + ":" + von + ">" + nach;
      const fragen = niveau !== "AP2" && (def.vorhersage || !S.vorhersageGefragt.has(inst.iid)) && !S.vorhersageGefragt.has(schluessel);
      if (!fragen) return original(von, nach);
      S.vorhersageGefragt.add(inst.iid); S.vorhersageGefragt.add(schluessel);
      const A = UI.labor.netz.geraete[von], B = UI.labor.netz.geraete[nach];
      const antwort = tipp => {
        zu();
        const r = original(von, nach);
        if (!r || tipp == null) return;
        const ok = (r.antworten || []).some(a => a && a.ok);
        const richtig = tipp === ok;
        if (typeof L !== "undefined") { Spiel.skillsRegistrieren(); L.ueben("lab.ping", richtig); }
        if (richtig) { Spiel.abzeichen.zaehlen("vorhersageRichtig"); Spiel.gutschreiben(2, 0, "Richtig vorhergesagt"); }
        setTimeout(() => UI.toast(richtig ? "Richtig vorhergesagt! +2 €" : `Knapp daneben: Du hast auf „${tipp ? "klappt" : "klappt nicht"}“ getippt. Die Simulation zeigt, warum.`,
          richtig ? "ok" : "info", {id: "vorhersage", titel: "Vorhersage"}), 1600);
      };
      const zu = overlay(h("div", {class: "sp-vorhersage"},
        h("small", {class: "sp-leise"}, "Vorhersage – erst raten, dann sehen"),
        h("h3", {}, `Wird der Ping von ${A?.name || von} zu ${B?.name || nach} klappen?`),
        h("div", {class: "sp-knoepfe"},
          h("button", {type: "button", class: "knopf primaer", onclick: () => antwort(true)}, "✓ Ja, klappt"),
          h("button", {type: "button", class: "knopf", onclick: () => antwort(false)}, "✗ Nein"),
          h("button", {type: "button", class: "knopf geist", onclick: () => antwort(null)}, "Überspringen"))), "vorhersage");
      return null;
    };
    huelle.__vorhersage = true;
    F.ping = huelle;
  }

  /* ---------- Abzeichen: im Ergebnisfenster oder als Toast – nie unsichtbar hinter einem Dialog ---------- */
  let abzTimer = null;
  function abzeichenPlanen(ms){ clearTimeout(abzTimer); abzTimer = setTimeout(abzeichenZeigen, ms); }
  function abzeichenZeigen(){
    if (!UI.buehneFrei() || S.probe) { abzeichenPlanen(1500); return; }
    const neu = Spiel.abzeichen.abholen(); if (!neu.length) return;
    const ansehen = {text: "Ansehen", fn: () => UI.app.ansicht("lernstand")};
    if (neu.length > 2) UI.toast(neu.map(a => a.sym + " " + a.titel).join(" · "), "ok", {titel: `${neu.length} neue Abzeichen`, aktion: ansehen});
    else for (const a of neu) UI.toast(`${a.sym} ${a.titel} – ${a.text}`, "ok", {titel: "Neues Abzeichen", aktion: ansehen});
  }
  /* Neue Kundenpost: leiser Hinweis in der Vollansicht, erst wenn kein Dialog offen ist (die Leiste zeigt nur den Zähler) */
  function postMelden(neu, versuch = 0){
    if (UI.modus() !== "voll") return;
    if ((!UI.buehneFrei() || S.probe) && versuch < 40) { setTimeout(() => postMelden(neu, versuch + 1), 1500); return; }
    const n = neu[neu.length - 1], a = postAbsender(n);
    UI.toast(neu.length > 1 ? `${neu.length} neue Nachrichten im Postfach.` : `${a.name}: ${String(n.text).split("\n")[0].slice(0, 90)}${String(n.text).length > 90 ? " …" : ""}`, "info",
      {titel: "✉ Neue Nachricht", id: "post", aktion: {text: "Lesen", fn: () => { S.postfachWahl = n.id; UI.app.ansicht("postfach"); }}});
  }

  document.addEventListener("keydown", e => {
    if (e.key !== "Escape" || !S.mappe.offen || UI.app.aktuell !== "labor" || UI.menue?.offen?.() || document.querySelector(".sp-overlay, .dialog-huelle")) return;
    e.preventDefault(); e.stopPropagation(); mappeZu();
  }, true);

  /* ---------- Bus ---------- */
  /* Fenster verkleinert/vergrößert: die Höhen-Klemme der offenen Mappe nachziehen (Runde 5). */
  if (typeof window !== "undefined" && window.addEventListener) window.addEventListener("resize", () => {
    if (!S.mappe.offen) return;
    const mm = document.querySelector(".am-mappe");
    if (mm) mappeHoeheKlemmen(mm);
  });
  /* Ansichtswechsel: die Mappe gehört zum Labor – beim Verlassen schließen, damit die Klasse
     .mappe-an (Werkzeugleiste ruht) nie auf einer anderen Ansicht hängen bleibt (Leitung, 31.10.2026). */
  Bus.an("ansicht", name => { if (name !== "labor" && S.mappe.offen) mappeZu(); });
  Bus.an("netz-geaendert", d => {
    if (S.inst && d && d.netz === S.inst.netz) livePlanen();
    if (S.mess && S.mess.ersteHandlung == null) S.mess.ersteHandlung = Math.round(performance.now());
  });
  Bus.an("arbeit-geaendert", d => { if (S.inst && d && d.inst === S.inst) livePlanen(); });   /* Antwort, Tabelle, Notiz, Audit */
  Bus.an("befehl-gemerkt", d => {
    if (!S.inst || !d || d.inst !== S.inst) return;
    const b = (S.inst.befehle || []).slice(-1)[0], name = b && (S.inst.netz.geraete[b.geraet]?.name || b.geraet);
    if (b) wegMerken(S.inst, {art: "befehl", ok: b.ok, text: `${name}> ${b.befehl.length > 28 ? b.befehl.slice(0, 27) + "…" : b.befehl}`});
    livePlanen();
  });
  Bus.an("zustand-geaendert", () => {
    status();
    if (Spiel.abzeichen.pruefen().length) abzeichenPlanen(400);
    const neuePost = Spiel.post.pruefen();
    if (neuePost.length) { status(); setTimeout(() => postMelden(neuePost), 400); }   /* erst nach dem Start der Probe prüfen, ob die Bühne frei ist */
  });
  Bus.an("ticket-neu", () => { status(); if (UI.app.aktuell === "postfach") { const c = document.querySelector(".sp-postfach")?.parentElement; if (c) postfachAnsicht(c); } });
  Bus.an("trace", d => {
    if (S.inst && d && d.quelle === "ping" && d.ergebnis && UI.labor.netz === S.inst.netz) {
      const ok = (d.ergebnis.antworten || []).some(a => a.ok), n = id => UI.labor.netz.geraete[id]?.name || id;
      wegMerken(S.inst, {art: "ping", ok, text: `Ping ${n(d.von)} → ${n(d.nach)} ${ok ? "✓" : "✗"}`});
    }
    if (S.coach && S.coach.schritt === 1 && d && d.quelle === "ping" && d.ergebnis && (d.ergebnis.antworten || []).some(a => a.ok)) coachWeiter(2);
  });

  /* ---------- Start ---------- */
  (UI.startHaken ||= []).push(() => {
    UI.app.registrieren("postfach", {titel: "Postfach", symbol: "postfach", zeigen: c => postfachAnsicht(c), wieder: c => postfachAnsicht(c),
      zaehler: () => Spiel._st ? Spiel.ungelesen() : 0});
  });
  Bus.an("ui-bereit", () => {
    try {
      Spiel.laden();
      Spiel.tagebuch.sitzung();                     /* Spieltagebuch: eine Sitzung je Programmstart */
      vorhersageEinrichten();
      /* Desktop: Rust hat das Fenster umgeschaltet (Tray-Klick, Strg+Alt+L, Ruhe) – Ansicht nachziehen */
      Plattform.an("modus-extern", m => { if (UI.modus() !== m) UI.modus(m); });
      status();
      aktiveLaden();
      if (!Spiel.st.einstieg.fertig && !Spiel.st.erledigt.length) { if (!S.inst) einstiegStarten(); else UI.app.ansicht("labor"); }
      else UI.app.ansicht("heute");                /* Hub „Heute“ ist die Startansicht (S2); ein offener Auftrag wartet dort */
    } catch (e) { console.error("Spielstart", e); UI.toast("Das Spiel konnte nicht starten: " + e.message, "fehler"); }
  });

  /* Postfach mit diesem Auftrag im Leser öffnen (Karte „Weiterempfehlung“) */
  function imPostfach(iid){ S.postfachWahl = iid; UI.app.ansicht("postfach"); }
  return {oeffnen, postfachAnsicht, status, abnahmeAnfordern, einstiegStarten, mappeAuf, mappeZu, imPostfach, get inst(){ return S.inst; }, get mess(){ return S.mess || null; }, _S: S};
})();
