/**
 * UI-Komponente für QC-Gates in NetLab 4.0
 * @class QCGatesUI
 */
class QCGatesUI {
    /**
     * Konstruktor
     */
    constructor() {
        this.gates = [];
        this.container = null;
        this.onGateUpdate = null;
    }
    
    /**
     * Initialisiert die QC-Gates UI
     * @param {string} containerId - ID des Containers
     * @returns {QCGatesUI} Instanz für Chain-Methoden
     */
    init(containerId) {
        this.container = document.getElementById(containerId);
        if (!this.container) {
            this.container = document.createElement('div');
            this.container.id = containerId;
            document.body.appendChild(this.container);
        }
        return this;
    }
    
    /**
     * Zeigt QC-Gates in der UI an
     * @returns {void}
     */
    renderGates() {
        if (!this.container) return;
        
        const html = this.gates.map(gate => `
            <div class="qc-gate" data-id="${gate.id}">
                <span class="gate-name">${gate.name}</span>
                <span class="gate-status ${gate.status}">${gate.status}</span>
                <button class="gate-check" data-id="${gate.id}">Prüfen</button>
            </div>
        `).join('');
        
        this.container.innerHTML = html;
        
        // Füge Event Listener hinzu
        const buttons = this.container.querySelectorAll('.gate-check');
        buttons.forEach(button => {
            button.addEventListener('click', (e) => {
                const gateId = e.target.dataset.id;
                this.checkGate(gateId);
            });
        });
    }
    
    /**
     * Fügt ein neues Gate hinzu
     * @param {Object} gateData - Gate-Daten
     * @returns {void}
     */
    addGate(gateData) {
        if (!gateData.id || !gateData.name) {
            console.error('Ungültige Gate-Daten:', gateData);
            return;
        }
        
        this.gates.push({
            id: gateData.id,
            name: gateData.name,
            status: 'untested',
            createdAt: new Date()
        });
        this.renderGates();
    }
    
    /**
     * Aktualisiert einen Gate-Status
     * @param {string} gateId - Gate-ID
     * @param {string} status - Neuer Status
     * @returns {void}
     */
    updateGateStatus(gateId, status) {
        const gate = this.gates.find(g => g.id === gateId);
        if (gate) {
            gate.status = status;
            gate.updatedAt = new Date();
            this.renderGates();
            
            // Callback aufrufen, falls vorhanden
            if (this.onGateUpdate) {
                this.onGateUpdate(gateId, status);
            }
        }
    }
    
    /**
     * Prüft einen Gate
     * @param {string} gateId - Gate-ID
     * @returns {void}
     */
    checkGate(gateId) {
        const gate = this.gates.find(g => g.id === gateId);
        if (gate) {
            // Simuliere Prüfung
            const statuses = ['passed', 'failed', 'pending'];
            const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
            this.updateGateStatus(gateId, randomStatus);
        }
    }
    
    /**
     * Gibt alle Gates zurück
     * @returns {Array} Liste aller Gates
     */
    getAllGates() {
        return this.gates;
    }
    
    /**
     * Setzt alle Gates zurück
     * @returns {void}
     */
    reset() {
        this.gates = [];
        this.renderGates();
    }
}

// Export für Verwendung in anderen Modulen
if (typeof module !== 'undefined' && module.exports) {
    module.exports = QCGatesUI;
} else {
    // Für Browser-Verwendung
    window.QCGatesUI = QCGatesUI;
}