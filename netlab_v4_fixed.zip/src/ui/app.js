"use strict";
/* ---------- App-Rahmen: Kopfzeile, Andock-Leiste, Ansichten, Einstellungen, Modi (Architektur § 9) ----------
   UI.app.registrieren(name, {titel, symbol, zeigen(container), wieder?(container), verlassen?(), zaehler?()})
   UI.app.ansicht(name)                  Ansicht wechseln (jede Ansicht füllt die Fläche; kein Fenstersystem)
   UI.app.status({euro, ruf, stufe, offen, fortschritt?:{anteil, text, bereit}})   Werte der Kopfzeile (leuchten bei Änderung kurz auf, Zahlen zählen hoch)
   UI.app.einstellungen()                Dialog; UI.app.einstellungAbschnitt(titel, renderFn(container)) ergänzt Abschnitte
   UI.app.hilfe()                        Tastenkürzel      UI.app.aktualisieren()  Zähler der Andock-Leiste neu lesen
   UI.app.liste()                        [{name, titel, symbol}]   UI.app.aktuell  Name der aktiven Ansicht
   UI.modus("voll"|"leiste"|"tray")      Wechsel im selben Fenster; baut das DOM der Vollansicht ab (store.sofort() vorher)
   UI.bewegung()                         "voll"|"reduziert"|"aus" (Einstellung + prefers-reduced-motion)
   Spiel-Ansichten melden sich an, indem sie beim Laden (UI.startHaken ||= []).push(() => UI.app.registrieren(…)) eintragen,
   oder später jederzeit UI.app.registrieren(…) aufrufen. */
UI.bewegung = function(){
  const e = (typeof store !== "undefined" && store.get("einst", {})) || {};
  if (e.bewegung === "aus") return "aus";
  if (e.bewegung === "reduziert" || wenigBewegung()) return "reduziert";
  return "voll";
};

/* ---------- Desktop-Fenster (Tauri): Kopfzeile als Fensterleiste (Runde 4, Strang E) ----------
   In der Vollansicht gibt es keine native Windows-Titelleiste mehr (shell/src-tauri/src/fenster.rs:
   modus "voll" schaltet set_decorations(false)). Diese Datei liefert die Ersatz-Kopfzeile:
     · sie ist Zieh-Fläche über `data-tauri-drag-region="deep"` – Tauris Ziehskript startet damit das
       System-Fensterziehen (Snap an Bildschirmkanten bleibt Windows-Sache) und maximiert per
       Doppelklick über `internal_toggle_maximize`; eigenes JS braucht es dafür nicht,
     · rechts stehen die drei Fensterknöpfe Minimieren/Maximieren/Schließen (44 px, aria-label,
       Tastatur, Fokusring aus basis.css). Sie rufen den eigenen Hüllen-Befehl `fenster_knopf`.
   NUR im Tauri-Modus (`Plattform.name === "tauri"`): die Browser-Fassung behält ihre Kopfzeile
   ohne Knöpfe und ohne Zieh-Fläche. Zustand zum Beschriften (Maximieren/Wiederherstellen) kommt
   aus `fenster_zustand` – nach Knopfdruck und nach dem Größeändern. */
UI.fenster = (() => {
  const da = () => typeof Plattform !== "undefined" && Plattform.name === "tauri";
  const ruf = (befehl, args) => {
    try {
      const t = typeof window !== "undefined" ? window.__TAURI__ : null;
      if (!t || !t.core || typeof t.core.invoke !== "function") return Promise.resolve(null);
      return Promise.resolve(t.core.invoke(befehl, args || {})).catch(e => { console.warn("Fenster", befehl, e); return null; });
    } catch (e) { console.warn("Fenster", befehl, e); return Promise.resolve(null); }
  };
  /* Eigene Inline-SVGs – UI.symbol kennt keine Fensterglyphen. Strichfarbe aus dem Knopf (currentColor). */
  const strich = (d, extra) => sv("svg", Object.assign({viewBox: "0 0 16 16", width: 16, height: 16, "aria-hidden": "true",
    fill: "none", stroke: "currentColor", "stroke-width": "1.6", "stroke-linecap": "round", "stroke-linejoin": "round"}, extra || {}), sv("path", {d}));
  const symbol = art => art === "minimieren" ? strich("M3.5 8h9")
    : art === "maximieren" ? strich("M3.5 3.5h9v9h-9z")
    : art === "wiederherstellen" ? strich("M5.5 5.5V4h7v7H11M3.5 5.5H11v7H3.5z")
    : strich("M4 4l8 8M12 4l-8 8");
  return {da, ruf, symbol};
})();

UI.app = (() => {
  /* Reihenfolge der Andock-Knöpfe. „training" steht seit der Hilfestellung (07.10.2026) vor „lernstand":
     der Trainingsbereich ist der Ort, an dem ein Azubi ohne Auftragsdruck übt (Vertrag § 6).
     Runde 7 (31.10.2026): „subnetz" steht direkt nach „labor" — verstehen und üben (Abteilung
     Subnetting) vor dem Training ganzer Fälle; unbekannte Namen überspringt liste() ohnehin. */
  const REIHE = ["heute", "postfach", "labor", "subnetz", "training", "kunden", "wiki", "lernstand", "shop"];
  const PLATZ = {
    postfach:  {titel: "Postfach",  symbol: "postfach",  text: "Hier landen die Aufträge deiner Kunden: Störungen, Projekte, Wartung.", mehr: "Das Postfach öffnet, sobald die Karriere eingebaut ist."},
    kunden:    {titel: "Kunden",    symbol: "kunden",    text: "Deine Kunden mit Vertrag, Ampel und Bewertungen.", mehr: "Die Kundenliste kommt mit der Karriere."},
    wiki:      {titel: "Wiki",      symbol: "wiki",      text: "Nachschlagen: Subnetting, VLAN, NAT, ACL, DHCP, DNS …", mehr: "Das Wiki wird gerade eingerichtet."},
    lernstand: {titel: "Lernstand", symbol: "lernstand", text: "Was du schon sicher kannst und was als Nächstes dran ist.", mehr: "Der Lernstand kommt mit dem Lernmotor."},
    shop:      {titel: "Shop",      symbol: "shop",      text: "Werkzeuge, Geräte und Verträge für dein Systemhaus.", mehr: "Der Shop öffnet mit der Karriere."},
  };
  const ansichten = new Map();
  const abschnitte = [];
  let root = null, el = {}, aktiv = null, gebaut = new Map(), wert = {euro: null, ruf: null, stufe: null, offen: null}, dialog = null;
  let modus = null, tastenAn = false, fensterHorer = null;

  /* ---------- Thema ---------- */
  const einst = () => store.get("einst", {}) || {};
  Bus.an("aussehen", () => themaAnwenden());
  Bus.an("ui-bereit", () => setTimeout(themaAnwenden, 0));            /* nach Spiel.laden: gekauftes Aussehen anwenden */
  function einstSetzen(teil){ const e = einst(); Object.assign(e, teil); store.set("einst", e); }
  /* Zusätzliche Themes (§ 18.16): eigene Stildateien src/stil/zzz-thema-<id>.css, Tokens in
     :root[data-theme="<id>"]; dunkel steuert nur die Sonne/Mond-Anzeige und color-scheme. */
  const THEMEN = [
    {id: "nordlicht", titel: "Nordlicht", dunkel: true},
    {id: "messing", titel: "Messing", dunkel: true},
    {id: "papier", titel: "Papier", dunkel: false},
    {id: "pulsar", titel: "Pulsar", dunkel: true},
    {id: "keramik", titel: "Keramik", dunkel: false},
  ];
  const eigenesTheme = t => THEMEN.find(x => x.id === t) || null;
  function themaAnwenden(){
    const t = einst().thema || "dunkel", d = document.documentElement;   /* § 18.3: Dunkel ist Standard */
    const eigen = eigenesTheme(t);
    if (t === "hell") d.dataset.theme = "light"; else if (t === "dunkel") d.dataset.theme = "dark";
    else if (t === "system") delete d.dataset.theme; else if (eigen) d.dataset.theme = eigen.id; else delete d.dataset.theme;
    /* `color-scheme` muss zum tatsächlich gezeichneten Schema passen (native Dropdowns, Range,
       Scrollbars). Vorher stand bei „system" mit hellem Betriebssystemwunsch „dark" — die Seite
       war hell, die Controls blieben dunkel (Befund der Design-Prüfung Runde 8). Drei Fälle:
       eigenes Theme → dessen dunkel-Flag; hell/dunkel → fest; system → Betriebssystemwunsch. */
    const dunkelSchema = eigen ? eigen.dunkel
      : t === "hell" ? false
      : t === "dunkel" ? true
      : !(typeof matchMedia !== "undefined" && matchMedia("(prefers-color-scheme: light)").matches);
    d.style.colorScheme = dunkelSchema ? "dark" : "light";
    /* Aussehen aus dem Shop (Akzentfarbe, Leistenstil) – vorher wurde es gekauft, aber nie angewendet */
    const a = typeof Spiel !== "undefined" && Spiel._st && Spiel.karriere ? Spiel.karriere.daten().aussehen : null;
    if (a && a.akzent && a.akzent !== "cyan") d.dataset.akzent = a.akzent; else delete d.dataset.akzent;
    if (a && a.leiste && a.leiste !== "standard") d.dataset.leiste = a.leiste; else delete d.dataset.leiste;
    d.dataset.bewegung = UI.bewegung();
    if (el.thema) { const dunkel = istDunkel(); el.thema.replaceChildren(UI.symbol(dunkel ? "sonne" : "mond", 18)); el.thema.title = dunkel ? "Helle Darstellung" : "Dunkle Darstellung"; }
  }
  function istDunkel(){
    const eigen = eigenesTheme(einst().thema);
    if (eigen) return eigen.dunkel;
    const t = document.documentElement.dataset.theme;
    if (t) return t === "dark";
    return !(typeof matchMedia !== "undefined" && matchMedia("(prefers-color-scheme: light)").matches);
  }
  function themaUmschalten(){ einstSetzen({thema: istDunkel() ? "hell" : "dunkel"}); themaAnwenden(); }

  /* ---------- Ansichten ---------- */
  function registrieren(name, def){
    if (!name || !def) return;
    const alt = ansichten.get(name);
    ansichten.set(name, Object.assign({name, titel: name, symbol: "info"}, def));
    if (alt && gebaut.has(name)) { gebaut.get(name).remove(); gebaut.delete(name); if (aktiv === name) { aktiv = null; ansicht(name); } }
    dockZeichnen();
  }
  function platzhalterDef(name){
    const p = PLATZ[name];
    return {titel: p.titel, symbol: p.symbol, platzhalter: true, zeigen: c => {
      c.append(h("div", {class: "platzhalter"},
        h("div", {class: "ph-sym"}, UI.symbol(p.symbol, 40)),
        h("h2", {}, p.titel),
        h("p", {class: "ph-text"}, p.text),
        h("p", {class: "ph-mehr"}, p.mehr + " Bis dahin: probier im freien Labor alles aus – nichts kann kaputtgehen, Rückgängig macht alles wieder gut."),
        h("button", {type: "button", class: "knopf knopf-haupt", onclick: () => ansicht("labor")}, UI.symbol("labor", 18), "Zum Labor")));
    }};
  }
  function grundAusstattung(){
    if (!ansichten.has("labor")) ansichten.set("labor", {name: "labor", titel: "Labor", symbol: "labor", zeigen: c => UI.labor.zeigen(c), wieder: () => UI.labor.wieder()});
    for (const n of Object.keys(PLATZ)) if (!ansichten.has(n)) ansichten.set(n, Object.assign({name: n}, platzhalterDef(n)));
  }
  function liste(){
    const namen = [...REIHE.filter(n => ansichten.has(n)), ...[...ansichten.keys()].filter(n => !REIHE.includes(n))];
    /* `kurz` ist die Beschriftung im Dock: die Spalte ist 76 px breit, lange Titel („Subnetting")
       brechen dort mitten im Wort um (gemessen 31.10.2026). Der volle Titel bleibt Titel, Tooltip
       und Statusfuß; im Dock steht die kurze Form. Fehlt sie, gilt wie bisher der Titel. */
    return namen.map(n => { const a = ansichten.get(n); return {name: n, titel: a.titel, kurz: a.kurz, symbol: a.symbol, platzhalter: !!a.platzhalter}; });
  }
  function ansicht(name){
    if (!ansichten.has(name)) return;
    if (modus !== "voll" || !root) { aktiv = name; return; }
    if (aktiv === name && gebaut.has(name)) return;
    const vorher = aktiv && ansichten.get(aktiv);
    try { vorher?.verlassen?.(); } catch (e) { console.error(e); }
    UI.menue?.zu?.();
    aktiv = name;
    for (const [n, c] of gebaut) c.hidden = n !== name;
    const def = ansichten.get(name);
    let c = gebaut.get(name);
    if (!c) {
      c = h("div", {class: "ansicht", "data-ansicht": name});
      el.flaeche.append(c); gebaut.set(name, c);
      try { def.zeigen(c); } catch (e) { console.error("Ansicht " + name, e); c.append(h("p", {class: "platzhalter"}, `Diese Ansicht konnte nicht aufgebaut werden: ${e.message || e}`)); }
    } else { c.hidden = false; try { def.wieder?.(c); } catch (e) { console.error(e); } }
    for (const b of $$(".dock-knopf", root)) { const an = b.dataset.ansicht === name; b.classList.toggle("an", an); if (an) b.setAttribute("aria-current", "page"); else b.removeAttribute("aria-current"); }
    for (const b of $$(".kopf-nav-knopf", root)) { const an = b.dataset.ansicht === name; b.classList.toggle("an", an); if (an) b.setAttribute("aria-current", "page"); else b.removeAttribute("aria-current"); }
    if (el.fussWeg) el.fussWeg.textContent = "Ansicht: " + (def.titel || name);
    Bus.senden("ansicht", name);
  }
  function dockZeichnen(){
    if (!el.dock) return;
    el.dock.replaceChildren(...liste().map(a => {
      const z = h("span", {class: "dock-zahl", hidden: true});
      const b = h("button", {type: "button", class: "dock-knopf" + (a.name === aktiv ? " an" : "") + (a.platzhalter ? " spaeter" : ""), "data-ansicht": a.name, title: a.titel,
        onclick: () => ansicht(a.name)}, typeof a.symbol === "string" ? UI.symbol(a.symbol, 22) : a.symbol, h("span", {class: "dock-text"}, a.kurz || a.titel), z);
      if (a.name === aktiv) b.setAttribute("aria-current", "page");
      return b;
    }));
    aktualisieren();
  }
  function aktualisieren(){
    if (!el.dock) return;
    for (const b of $$(".dock-knopf", el.dock)) {
      const def = ansichten.get(b.dataset.ansicht), z = $(".dock-zahl", b);
      let n = 0; try { n = def?.zaehler ? +def.zaehler() || 0 : 0; } catch (e) { console.error(e); }
      z.hidden = !n; z.textContent = n > 99 ? "99+" : String(n);
    }
  }

  /* ---------- Kopfzeile ---------- */
  function wertEl(klasse, sym, titel, onclick){
    const zahl = h("span", {class: "wert-zahl"});
    const b = h(onclick ? "button" : "div", {class: "wert " + klasse, title: titel, ...(onclick ? {type: "button", onclick} : {})}, UI.symbol(sym, 16), zahl);
    return {b, zahl};
  }
  const FORMAT = {
    euro: x => x == null ? "– €" : `${eur(x)} €`,
    ruf: x => x == null ? "Ruf –" : `Ruf ${zahlDe(Math.round(x))}`,
    /* „Karriere" statt „Stufe": das Programm benutzt „Stufe" für vier Dinge (Karriere, Bildungsstand,
       Erklärtiefe, Hilfeleiter). Der Tooltip dieser Fläche sagte schon immer „Karriere-Stufe", die
       sichtbare Beschriftung widersprach ihm (Review Auffindbarkeit, Befund 4, 07.10.2026). */
    stufe: x => x == null ? "Karriere –" : `Karriere ${x}`,
    offen: x => x == null ? "0 Tickets" : `${zahlDe(x)} ${x === 1 ? "Ticket" : "Tickets"}`,
  };
  /* Speicher-Kennzeichen: drei Zustände, kein Klickziel, keine Animation, nur ein leiser Text.
     Die Breite zählt (Telefon in beiden Ausrichtungen): auf sehr schmalen Geräten (≤ 380 px)
     steht nur das Zeichen, das Ausführliche immer im Titel. Angeschlossen an Bus
     „speicher-stand“ aus src/kern/basis.js. */
  const STAND_TEXT = {schreibt: "… sichert", gesichert: "✓ gesichert", fehler: "⚠ nicht gesichert"};
  const STAND_KURZ = {schreibt: "…", gesichert: "✓", fehler: "⚠"};
  const schmal = () => typeof matchMedia !== "undefined" && matchMedia("(max-width: 380px)").matches;
  function standZeigen(s){
    if (!el.stand) return;
    s = s && s.art ? s : store.stand();
    const zeit = s.zeit ? new Date(s.zeit).toLocaleTimeString("de-DE", {hour: "2-digit", minute: "2-digit"}) : null;
    el.stand.textContent = (schmal() ? STAND_KURZ : STAND_TEXT)[s.art] || "";
    el.stand.title = s.art === "fehler"
      ? `Spielstand NICHT gesichert (${s.fehler?.name || "Fehler"}): ${s.fehler?.text || ""}`
      : s.art === "schreibt" ? "Der Spielstand wird geschrieben …"
      : `Spielstand gesichert${zeit ? " um " + zeit : ""}`;
  }
  Bus.an("speicher-stand", standZeigen);
  if (typeof matchMedia !== "undefined") {
    try { matchMedia("(max-width: 380px)").addEventListener("change", () => standZeigen()); } catch (e) { /* alte Browser */ }
  }
  function status(s = {}){
    /* Fortschritt zur nächsten Stufe als feiner Balken unter „Stufe N“ (Ruf UND Können zählen, der kleinere Anteil bestimmt) */
    if ("fortschritt" in s && el.werte?.stufe) {
      const f = s.fortschritt, b = el.werte.stufe.b;
      b.classList.toggle("mit-fortschritt", !!f);
      b.classList.toggle("bereit", !!f?.bereit);
      b.style.setProperty("--fortschritt", f ? Math.round(klemme(f.anteil || 0, 0, 1) * 100) + "%" : "0%");
      b.title = f?.text || "Karriere-Stufe";
    }
    for (const k of Object.keys(FORMAT)) {
      if (!(k in s)) continue;
      const alt = wert[k], neu = s[k];
      wert[k] = neu;
      const w = el.werte?.[k]; if (!w) continue;
      if (alt === neu) { w.zahl.textContent = FORMAT[k](neu); continue; }
      w.b.classList.toggle("leer", neu == null);
      if (k === "offen") w.b.classList.toggle("hat", +neu > 0);
      if (typeof alt === "number" && typeof neu === "number" && k !== "stufe" && UI.bewegung() === "voll") zaehlen(w, k, alt, neu);
      else w.zahl.textContent = FORMAT[k](neu);
      if (alt != null && neu != null) { w.b.classList.remove("leuchtet"); void w.b.offsetWidth; w.b.classList.add("leuchtet"); w.b.classList.toggle("runter", neu < alt); }
      if (k === "euro" && typeof alt === "number" && neu > alt) UI.juice?.(w.b, "geld", 1000);
    }
  }
  function zaehlen(w, k, alt, neu){
    const t0 = performance.now(), ms = UI.zeit("zaehler"), marke = (w.marke = (w.marke || 0) + 1);
    const s = t => {
      if (w.marke !== marke) return;
      const p = Math.min(1, (t - t0) / ms), e = 1 - Math.pow(1 - p, 3);
      const x = alt + (neu - alt) * e;
      w.zahl.textContent = FORMAT[k](k === "euro" ? x : Math.round(x));
      if (p < 1) requestAnimationFrame(s); else w.zahl.textContent = FORMAT[k](neu);
    };
    requestAnimationFrame(s);
  }

  /* ---------- Fensterknöpfe der Kopfzeile (nur Tauri-Modus, Strang E) ----------
     Die Kopfzeile ist im Tauri-Modus zugleich Titelleiste: Ziehen/Doppelklick übernimmt Tauris
     Ziehskript (Attribut data-tauri-drag-region, in fenster.rs dokumentiert). Hier entstehen die drei
     Knöpfe; alle 44 px, mit aria-label und Fokusring, im Browser gar nicht. */
  function fensterKopf(kopf){
    kopf.classList.add("mit-fenster");
    kopf.setAttribute("data-tauri-drag-region", "deep");
    const stand = {max: false};
    /* Beschriftung/Icon folgen dem echten Fensterzustand (auch nach Doppelklick oder Ziehen am Rand). */
    function merkmal(z){
      if (!z || typeof z.maximiert !== "boolean" || stand.max === z.maximiert) return;
      stand.max = z.maximiert;
      const titel = stand.max ? "Wiederherstellen" : "Maximieren";
      maximieren.setAttribute("aria-label", titel);
      maximieren.title = titel;
      maximieren.replaceChildren(UI.fenster.symbol(stand.max ? "wiederherstellen" : "maximieren"));
    }
    const knopf = (art, titel, fn) => h("button", {type: "button", class: "fenster-knopf" + (art === "schliessen" ? " schliessen" : ""),
      "data-fenster": art, title: titel, "aria-label": titel, onclick: fn}, UI.fenster.symbol(art));
    const minimieren = knopf("minimieren", "Minimieren", () => UI.fenster.ruf("fenster_knopf", {aktion: "minimieren"}));
    const maximieren = h("button", {type: "button", class: "fenster-knopf", "data-fenster": "maximieren", title: "Maximieren", "aria-label": "Maximieren",
      onclick: () => UI.fenster.ruf("fenster_knopf", {aktion: "maximieren"}).then(merkmal)}, UI.fenster.symbol("maximieren"));
    const schliessen = knopf("schliessen", "Schließen", () => UI.fenster.ruf("fenster_knopf", {aktion: "schliessen"}));
    kopf.append(h("div", {class: "fenster-knoepfe", role: "group", "aria-label": "Fenster"}, minimieren, maximieren, schliessen));
    UI.fenster.ruf("fenster_zustand").then(merkmal);            /* Grundzustand: läuft maximiert? */
    if (typeof window !== "undefined" && window.addEventListener && window.removeEventListener) {
      let uhr = 0;
      const nachmessen = () => { clearTimeout(uhr); uhr = setTimeout(() => UI.fenster.ruf("fenster_zustand").then(merkmal), 160); };
      window.addEventListener("resize", nachmessen);              /* nach Ziehen am Rand: Knopf-Beschriftung nachziehen */
      fensterHorer = () => { window.removeEventListener("resize", nachmessen); clearTimeout(uhr); };
    }
  }

  /* ---------- Aufbau der Vollansicht ---------- */
  function aufbauen(container){
    grundAusstattung();
    root = h("div", {class: "app"});
    const knopf = (sym, titel, fn, text) => h("button", {type: "button", class: "kopf-knopf" + (text ? " mit-text" : ""), title: titel, "aria-label": titel, onclick: fn}, UI.symbol(sym, 18), text ? h("span", {}, text) : null);
    el.werte = {
      euro: wertEl("wert-euro", "euro", "Kontostand deines Systemhauses"),
      ruf: wertEl("wert-ruf", "stern", "Ruf bei deinen Kunden"),
      stufe: wertEl("wert-stufe", "stufe", "Karriere-Stufe", () => ansicht("lernstand")),
      offen: wertEl("wert-offen", "postfach", "Offene Tickets im Postfach", () => ansicht("postfach")),
    };
    el.thema = knopf("sonne", "Hell/Dunkel", themaUmschalten);
    el.stand = h("span", {class: "sp-leise", "aria-live": "polite", role: "status"});
    const kopf = h("header", {class: "kopf"},
      h("div", {class: "kopf-marke"},
        sv("svg", {viewBox: "0 0 32 32", width: 28, height: 28, class: "marke-sym", "aria-hidden": "true"},
          sv("rect", {x: 1.5, y: 1.5, width: 29, height: 29, rx: 8}),
          sv("path", {d: "M9 21V11h5v5h5v-5h4"}), sv("circle", {cx: 9, cy: 21, r: 2.2}), sv("circle", {cx: 23, cy: 11, r: 2.2}), sv("circle", {cx: 19, cy: 21, r: 2.2}), sv("path", {d: "M19 16v5"})),
        h("span", {class: "marke-name"}, "Netzwerk-Labor"),
        h("span", {class: "marke-version", title: typeof LABOR_BAU !== "undefined" ? "Baukennung " + LABOR_BAU + " (aus dem Inhalt der Bausteine)" : ""}, "v" + (typeof LABOR_VERSION !== "undefined" ? LABOR_VERSION : "dev")),
      ),
      el.stand,
      h("div", {class: "kopf-werte"}, el.werte.euro.b, el.werte.ruf.b, el.werte.stufe.b, el.werte.offen.b),
      h("div", {class: "kopf-knoepfe"},
        knopf("suche", "Befehlspalette (Strg+K)", () => UI.palette.oeffnen(), "Strg+K"),
        knopf("leiste", "Zur Leiste wechseln (kompakte Ansicht am Rand)", () => UI.modus("leiste"), "Zur Leiste"),
        el.thema,
        knopf("zahnrad", "Einstellungen", () => einstellungen()),
        knopf("hilfe", "Tastenkürzel (?)", () => hilfe())));
    el.dock = h("nav", {class: "dock", "aria-label": "Ansichten"});
    el.flaeche = h("main", {class: "flaeche"});
    /* § 18.7: Statusfuß 28 px — reine Anzeige (Ansicht links, Zustand rechts), keine Bedienelemente. */
    el.fussWeg = h("span", {class: "fuss-text"}, "Bereit");
    el.fussEbene = h("span", {class: "fuss-teil fuss-ebene"}, "Ebene IP");
    el.fuss = h("footer", {class: "fuss", "aria-label": "Statuszeile"},
      h("span", {class: "fuss-teil fuss-live"}, h("i", {class: "fuss-punkt", "aria-hidden": "true"}), "live"),
      h("span", {class: "fuss-teil", role: "status", "aria-live": "polite"}, el.fussWeg),
      el.fussEbene,
      h("span", {class: "fuss-teil"}, "lokal", h("span", {class: "fuss-trenner", "aria-hidden": "true"}, "·"), "kein Netz",
        h("span", {class: "fuss-trenner", "aria-hidden": "true"}, "·"), "v" + (typeof LABOR_VERSION !== "undefined" ? LABOR_VERSION : "dev")));
    /* Statuszeile: Ebene mitziehen, wenn die Netz-Ebene wechselt (Bus „ebene" aus UI.ebenen) */
    try {
      const EBENEN_NAME = {physik: "Physik", vlan: "VLAN", ip: "IP-Netze", mac: "MAC-Tabellen", routen: "Routen"};
      Bus.an("ebene", id => { if (el.fussEbene) el.fussEbene.textContent = "Ebene " + (EBENEN_NAME[id] || id); });
    } catch (e) { console.error(e); }
    if (UI.fenster.da()) fensterKopf(kopf);
    root.append(kopf, el.dock, el.flaeche, el.fuss);
    container.replaceChildren(root);
    gebaut = new Map();
    const alt = {...wert}; for (const k of Object.keys(wert)) wert[k] = undefined;
    status(alt);
    themaAnwenden();
    standZeigen(store.stand());          /* frisch aufgebaut: den letzten Speicherstand zeigen */
    dockZeichnen();
    const ziel = aktiv && ansichten.has(aktiv) ? aktiv : "labor";
    aktiv = null;
    ansicht(ziel);
    tastenEinrichten();
  }
  function abbauen(){
    dialogZu();
    if (fensterHorer) { try { fensterHorer(); } catch (e) { console.error(e); } fensterHorer = null; }
    for (const [n] of gebaut) { try { ansichten.get(n)?.verlassen?.(); } catch (e) { console.error(e); } }
    gebaut = new Map();
    root?.remove(); root = null; el = {};
  }

  /* ---------- Dialoge: Einstellungen und Tastenkürzel ---------- */
  function dialogOeffnen(titel, inhalt, klasse = ""){
    dialogZu();
    const zu = h("button", {type: "button", class: "dialog-zu", title: "Schließen (Esc)", "aria-label": "Schließen", onclick: () => dialogZu()}, UI.symbol("schliessen", 18));
    const kasten = h("div", {class: "dialog " + klasse, role: "dialog", "aria-modal": "true", "aria-label": titel},
      h("div", {class: "dialog-kopf"}, h("h2", {}, titel), zu), h("div", {class: "dialog-inhalt"}, inhalt));
    const huelle = h("div", {class: "dialog-huelle", onpointerdown: e => { if (e.target === huelle) dialogZu(); }}, kasten);
    /* Ziehen am KOPF (Nutzerbefund: der Auftragsdialog stand starr in der Mitte und verdeckte genau
       die Fläche, die man beim Lesen sehen will). Pointer-Events — Maus, Finger und Stift gleich;
       NICHT am Inhalt, sonst könnte man Text nicht mehr markieren. Geklemmt, damit kein Dialog aus
       dem sichtbaren Bereich geschoben werden kann, und ohne gemerkte Lage: jeder Dialog startet
       wieder mittig (deterministisch), weil hier jedes Mal ein frischer Kasten entsteht.
       `transform` statt `left/top`: kein Layout-Sprung, die Hülle bleibt die Zentrierung. */
    const kopf = kasten.querySelector(".dialog-kopf");
    if (kopf) kopf.addEventListener("pointerdown", e => {
      if (e.target.closest && e.target.closest("button")) return;      /* der Schließen-Knopf bleibt ein Knopf */
      if (typeof e.clientX !== "number" || !kasten.getBoundingClientRect) return;
      e.preventDefault();                                             /* keine Textauswahl beim Ziehen */
      const start = {x: e.clientX, y: e.clientY};
      const basis = kasten.getBoundingClientRect();                   /* die zentrierte Grundlage */
      const rand = 12, vw = () => (typeof innerWidth === "number" ? innerWidth : 0), vh = () => (typeof innerHeight === "number" ? innerHeight : 0);
      const grenzen = () => ({minX: rand - basis.left, maxX: vw() - rand - basis.right,
                              minY: rand - basis.top, maxY: vh() - rand - basis.bottom});
      const bewegen = ev => {
        const b = grenzen();
        const dx = Math.max(b.minX, Math.min(b.maxX, ev.clientX - start.x));
        const dy = Math.max(b.minY, Math.min(b.maxY, ev.clientY - start.y));
        kasten.style.transform = `translate(${Math.round(dx)}px, ${Math.round(dy)}px)`;
      };
      const loslassen = () => {
        kopf.removeEventListener("pointermove", bewegen);
        kopf.removeEventListener("pointerup", loslassen);
        kopf.removeEventListener("pointercancel", loslassen);
        kopf.classList.remove("zieht");
      };
      kopf.setPointerCapture?.(e.pointerId);
      kopf.classList.add("zieht");
      kopf.addEventListener("pointermove", bewegen);
      kopf.addEventListener("pointerup", loslassen);
      kopf.addEventListener("pointercancel", loslassen);
    });
    huelle.addEventListener("keydown", e => {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); dialogZu(); }
      if (e.key === "Tab") {         /* Fokus im Dialog halten */
        const f = $$("button:not([disabled]), input:not([disabled]), select, [tabindex='0']", kasten);
        if (!f.length) return;
        if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
        else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
      }
    });
    dialog = {huelle, vorher: document.activeElement};
    document.body.append(huelle);
    requestAnimationFrame(() => { huelle.classList.add("da"); zu.focus({preventScroll: true}); });
    return kasten;
  }
  function dialogZu(){
    if (!dialog) return;
    const d = dialog; dialog = null;
    d.huelle.remove();
    if (d.vorher?.isConnected) d.vorher.focus?.({preventScroll: true});
  }
  function einstellungAbschnitt(titel, fn){
    const i = abschnitte.findIndex(a => a.titel === titel);
    if (i >= 0) abschnitte[i].fn = fn; else abschnitte.push({titel, fn});
  }
  function wahl(name, optionen, aktuell, fn){
    return h("div", {class: "wahl", role: "radiogroup", "aria-label": name},
      optionen.map(([wertX, text]) => {
        const b = h("button", {type: "button", role: "radio", class: "wahl-knopf" + (wertX === aktuell ? " an" : ""), "aria-checked": String(wertX === aktuell), onclick: () => {
          for (const x of b.parentNode.children) { x.classList.toggle("an", x === b); x.setAttribute("aria-checked", String(x === b)); }
          fn(wertX);
        }}, text);
        return b;
      }));
  }
  function zeile(titel, text, steuer, kann){
    const gesperrt = kann && !kann.ja;
    return h("div", {class: "einst-zeile" + (gesperrt ? " gesperrt" : "")},
      h("div", {class: "einst-text"}, h("strong", {}, titel), text ? h("span", {}, text) : null, gesperrt && kann.grund ? h("span", {class: "einst-grund"}, kann.grund) : null),
      h("div", {class: "einst-steuer", inert: gesperrt ? "" : null, "aria-disabled": gesperrt ? "true" : null}, steuer));
  }
  function schalter(an, fn, titel){
    const b = h("button", {type: "button", role: "switch", class: "schalter" + (an ? " an" : ""), "aria-checked": String(!!an), "aria-label": titel,
      onclick: () => { const neu = b.getAttribute("aria-checked") !== "true"; b.setAttribute("aria-checked", String(neu)); b.classList.toggle("an", neu); fn(neu); }}, h("span", {}));
    return b;
  }
  /* Gekaufte Akzentfarben und Leistenstile auswählen (Spiel.shop.kaufen wechselt ohne erneutes Bezahlen) */
  function aussehenZeile(art, titel, text){
    if (typeof Spiel === "undefined" || !Spiel._st) return document.createTextNode("");      /* append(null) schriebe „null“ */
    const a = Spiel.karriere.daten().aussehen;
    const optionen = Spiel.AUSSEHEN.filter(x => x.art === art && a.gekauft.includes(x.id)).map(x => [x.id, x.titel.replace(/^Leiste: /, "")]);
    return zeile(titel, text, wahl(titel, optionen, a[art], v => { Spiel.shop.kaufen("aussehen:" + v); themaAnwenden(); }));
  }
  function eigeneAbschnitte(){
    const e = einst();
    const l = [];
    l.push({titel: "Darstellung", fn: c => c.append(
      zeile("Farbschema", "Dunkel ist der Leitstand-Look. „System“ folgt der Einstellung des Betriebssystems.",
        wahl("Farbschema", [["hell", "Hell"], ["dunkel", "Dunkel"], ["system", "System"]],
          eigenesTheme(e.thema) ? "" : (e.thema || "dunkel"), v => { einstSetzen({thema: v}); themaAnwenden(); })),
      zeile("Theme", "Fünf zusätzliche Themes mit eigenem Charakter – POLARIS bleibt der Standard. Ein Theme ersetzt das Farbschema.",
        wahl("Theme", [["", "POLARIS"], ...THEMEN.map(x => [x.id, x.titel])], eigenesTheme(e.thema) ? e.thema : "",
          v => { einstSetzen({thema: v || "dunkel"}); themaAnwenden(); })),
      zeile("Animationen", "Pakete fliegen, Zahlen zählen hoch. „Reduziert“ blendet nur kurz ein, „Aus“ zeigt Ergebnisse sofort. Die Systemeinstellung „Bewegung reduzieren“ wird immer beachtet.",
        wahl("Animationen", [["an", "An"], ["reduziert", "Reduziert"], ["aus", "Aus"]], e.bewegung || "an", v => { einstSetzen({bewegung: v}); themaAnwenden(); })),
      zeile("Ton", "Leise Klänge bei Kabel, Ping, Haken und Sternen – alles bleibt auch ohne Ton verständlich. Die Leiste und ein Fenster im Hintergrund sind immer stumm.",
        wahl("Ton", [["aus", "Aus"], ["leise", "Leise"], ["normal", "Normal"]], e.ton || "leise", v => { einstSetzen({ton: v}); UI.klang?.spielen("haken"); })),
      aussehenZeile("akzent", "Akzentfarbe", "Weitere Farben gibt es im Shop – gekaufte wählst du hier jederzeit."),
      aussehenZeile("leiste", "Leiste", "Wie die kleine Leiste am Bildschirmrand aussieht. Weitere Stile gibt es im Shop."),
      zeile("Ereignisse", "Stromausfall, Kabelschaden, Notfall-Anruf … höchstens eines je 30 (selten) oder 15 Minuten Arbeit (normal), immer mit Erklärung. Fortschritt geht nie verloren.",
        wahl("Ereignisse", [["aus", "Aus"], ["selten", "Selten"], ["normal", "Normal"]], e.ereignisse || "selten", v => { einstSetzen({ereignisse: v}); if (Spiel._einst) Spiel._einst.ereignisse = v; })),
      zeile("Anpassung", "Automatisch: Nach zwei zähen Aufträgen in einer Fertigkeit kommt der nächste mit Gerüst (Tipp, Haken, Warnungen), nach drei Glanzergebnissen wird er kniffliger. Manuell: Es gilt nur das Niveau.",
        wahl("Anpassung", [["auto", "Automatisch"], ["manuell", "Manuell"]], e.anpassung || "auto", v => { einstSetzen({anpassung: v}); if (Spiel._einst) Spiel._einst.anpassung = v; })))});
    l.push({titel: "Erklärtiefe", fn: c => c.append(
      zeile("Wie ausführlich sollen Konsole und Simulation erklären?", "Einstieg erklärt jeden Schritt, AP1 knapp, AP2 zeigt nur, was ein echtes Gerät melden würde.",
        wahl("Erklärtiefe", [["E", "Einstieg"], ["AP1", "AP1"], ["AP2", "AP2"]], e.niveau || "E", v => { einstSetzen({niveau: v}); Bus.senden("niveau", v); })))});
    l.push({titel: "Leiste", fn: c => {
      /* Runde 5 (Leitung): Standard 0,92 statt 0,55 — die Leiste wirkte ausgewaschen und beliebig
         (Befund des Nutzers: „vermittelt visuell nicht ihren Nutzen"). Regelbar bleibt 60–100 %. */
      const le = Object.assign({deckkraft: 0.92, ecke: "ur"}, e.leiste);
      const setzeLeiste = teil => { const x = einst(); x.leiste = Object.assign({deckkraft: 0.92, ecke: "ur"}, x.leiste, teil); store.set("einst", x); UI.leiste?.darstellen?.(); };
      const kannL = Plattform.kann("leiste");
      const prozent = h("output", {class: "einst-wert"}, Math.round(le.deckkraft * 100) + " %");
      const regler = h("input", {type: "range", min: "60", max: "100", step: "5", value: String(Math.round(le.deckkraft * 100)), "aria-label": "Deckkraft der Leiste ohne Maus",
        oninput: ev => { prozent.textContent = ev.target.value + " %"; setzeLeiste({deckkraft: +ev.target.value / 100}); }});
      c.append(zeile("Deckkraft ohne Maus", "Mit der Maus darüber ist die Leiste immer voll deckend.", h("div", {class: "regler"}, regler, prozent), kannL));
      c.append(zeile("Position", Plattform.name === "browser" ? "Im Browser: Ecke der kleinen Karte." : "Ecke des Bildschirms, an der die Leiste sitzt.",
        wahl("Position", [["ol", "oben links"], ["or", "oben rechts"], ["ul", "unten links"], ["ur", "unten rechts"]], le.ecke, v => {
          setzeLeiste({ecke: v}); try { Promise.resolve(Plattform.fenster.position(v)).catch(() => {}); } catch {}
        }), kannL));
      const kannO = Plattform.kann("immerOben");
      c.append(zeile("Immer im Vordergrund", "Die Leiste bleibt über anderen Fenstern.", schalter(!!le.immerOben, v => { setzeLeiste({immerOben: v}); try { Promise.resolve(Plattform.fenster.immerOben(v)).catch(() => {}); } catch {} }, "Immer im Vordergrund"), kannO));
      const kannA = Plattform.kann("autostart");
      const auto = schalter(false, v => { Promise.resolve(Plattform.autostart(v)).catch(err => UI.toast(`Autostart ließ sich nicht ändern: ${err.message || err}`, "fehler")); }, "Autostart");
      if (kannA.ja) Promise.resolve(Plattform.autostartStatus()).then(an => { auto.classList.toggle("an", !!an); auto.setAttribute("aria-checked", String(!!an)); }).catch(() => {});
      c.append(zeile("Mit dem Computer starten", "Startet still im Tray – nur wenn du das willst.", auto, kannA));
    }});
    return l;
  }
  function einstellungen(){
    const inhalt = h("div", {class: "einst"});
    for (const a of [...eigeneAbschnitte(), ...abschnitte]) {
      const c = h("section", {class: "einst-abschnitt"}, h("h3", {}, a.titel));
      try { a.fn(c); } catch (e) { console.error("Einstellungen", a.titel, e); c.append(h("p", {}, "Dieser Abschnitt konnte nicht geladen werden.")); }
      inhalt.append(c);
    }
    inhalt.append(h("p", {class: "einst-fuss"}, `Netzwerk-Labor ${typeof LABOR_VERSION !== "undefined" ? LABOR_VERSION : ""}${typeof LABOR_BAU !== "undefined" ? " · Stand " + LABOR_BAU : ""} · ${Plattform.name === "tauri" ? "Desktop-Programm" : "Browser-Fassung"}`));
    dialogOeffnen("Einstellungen", inhalt, "dialog-einst");
  }
  const KUERZEL = [
    ["Überall", [["Strg+K", "Befehlspalette: Gerät springen, „ping A B“, Ebene, Ansicht"], ["?", "diese Übersicht"], ["Esc", "abbrechen, Menü schließen, Auswahl aufheben"]]],
    ["Labor – Werkzeuge", [["V", "Auswählen (Ziehen auf freier Fläche verschiebt die Ansicht, Shift+Ziehen = Auswahlrahmen)"], ["K", "Kabel verlegen"], ["P", "Ping-Werkzeug (mit Auswahl: Ping von diesem Gerät)"],
      ["1 … 4", "Geräte-Fach öffnen: Endgeräte · Server · Netzwerk · Außenwelt (im offenen Fach: 1 … n wählt das Gerät)"], ["⇧1 … ⇧5", "Ebene: Physik · VLAN · IP-Netze · MAC · Routen"]]],
    ["Labor – Ansicht", [["F", "alles einpassen"], ["A", "aufräumen (Auto-Layout)"], ["+  −  0", "Zoom größer, kleiner, 100 %"], ["Pfeiltasten", "Ansicht verschieben (mit Auswahl: Gerät verschieben, Shift = weiter)"], ["I / S", "Inspektor / Simulation ein- und ausklappen"]]],
    ["Labor – Bearbeiten", [["Entf", "Gerät oder Kabel löschen (Rückgängig statt Nachfrage)"], ["Strg+Z", "rückgängig"], ["Strg+Y", "wiederholen"], ["T / C", "Terminal des gewählten Geräts (im Dock)"], ["Enter", "Inspektor des gewählten Geräts"]]],
    ["Maus", [["Ziehen (leer)", "Ansicht verschieben (Hand)"], ["Shift+Ziehen (leer)", "Auswahlrahmen: mehrere Geräte (additiv)"], ["Ziehen (Gerät)", "Gerät verschieben"], ["Shift+Klick", "Gerät zur Auswahl hinzufügen/entfernen"], ["⊕ oder Port-Punkt ziehen", "Kabel (Shift beim Loslassen: Port wählen)"], ["Mausrad", "Zoom um den Mauszeiger"], ["Doppelklick", "leere Fläche: Gerät einsetzen · Gerät: Terminal"], ["Rechtsklick", "Konsole, Ping, Strom, Neustart, Löschen · Kabel: testen, trennen"]]],
  ];
  function hilfe(){
    const inhalt = h("div", {class: "kuerzel"}, KUERZEL.map(([titel, l]) => h("section", {}, h("h3", {}, titel),
      h("dl", {}, l.map(([k, t]) => [h("dt", {}, k.split(/(\s\/\s|\s…\s|\s\s)/).map(s => s.trim() && !/^(\/|…)$/.test(s.trim()) ? h("kbd", {}, s.trim()) : s)), h("dd", {}, t)])))));
    dialogOeffnen("Tastenkürzel", inhalt, "dialog-hilfe");
  }

  /* ---------- Tastatur (eine Stelle für alles) ---------- */
  function tastenEinrichten(){
    if (tastenAn) return;
    tastenAn = true;
    document.addEventListener("keydown", e => {
      if (modus !== "voll") return;
      const t = e.target;
      const eingabe = t && t.closest && t.closest("input, textarea, select, [contenteditable=''], [contenteditable='true']");
      if ((e.ctrlKey || e.metaKey) && !e.altKey && (e.key === "k" || e.key === "K")) { e.preventDefault(); UI.palette.oeffnen(); return; }
      if (dialog || UI.palette.offen) return;
      if (eingabe || e.defaultPrevented) return;
      if (e.key === "?" && !e.ctrlKey && !e.metaKey) { e.preventDefault(); hilfe(); return; }
      if (aktiv === "labor" && t.closest?.(".labor, body") && !t.closest?.(".lb-inspektor, .lb-sim-inhalt, .lb-dock")) {
        if (UI.labor.taste(e)) e.preventDefault();
      } else if (aktiv === "labor" && (e.ctrlKey || e.metaKey) && /^[zyZY]$/.test(e.key)) {
        if (UI.labor.taste(e)) e.preventDefault();
      }
    });
    if (typeof matchMedia !== "undefined") matchMedia("(prefers-color-scheme: light)").addEventListener?.("change", () => themaAnwenden());
  }

  /* ---------- Modi: ein Fenster, zwei Ansichten ---------- */
  function modusSetzen(m){
    if (!["voll", "leiste", "tray"].includes(m) || m === modus) return;
    const alt = modus;
    try { Promise.resolve(store.sofort()).catch(e => console.warn("Speichern", e)); } catch (e) { console.warn(e); }
    UI.menue?.zu?.(); UI.palette?.schliessen?.(); dialogZu();
    const container = document.getElementById("app");
    if (alt === "voll") abbauen();
    if (m === "voll" && UI.leiste.aufgebaut) UI.leiste.abbauen();
    modus = m;
    document.documentElement.dataset.modus = m;
    if (m === "voll") aufbauen(container);
    else if (m === "leiste" && !UI.leiste.aufgebaut) UI.leiste.aufbauen(container);
    try { Promise.resolve(Plattform.fenster.modus(m)).catch(e => console.warn("Fenstermodus", e)); } catch (e) { console.warn(e); }
    Bus.senden("modus", m);
  }

  return {registrieren, ansicht, status, einstellungen, einstellungAbschnitt, hilfe, aktualisieren, liste, aufbauen, abbauen,
          themaAnwenden, themaUmschalten, istDunkel, dialogOeffnen, dialogZu, modusSetzen,
          get aktuell(){ return aktiv; }, get modus(){ return modus; }, get werte(){ return {...wert}; }};
})();

UI.modus = function(m){ if (m === undefined) return UI.app.modus; return UI.app.modusSetzen(m); };
