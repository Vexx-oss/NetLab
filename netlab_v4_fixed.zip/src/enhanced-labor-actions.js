
/* 
NetLab Version 4.0 - Erweiterte Labor-Aktionen
*/

// Erweiterte Labor-Aktionen mit neuen Funktionen
class EnhancedLaborActions {
  constructor() {
    this.version = "4.0";
    this.coreActions = [
      {id: "kabel-verlegen", name: "Kabel verlegen", taste: "K", description: "Verlege Kabel zwischen Geräten"},
      {id: "geraet-anklicken", name: "Gerät anlicken", taste: "D", description: "Öffne das Gerät für die Konfiguration"},
      {id: "ping-werkzeug", name: "Ping-Werkzeug", taste: "P", description: "Teste Netzwerkverbindungen"},
      {id: "terminal-oeffnen", name: "Terminal öffnen", taste: "T", description: "Öffne das Terminal des Geräts"},
      {id: "simulation-oeffnen", name: "Simulation öffnen", taste: "S", description: "Öffne die Paket-Simulation"},
      {id: "inspektor-oeffnen", name: "Inspektor öffnen", taste: "I", description: "Öffne den Inspektor für detaillierte Informationen"}
    ];
    
    // Neue Funktionen für Version 4.0
    this.enhancements = {
      contextualActions: true,
      quickAccess: true,
      combinationFeatures: true,
      visualization: true
    };
    
    this.actionHistory = [];
  }
  
  // Methode zur Erzeugung kontextabhängiger Aktionen
  getContextualActions(currentContext) {
    // Aktionen basierend auf dem aktuellen Kontext
    const contextualActions = [];
    
    switch(currentContext) {
      case 'network':
        contextualActions.push(
          {id: "vlan-verwalten", name: "VLAN verwalten", taste: "V", description: "Konfiguriere VLANs"},
          {id: "router-config", name: "Router konfigurieren", taste: "R", description: "Konfiguriere Router-Einstellungen"}
        );
        break;
      case 'security':
        contextualActions.push(
          {id: "acl-erstellen", name: "ACL erstellen", taste: "A", description: "Erstelle Zugriffskontrolllisten"},
          {id: "firewall-config", name: "Firewall konfigurieren", taste: "F", description: "Konfiguriere Firewall-Regeln"}
        );
        break;
      case 'dhcp':
        contextualActions.push(
          {id: "dhcp-server", name: "DHCP-Server", taste: "H", description: "Konfiguriere DHCP-Server"},
          {id: "dhcp-reservierung", name: "DHCP-Reservierung", taste: "E", description: "Erstelle DHCP-Reservierungen"}
        );
        break;
    }
    
    return contextualActions;
  }
  
  // Methode für Schnellzugriff
  getQuickAccessActions() {
    return [
      {id: "aktion-1", name: "Schnellaktion 1", taste: "1", description: "Schnellzugriff Aktion 1"},
      {id: "aktion-2", name: "Schnellaktion 2", taste: "2", description: "Schnellzugriff Aktion 2"},
      {id: "aktion-3", name: "Schnellaktion 3", taste: "3", description: "Schnellzugriff Aktion 3"}
    ];
  }
  
  // Methode zur Visualisierung von Aktionen
  visualizeActions(actions) {
    return {
      actionList: actions,
      visualRepresentation: true,
      filterOptions: ["Alle", "Netzwerk", "Sicherheit", "Konfiguration"],
      quickFilter: true
    };
  }
  
  // Methode zur Verwaltung von Aktionen
  manageActions(actionId, operation) {
    switch(operation) {
      case 'add':
        this.actionHistory.push({actionId, operation, timestamp: Date.now()});
        return {status: 'added', actionId};
      case 'remove':
        const index = this.actionHistory.findIndex(item => item.actionId === actionId);
        if (index > -1) {
          this.actionHistory.splice(index, 1);
          return {status: 'removed', actionId};
        }
        return {status: 'not_found', actionId};
      default:
        return {status: 'unknown_operation', operation};
    }
  }
  
  // Methode zur Erstellung benutzerdefinierter Aktionen
  createCustomAction(name, description, shortcut) {
    const customAction = {
      id: `custom-${Date.now()}`,
      name: name,
      taste: shortcut,
      description: description,
      custom: true,
      createdAt: Date.now()
    };
    
    this.coreActions.push(customAction);
    return customAction;
  }
  
  // Methode für Kombinationsaktionen
  createCombinationAction(actions) {
    return {
      id: `combo-${Date.now()}`,
      name: "Kombinationsaktion",
      description: "Kombinierte Aktion aus " + actions.length + " Einzelaktionen",
      actions: actions,
      combination: true
    };
  }
}

// Export für die Nutzung im Projekt
if (typeof module !== 'undefined' && module.exports) {
  module.exports = EnhancedLaborActions;
}
